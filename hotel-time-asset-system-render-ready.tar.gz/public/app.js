const state = {
  dashboard: null,
  selectedRoomId: 2,
  quote: null,
  activeAdmin: "overview",
  startMinute: 0,
  endMinute: 0,
  quoteTimer: null
};

const ACCESS_PASSWORD = "yang10101212";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const statusText = {
  idle: "空闲",
  occupied: "入住中",
  overtime: "超时",
  cleaning: "清洁中",
  pending: "待入住",
  ongoing: "进行中",
  completed: "已完成",
  sold: "已售",
  maintenance: "维护中"
};

const typeText = {
  economy: "经济型",
  standard: "标准型",
  deluxe: "豪华型"
};

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addDays(value, days) {
  const d = new Date(`${value}T00:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function formatMoney(value) {
  return `¥${Number(value || 0).toFixed(2)}`;
}

function formatMinute(minute) {
  const hour = Math.floor(minute / 60);
  const min = minute % 60;
  return `${String(hour).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
}

function timeOptions(kind) {
  const min = kind === "start" ? 0 : 30;
  const max = kind === "start" ? 1410 : 1440;
  const options = [];
  for (let minute = min; minute <= max; minute += 15) options.push(minute);
  return options;
}

function renderTimeWheel(id, kind) {
  const wheel = $(id);
  wheel.innerHTML = timeOptions(kind).map((minute) => `
    <button class="time-option" type="button" data-minute="${minute}">${formatMinute(minute)}</button>
  `).join("");

  wheel.addEventListener("click", (event) => {
    const option = event.target.closest(".time-option");
    if (!option) return;
    setWheelValue(id, Number(option.dataset.minute), true);
    refreshQuote();
  });

  wheel.addEventListener("scroll", () => {
    window.clearTimeout(wheel._scrollTimer);
    wheel._scrollTimer = window.setTimeout(() => {
      const minute = nearestWheelMinute(wheel);
      if (kind === "start") state.startMinute = minute;
      else state.endMinute = minute;
      updateTimeUi();
      refreshQuoteDebounced();
    }, 80);
  });
}

function nearestWheelMinute(wheel) {
  const center = wheel.scrollTop + wheel.clientHeight / 2;
  let best = null;
  let bestDistance = Infinity;
  wheel.querySelectorAll(".time-option").forEach((option) => {
    const optionCenter = option.offsetTop + option.offsetHeight / 2;
    const distance = Math.abs(optionCenter - center);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = Number(option.dataset.minute);
    }
  });
  return best ?? 0;
}

function setWheelValue(id, minute, smooth = false) {
  const wheel = $(id);
  const option = wheel.querySelector(`[data-minute="${minute}"]`);
  if (!option) return;
  option.scrollIntoView({ block: "center", behavior: smooth ? "smooth" : "auto" });
}

function updateTimeUi() {
  $("#startText").textContent = formatMinute(state.startMinute);
  $("#endText").textContent = formatMinute(state.endMinute);
  $("#selectedBand").style.setProperty("--left", `${(state.startMinute / 1440) * 100}%`);
  $("#selectedBand").style.setProperty("--width", `${Math.max(0, (state.endMinute - state.startMinute) / 1440) * 100}%`);

  $$("#startWheel .time-option").forEach((option) => option.classList.toggle("selected", Number(option.dataset.minute) === state.startMinute));
  $$("#endWheel .time-option").forEach((option) => option.classList.toggle("selected", Number(option.dataset.minute) === state.endMinute));
}

function refreshQuoteDebounced() {
  window.clearTimeout(state.quoteTimer);
  state.quoteTimer = window.setTimeout(refreshQuote, 120);
}

function formatDateTime(value) {
  const d = new Date(value);
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "请求失败");
  return data;
}

async function loadDashboard() {
  const date = $("#bookingDate").value || today();
  state.dashboard = await api(`/api/bootstrap?date=${date}`);
  renderAll();
  await refreshQuote();
}

function renderAll() {
  renderRooms();
  renderTimelines();
  renderHardware();
  renderMetrics();
  renderOrders();
  renderPricing();
  renderCleaning();
  $("#clockText").textContent = `系统时间 ${formatDateTime(state.dashboard.now)}`;
}

function renderRooms() {
  $("#roomCards").innerHTML = state.dashboard.rooms.map((room) => `
    <button class="room-card ${room.id === state.selectedRoomId ? "active" : ""}" data-room-id="${room.id}">
      <span>
        <strong>${room.number}房</strong><br />
        <small>${room.typeLabel} · 基础价 ${formatMoney(room.base_price)}/晚</small>
      </span>
      <span class="status-pill status-${room.status}">${statusText[room.status] || room.status}</span>
    </button>
  `).join("");

  $$(".room-card").forEach((card) => card.addEventListener("click", async () => {
    state.selectedRoomId = Number(card.dataset.roomId);
    state.quote = null;
    renderRooms();
    await refreshQuote();
  }));
}

function renderTimelines() {
  const html = state.dashboard.timelines.map((timeline) => {
    const idle = timeline.counts.idle || 0;
    return `
      <div class="timeline-row">
        <strong>${timeline.roomNumber}房</strong>
        <div class="timeline-track" title="一天1440个一分钟颗粒">
          ${timeline.segments.map((seg) => `<span class="timeline-segment ${seg.state}" style="width:${seg.width}%"></span>`).join("")}
        </div>
        <span class="minute-count">空闲${idle}分</span>
      </div>
    `;
  }).join("");
  $("#guestTimelines").innerHTML = html;
  $("#adminTimelines").innerHTML = html;
}

function renderHardware() {
  const hardwareByRoom = Object.fromEntries(state.dashboard.hardware.map((h) => [h.room_id, h]));
  const html = state.dashboard.rooms.map((room) => {
    const h = hardwareByRoom[room.id] || {};
    return `
      <div class="hardware-card">
        <strong>${room.number}房 · ${statusText[room.status]}</strong>
        <div class="hardware-icons">
          <span class="${h.lock_authorized ? "on" : ""}" title="门锁授权">🔐</span>
          <span class="${h.lock_open ? "on" : ""}" title="门锁开启">🚪</span>
          <span class="${h.power_on ? "on" : ""}" title="房间供电">💡</span>
          <span class="on" title="应急照明">🟡</span>
        </div>
        <small>门锁${h.lock_authorized ? "已授权" : "未授权"} · 房间${h.power_on ? "供电中" : "已断电"} · 应急照明保留</small>
      </div>
    `;
  }).join("");
  $("#guestHardware").innerHTML = html;

  $("#roomOps").innerHTML = state.dashboard.rooms.map((room) => {
    const h = hardwareByRoom[room.id] || {};
    const current = state.dashboard.orders.find((o) => o.room_id === room.id && ["ongoing", "overtime"].includes(o.status));
    return `
      <div class="ops-row">
        <div>
          <strong>${room.number}房</strong>
          <span class="status-pill status-${room.status}">${statusText[room.status]}</span>
          <p>${room.typeLabel} · 当前订单：${current ? `#${current.id} ${escapeHtml(current.guest)}` : "无"}</p>
          <small>🔐 ${h.lock_authorized ? "有权限" : "无权限"} · 💡 ${h.power_on ? "供电" : "断电"} · 🟡 应急照明</small>
        </div>
        <div class="ops-actions">
          ${current ? `<button class="mini-button ok" data-action="checkout" data-id="${current.id}">退房</button><button class="mini-button warn" data-action="overtime" data-id="${current.id}">模拟超时</button>` : ""}
        </div>
      </div>
    `;
  }).join("");
}

function renderMetrics() {
  const m = state.dashboard.metrics;
  $("#metricIncome").textContent = formatMoney(m.todayIncome);
  $("#metricOccupancy").textContent = `${m.occupancyRate}%`;
  $("#metricAvg").textContent = formatMoney(m.averageRoomPrice);
  $("#metricMinutes").textContent = `${m.soldMinutes}分`;

  const orderRevenue = state.dashboard.orders
    .slice(0, 5)
    .reverse()
    .map((o) => ({ label: `#${o.id}`, value: o.price + o.overtime_fee }));
  const max = Math.max(1, ...orderRevenue.map((x) => x.value));
  $("#barChart").innerHTML = orderRevenue.map((x) => `
    <div class="bar" style="height:${Math.max(8, (x.value / max) * 160)}px" title="${x.label} ${formatMoney(x.value)}"><span>${x.label}</span></div>
  `).join("");

  const total = m.soldMinutes + m.idleMinutes;
  const degree = total ? (m.soldMinutes / total) * 360 : 0;
  $("#pieChart").style.setProperty("--sold-deg", `${degree}deg`);
}

function renderOrders() {
  $("#ordersTable").innerHTML = state.dashboard.orders.map((order) => `
    <div class="order-row">
      <div>
        <strong>#${order.id} · ${order.room_number}房 · ${escapeHtml(order.guest)}</strong><br />
        <span>${formatDateTime(order.start_at)} - ${formatDateTime(order.end_at)}</span>
      </div>
      <span class="status-pill status-${order.status}">${statusText[order.status]}</span>
      <span>${formatMoney(order.price)} + 押金${formatMoney(order.deposit)}<br />超时费 ${formatMoney(order.overtime_fee)}</span>
      <div class="order-actions">
        ${order.status === "pending" ? `<button class="mini-button ok" data-action="checkin" data-id="${order.id}">到点入住</button>` : ""}
        ${["ongoing", "overtime"].includes(order.status) ? `<button class="mini-button ok" data-action="checkout" data-id="${order.id}">退房</button><button class="mini-button warn" data-action="overtime" data-id="${order.id}">超时处理</button>` : ""}
        <button class="mini-button" data-action="contract" data-id="${order.id}">看契约</button>
      </div>
    </div>
  `).join("");
}

function renderPricing() {
  const roomPrices = state.dashboard.rooms.reduce((acc, room) => {
    acc[room.type] = room.base_price;
    return acc;
  }, {});
  const priceRows = Object.entries(roomPrices).map(([type, value]) => `
    <label class="pricing-row">
      <span>${typeText[type]}基础价</span>
      <input data-price-type="${type}" type="number" min="1" step="1" value="${value}" />
    </label>
  `).join("");
  const factorRows = state.dashboard.pricing.map((item) => `
    <label class="pricing-row">
      <span>${escapeHtml(item.label)}</span>
      <input data-factor-key="${item.key}" type="number" min="0.1" step="0.05" value="${item.value}" />
    </label>
  `).join("");
  $("#pricingForm").innerHTML = priceRows + factorRows;
}

function renderCleaning() {
  $("#cleaningList").innerHTML = state.dashboard.cleaningTasks.map((task) => `
    <div class="cleaning-row">
      <div>
        <strong>${task.room_number}房 · ${task.status === "pending" ? "待清洁" : "已完成"}</strong><br />
        <span>派单时间 ${formatDateTime(task.scheduled_at)} ${task.completed_at ? `· 完成 ${formatDateTime(task.completed_at)}` : ""}</span>
      </div>
      ${task.status === "pending" ? `<button class="mini-button ok" data-action="cleaning" data-id="${task.id}">清洁完成</button>` : `<span class="status-pill status-completed">已完成</span>`}
    </div>
  `).join("");
}

async function refreshQuote() {
  const start = state.startMinute;
  const end = state.endMinute;
  ensureEndDate();
  updateTimeUi();
  $("#openContract").disabled = true;
  state.quote = null;

  if ($("#endDate").value < $("#bookingDate").value) {
    $("#quotePrice").textContent = "结束时间要晚于开始时间";
    $("#quoteExplain").textContent = "结束日期不能早于开始日期。";
    return;
  }

  try {
    const q = await api("/api/quote", {
      method: "POST",
      body: {
        roomId: state.selectedRoomId,
        date: $("#bookingDate").value,
        endDate: $("#endDate").value,
        startMinute: start,
        endMinute: end
      }
    });
    state.quote = q;
    $("#quotePrice").textContent = formatMoney(q.price);
    $("#quoteExplain").textContent = `${q.minutes}分钟 · 供需系数×${q.demandCoefficient} · 需付${formatMoney(q.payTotal)}（含押金100元）`;
    $("#openContract").disabled = false;
  } catch (error) {
    $("#quotePrice").textContent = "该时间不可售";
    $("#quoteExplain").textContent = error.message;
  }
}

function showContract(contract) {
  $("#agreeContract").checked = false;
  $("#confirmOrder").disabled = true;
  $("#contractBody").innerHTML = `
    <div class="contract-line"><strong>房间</strong><span>${contract.roomNumber}房 · ${contract.roomType}</span></div>
    <div class="contract-line"><strong>起止时间</strong><span>${formatDateTime(contract.startAt)} - ${formatDateTime(contract.endAt)}</span></div>
    <div class="contract-line"><strong>房费</strong><span>${formatMoney(contract.price)}</span></div>
    <div class="contract-line"><strong>押金</strong><span>${formatMoney(contract.deposit)}</span></div>
    <div class="contract-line"><strong>物理执行</strong><span>${escapeHtml(contract.hardware)}</span></div>
    <div class="contract-line"><strong>超时规则</strong><span>${contract.rules.map(escapeHtml).join("<br />")}</span></div>
  `;
  $("#contractDialog").showModal();
}

async function confirmOrder(event) {
  event.preventDefault();
  if (!state.quote) return;
  try {
    state.dashboard = (await api("/api/orders", {
      method: "POST",
      body: {
        roomId: state.selectedRoomId,
        date: $("#bookingDate").value,
        endDate: $("#endDate").value,
        startMinute: state.startMinute,
        endMinute: state.endMinute,
        guest: "现场演示客户"
      }
    })).dashboard;
    $("#contractDialog").close();
    ["flowOrder", "flowCheckin", "flowUse"].forEach((id) => $(`#${id}`).classList.add("active"));
    toast("支付成功：订单已生成，门锁权限会在时间开始时自动生效。");
    renderAll();
    await refreshQuote();
  } catch (error) {
    toast(error.message);
  }
}

async function handleAction(action, id) {
  try {
    const date = $("#bookingDate").value;
    if (action === "checkin") {
      state.dashboard = await api(`/api/orders/${id}/checkin`, { method: "POST", body: { date } });
      toast("已触发入住：门锁授权、房间供电。");
    }
    if (action === "checkout") {
      state.dashboard = await api(`/api/orders/${id}/checkout`, { method: "POST", body: { date, mode: "early" } });
      $("#flowEnd").classList.add("active");
      toast("已退房：门锁失效、房间断电，并自动派保洁。");
    }
    if (action === "overtime") {
      state.dashboard = await api(`/api/orders/${id}/overtime`, { method: "POST", body: { date, minutes: 25 } });
      $("#flowEnd").classList.add("active");
      toast("已按超时20分钟以上规则扣除押金，并自动开启新周期。");
    }
    if (action === "cleaning") {
      state.dashboard = await api(`/api/cleaning/${id}/complete`, { method: "POST", body: { date } });
      toast("保洁完成：房间恢复空闲。");
    }
    if (action === "contract") {
      const order = state.dashboard.orders.find((o) => o.id === Number(id));
      showContract(order.contract);
      $("#confirmOrder").disabled = true;
    }
    renderAll();
    await refreshQuote();
  } catch (error) {
    toast(error.message);
  }
}

function toast(message) {
  $("#toast").textContent = message;
  $("#toast").classList.remove("hidden");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => $("#toast").classList.add("hidden"), 3600);
}

function bindEvents() {
  $$(".tab").forEach((tab) => tab.addEventListener("click", () => {
    $$(".tab").forEach((x) => x.classList.remove("active"));
    tab.classList.add("active");
    $("#guestView").classList.toggle("hidden", tab.dataset.view !== "guest");
    $("#adminView").classList.toggle("hidden", tab.dataset.view !== "admin");
  }));

  $$(".admin-nav").forEach((button) => button.addEventListener("click", () => {
    $$(".admin-nav").forEach((x) => x.classList.remove("active"));
    button.classList.add("active");
    $$(".admin-page").forEach((page) => page.classList.add("hidden"));
    $(`#admin${button.dataset.admin[0].toUpperCase()}${button.dataset.admin.slice(1)}`).classList.remove("hidden");
  }));

  $("#bookingDate").addEventListener("change", loadDashboard);
  $("#endDate").addEventListener("change", refreshQuote);
  $("#openContract").addEventListener("click", () => state.quote && showContract(state.quote.contract));
  $("#agreeContract").addEventListener("change", () => $("#confirmOrder").disabled = !$("#agreeContract").checked || !state.quote);
  $("#confirmOrder").addEventListener("click", confirmOrder);

  document.body.addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    handleAction(button.dataset.action, button.dataset.id);
  });

  $("#savePricing").addEventListener("click", async () => {
    const prices = Object.fromEntries($$("[data-price-type]").map((input) => [input.dataset.priceType, input.value]));
    const factors = Object.fromEntries($$("[data-factor-key]").map((input) => [input.dataset.factorKey, input.value]));
    state.dashboard = await api("/api/pricing", { method: "POST", body: { prices, factors, date: $("#bookingDate").value } });
    toast("定价已保存，报价会立即按新规则计算。");
    renderAll();
    await refreshQuote();
  });

  $("#resetDemo").addEventListener("click", async () => {
    state.dashboard = await api("/api/demo/reset", { method: "POST", body: { date: $("#bookingDate").value } });
    state.selectedRoomId = 2;
    toast("演示数据已恢复到初始状态。");
    renderAll();
    await refreshQuote();
  });
}

function setDefaultTime() {
  const now = new Date();
  const start = Math.min(1320, Math.ceil((now.getHours() * 60 + now.getMinutes() + 30) / 15) * 15);
  state.startMinute = start;
  state.endMinute = start + 120 > 1440 ? start + 120 - 1440 : start + 120;
  ensureEndDate();
  setWheelValue("#startWheel", state.startMinute);
  setWheelValue("#endWheel", state.endMinute);
  updateTimeUi();
}

function ensureEndDate() {
  const startDate = $("#bookingDate").value || today();
  if (!$("#endDate").value || $("#endDate").value < startDate) $("#endDate").value = startDate;
  const shouldCrossDay = state.endMinute <= state.startMinute;
  if (shouldCrossDay && $("#endDate").value === startDate) $("#endDate").value = addDays(startDate, 1);
}

async function startSystem() {
  $("#bookingDate").value = today();
  $("#endDate").value = today();
  renderTimeWheel("#startWheel", "start");
  renderTimeWheel("#endWheel", "end");
  setDefaultTime();
  bindEvents();
  await loadDashboard();
  setInterval(loadDashboard, 45_000);
}

function boot() {
  $("#authForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = $("#accessPassword").value.trim();
    if (input !== ACCESS_PASSWORD) {
      $("#authMessage").textContent = "系统维护中";
      $("#accessPassword").select();
      return;
    }

    $("#authMessage").textContent = "";
    $("#authGate").hidden = true;
    document.body.classList.remove("auth-locked");
    await startSystem();
  });
}

try {
  boot();
} catch (error) {
  toast(error.message);
}
