const state = {
  dashboard: null,
  selectedRoomId: 0,
  quote: null,
  activeAdmin: "overview",
  startMinute: 0,
  endMinute: 0,
  quoteTimer: null,
  lastCleaningTaskId: 0,
  lastAlertId: 0,
  lastTransferId: 0,
  alertSound: true,
  storeMode: "A",
  crossStoreRecommendation: null,
  crossPromptKey: "",
  roomTypeFilter: "all",
  floorFilter: "all",
  userInteracted: false,
  expectedArrivalMinutes: 0,
  guestHardwareRoomId: Number(sessionStorage.getItem("guestHardwareRoomId") || 0),
  lastCheckinQr: sessionStorage.getItem("lastCheckinQr") || "",
  paymentMethod: "微信支付",
  compensationType: "traffic",
  user: JSON.parse(sessionStorage.getItem("hotelDemoUser") || "null"),
  timeCard: JSON.parse(sessionStorage.getItem("hotelTimeCard") || "null")
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const statusText = {
  idle: "空闲",
  occupied: "入住中",
  overtime: "超时",
  cleaning: "清洁中",
  pending: "已预订",
  ongoing: "进行中",
  completed: "已完成",
  cancelled: "已取消",
  inspected: "已恢复",
  reserved_cleaning: "待清洁-已预订",
  ready: "已就绪",
  sold: "已售",
  maintenance: "维护中"
};

const cleaningStatusText = {
  pending: "已派单待接单",
  accepted: "已接单",
  cleaning: "清洁中",
  finished: "已完成",
  completed: "已完成",
  released: "已完成上架"
};

const cleaningPriorityText = {
  normal: "正常",
  urgent: "加急"
};

const typeText = {
  economy: "大床房",
  standard: "双人大床房",
  deluxe: "豪华大床房"
};

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addDays(value, days) {
  const d = new Date(`${value}T00:00:00`);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function formatMoney(value) {
  return `¥${Number(value || 0).toFixed(2)}`;
}

function formatMinute(minute) {
  const hour = Math.floor(minute / 60);
  const min = minute % 60;
  return `${String(hour).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
}

function dateAtMinute(date, minute) {
  const d = new Date(`${date}T00:00:00`);
  d.setMinutes(minute);
  return d;
}

function minutesBetween(start, end) {
  return Math.round((end - start) / 60_000);
}

function ymdFromDate(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function formatWheelLabel(date, minute) {
  const d = dateAtMinute(date, minute);
  return `${d.getMonth() + 1}/${d.getDate()} ${formatMinute(minute)}`;
}

function getSelectedStartAt() {
  return dateAtMinute($("#bookingDate")?.value || today(), state.startMinute);
}

function getSelectedEndAt() {
  return dateAtMinute($("#endDate")?.value || $("#bookingDate")?.value || today(), state.endMinute);
}

function applyDateMinute(kind, option) {
  const date = option.dataset.date;
  const minute = Number(option.dataset.minute);
  if (kind === "start") {
    $("#bookingDate").value = date;
    state.startMinute = minute;
    syncEndAfterStart();
  } else {
    $("#endDate").value = date;
    state.endMinute = minute;
  }
}

function syncEndAfterStart() {
  const startAt = getSelectedStartAt();
  const endAt = getSelectedEndAt();
  if (endAt > startAt) return;
  const suggested = new Date(startAt);
  suggested.setMinutes(suggested.getMinutes() + 120);
  $("#endDate").value = ymdFromDate(suggested);
  state.endMinute = suggested.getHours() * 60 + suggested.getMinutes();
}

function timeOptions(kind) {
  const date = kind === "end" ? ($("#endDate")?.value || $("#bookingDate")?.value || today()) : ($("#bookingDate")?.value || today());
  const options = [];
  // 从 00:00 开始，并保留 24:00 作为当天完整结束点，方便做整天/跨天契约。
  for (let minute = 0; minute <= 1440; minute += 15) {
    options.push({
      date,
      minute,
      offset: minute,
      label: formatMinute(minute)
    });
  }
  return options;
}

function renderTimeWheel(id, kind) {
  const wheel = $(id);
  wheel.innerHTML = timeOptions(kind).map((option) => `
    <option class="time-option" value="${option.date}|${option.minute}" data-date="${option.date}" data-minute="${option.minute}" data-offset="${option.offset}">${option.label}</option>
  `).join("");

  if (!wheel.dataset.bound) {
    wheel.dataset.kind = kind;
    wheel.dataset.bound = "1";
    wheel.addEventListener("change", async () => {
      const option = wheel.selectedOptions[0];
      if (!option) return;
      state.userInteracted = true;
      const beforeRange = `${$("#bookingDate").value}|${$("#endDate").value}`;
      applyDateMinute(wheel.dataset.kind, option);
      if (wheel.dataset.kind === "start") renderTimeWheel("#endWheel", "end");
      setWheelValue(id, option.dataset.date, Number(option.dataset.minute));
      updateTimeUi();
      const afterRange = `${$("#bookingDate").value}|${$("#endDate").value}`;
      if (afterRange !== beforeRange) await loadDashboard();
      else await refreshQuote();
    });
  }
}

function nearestWheelOption(wheel) {
  const center = wheel.scrollTop + wheel.clientHeight / 2;
  let best = null;
  let bestDistance = Infinity;
  wheel.querySelectorAll(".time-option").forEach((option) => {
    const optionCenter = option.offsetTop + option.offsetHeight / 2;
    const distance = Math.abs(optionCenter - center);
    if (distance < bestDistance) {
      bestDistance = distance;
      best = Number(option.dataset.minute);
      best = option;
    }
  });
  return best;
}

function setWheelValue(id, date, minute, smooth = false) {
  const wheel = $(id);
  const option = wheel.querySelector(`[data-date="${date}"][data-minute="${minute}"]`);
  if (!option) return;
  wheel.value = `${date}|${minute}`;
}

function updateTimeUi() {
  $("#startText").textContent = `${$("#bookingDate")?.value || today()} ${formatMinute(state.startMinute)}`;
  $("#endText").textContent = `${$("#endDate")?.value || $("#bookingDate")?.value || today()} ${formatMinute(state.endMinute)}`;
  const startDate = $("#bookingDate")?.value || today();
  const endDate = $("#endDate")?.value || startDate;
  const rangeStart = dateAtMinute(startDate, 0);
  const rangeEnd = dateAtMinute(endDate, 1440);
  const selectedStart = dateAtMinute(startDate, state.startMinute);
  const selectedEnd = dateAtMinute(endDate, state.endMinute);
  const totalMinutes = Math.max(1, minutesBetween(rangeStart, rangeEnd));
  const selectedMinutes = Math.max(0, minutesBetween(selectedStart, selectedEnd));
  const left = Math.max(0, Math.min(100, (minutesBetween(rangeStart, selectedStart) / totalMinutes) * 100));
  const width = Math.max(0, Math.min(100 - left, (selectedMinutes / totalMinutes) * 100));
  $("#selectedBand").style.setProperty("--left", `${left}%`);
  $("#selectedBand").style.setProperty("--width", `${width}%`);
  const stayDays = Math.floor(selectedMinutes / 1440);
  const stayHours = Math.floor((selectedMinutes % 1440) / 60);
  const stayMins = selectedMinutes % 60;
  const stayText = `${stayDays ? `${stayDays}天` : ""}${stayHours ? `${stayHours}小时` : ""}${stayMins ? `${stayMins}分钟` : ""}` || `${selectedMinutes}分钟`;
  $("#continuousRange").textContent = `${startDate} ${formatMinute(state.startMinute)} 入住 → ${endDate} ${formatMinute(state.endMinute)} 离店 · 共${stayText}`;
  updateArrivalUi();

  $$("#startWheel .time-option").forEach((option) => option.classList.toggle("selected", option.dataset.date === startDate && Number(option.dataset.minute) === state.startMinute));
  $$("#endWheel .time-option").forEach((option) => option.classList.toggle("selected", option.dataset.date === endDate && Number(option.dataset.minute) === state.endMinute));
}

function expectedArrivalMinutes() {
  const raw = $("#arrivalMinutes")?.value;
  const value = raw === "" || raw == null ? state.expectedArrivalMinutes : Number(raw);
  return Math.max(0, Math.min(240, Number.isFinite(value) ? value : 0));
}

function earliestArrivalAt() {
  const byArrival = new Date();
  byArrival.setMinutes(byArrival.getMinutes() + expectedArrivalMinutes());
  const byContract = getSelectedStartAt();
  return byArrival > byContract ? byArrival : byContract;
}

function updateArrivalUi() {
  const minutes = expectedArrivalMinutes();
  state.expectedArrivalMinutes = minutes;
  if ($("#earliestArrivalText")) $("#earliestArrivalText").textContent = `${formatDateTime(earliestArrivalAt().toISOString())} 最早入住`;
  const arrivalText = minutes === 0 ? "现在到店或暂不填写预计到店时间" : `预计${minutes}分钟后到店`;
  if ($("#arrivalHint")) $("#arrivalHint").textContent = `您${arrivalText}。请按预计时间到店办理入住。`;
}

function openArrivalDialog() {
  if (!state.quote) return;
  updateArrivalUi();
  $("#arrivalDialog").showModal();
}

async function openRulesDialog() {
  if (!state.quote) return;
  await ensureTimeCardBeforeBooking();
  updateCheckinRuleText();
  $("#agreeCheckinRules").checked = false;
  $("#confirmRules").disabled = true;
  $("#rulesDialog").showModal();
}

async function confirmArrivalAndShowContract() {
  if (!state.quote) return;
  $("#arrivalDialog").close();
  await refreshQuote();
  if (state.quote) showContract(state.quote.contract);
}

function refreshQuoteDebounced() {
  window.clearTimeout(state.quoteTimer);
  state.quoteTimer = window.setTimeout(refreshQuote, 120);
}

function refreshDashboardDebounced() {
  window.clearTimeout(state.quoteTimer);
  state.quoteTimer = window.setTimeout(loadDashboard, 180);
}

function formatDateTime(value) {
  const d = new Date(value);
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
}

function maskPhone(phone = "") {
  const raw = String(phone || "").replace(/\D/g, "");
  if (raw.length < 7) return raw || "未绑定手机号";
  return `${raw.slice(0, 3)}****${raw.slice(-4)}`;
}

function markFlowActive(ids) {
  ids.forEach((id) => {
    const node = $(`#${id}`);
    if (node) node.classList.add("active");
  });
}

function qrSvgDataUri(text) {
  const modules = makeQrMatrix(String(text || ""));
  const size = modules.length;
  const quiet = 4;
  const cell = 6;
  const outer = (size + quiet * 2) * cell;
  const rects = [];
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      if (modules[y][x]) rects.push(`<rect x="${(x + quiet) * cell}" y="${(y + quiet) * cell}" width="${cell}" height="${cell}"/>`);
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${outer}" height="${outer}" viewBox="0 0 ${outer} ${outer}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><g fill="#111">${rects.join("")}</g></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function makeQrMatrix(text) {
  // 固定使用 QR Version 4-L，足够容纳当前入住凭证；本地生成，不调用外部服务。
  const version = 4;
  const size = 17 + version * 4;
  const dataCodewords = 80;
  const eccCodewords = 20;
  const matrix = Array.from({ length: size }, () => Array(size).fill(false));
  const reserved = Array.from({ length: size }, () => Array(size).fill(false));
  const set = (x, y, value, lock = true) => {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    matrix[y][x] = Boolean(value);
    if (lock) reserved[y][x] = true;
  };
  const finder = (x, y) => {
    for (let dy = -1; dy <= 7; dy += 1) for (let dx = -1; dx <= 7; dx += 1) set(x + dx, y + dy, false);
    for (let dy = 0; dy < 7; dy += 1) for (let dx = 0; dx < 7; dx += 1) {
      const edge = dx === 0 || dx === 6 || dy === 0 || dy === 6;
      const core = dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4;
      set(x + dx, y + dy, edge || core);
    }
  };
  finder(0, 0);
  finder(size - 7, 0);
  finder(0, size - 7);
  for (let i = 8; i < size - 8; i += 1) {
    set(i, 6, i % 2 === 0);
    set(6, i, i % 2 === 0);
  }
  const alignment = (cx, cy) => {
    for (let dy = -2; dy <= 2; dy += 1) for (let dx = -2; dx <= 2; dx += 1) {
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      set(cx + dx, cy + dy, d !== 1);
    }
  };
  alignment(26, 26);
  set(8, 4 * version + 9, true);
  for (let i = 0; i < 9; i += 1) {
    if (i !== 6) {
      set(8, i, false);
      set(i, 8, false);
    }
  }
  for (let i = 0; i < 8; i += 1) {
    set(size - 1 - i, 8, false);
    set(8, size - 1 - i, false);
  }

  const bytes = [...new TextEncoder().encode(text)].slice(0, 72);
  const bits = [];
  const push = (value, length) => {
    for (let i = length - 1; i >= 0; i -= 1) bits.push((value >>> i) & 1);
  };
  push(0b0100, 4);
  push(bytes.length, 8);
  bytes.forEach((byte) => push(byte, 8));
  const maxBits = dataCodewords * 8;
  for (let i = 0; i < 4 && bits.length < maxBits; i += 1) bits.push(0);
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(Number.parseInt(bits.slice(i, i + 8).join(""), 2));
  for (let pad = 0; data.length < dataCodewords; pad += 1) data.push(pad % 2 ? 0x11 : 0xec);
  const codewords = [...data, ...qrReedSolomon(data, eccCodewords)];
  const allBits = codewords.flatMap((byte) => Array.from({ length: 8 }, (_, i) => (byte >>> (7 - i)) & 1));

  let bitIndex = 0;
  let upward = true;
  for (let x = size - 1; x > 0; x -= 2) {
    if (x === 6) x -= 1;
    for (let yi = 0; yi < size; yi += 1) {
      const y = upward ? size - 1 - yi : yi;
      for (let dx = 0; dx < 2; dx += 1) {
        const xx = x - dx;
        if (reserved[y][xx]) continue;
        const raw = allBits[bitIndex++] || 0;
        const mask = (xx + y) % 2 === 0;
        set(xx, y, raw ^ mask, false);
      }
    }
    upward = !upward;
  }
  writeQrFormat(matrix, reserved, 0);
  return matrix;
}

function qrReedSolomon(data, degree) {
  const exp = Array(512).fill(0);
  const log = Array(256).fill(0);
  let x = 1;
  for (let i = 0; i < 255; i += 1) {
    exp[i] = x;
    log[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i += 1) exp[i] = exp[i - 255];
  const mul = (a, b) => (a && b ? exp[log[a] + log[b]] : 0);
  let gen = [1];
  for (let i = 0; i < degree; i += 1) {
    const next = Array(gen.length + 1).fill(0);
    gen.forEach((coef, j) => {
      next[j] ^= mul(coef, exp[i]);
      next[j + 1] ^= coef;
    });
    gen = next;
  }
  const rem = Array(degree).fill(0);
  data.forEach((byte) => {
    const factor = byte ^ rem.shift();
    rem.push(0);
    gen.slice(1).forEach((coef, i) => {
      rem[i] ^= mul(coef, factor);
    });
  });
  return rem;
}

function writeQrFormat(matrix, reserved, mask) {
  const size = matrix.length;
  const set = (x, y, value) => {
    matrix[y][x] = Boolean(value);
    reserved[y][x] = true;
  };
  let data = (1 << 3) | mask; // L级纠错 + mask
  let bits = data << 10;
  const generator = 0x537;
  for (let i = 14; i >= 10; i -= 1) {
    if ((bits >>> i) & 1) bits ^= generator << (i - 10);
  }
  const format = ((data << 10) | bits) ^ 0x5412;
  const coords1 = [[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[7,8],[8,8],[8,7],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0]];
  const coords2 = [[size-1,8],[size-2,8],[size-3,8],[size-4,8],[size-5,8],[size-6,8],[size-7,8],[8,size-8],[8,size-7],[8,size-6],[8,size-5],[8,size-4],[8,size-3],[8,size-2],[8,size-1]];
  for (let i = 0; i < 15; i += 1) {
    const bit = (format >>> i) & 1;
    set(coords1[i][0], coords1[i][1], bit);
    set(coords2[i][0], coords2[i][1], bit);
  }
}

async function api(path, options = {}) {
  const token = sessionStorage.getItem("hotelAccessToken");
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(path, {
    headers,
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await res.json();
  if (res.status === 401) {
    sessionStorage.removeItem("hotelAccessToken");
    $("#authGate").hidden = false;
    document.body.classList.add("auth-locked");
  }
  if (!res.ok) throw new Error(data.message || "请求失败");
  return data;
}

async function loginWithPassword(password) {
  const res = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "系统维护中");
  sessionStorage.setItem("hotelAccessToken", data.token);
  return data;
}

async function loadDashboard() {
  const date = $("#bookingDate").value || today();
  ensureEndDate();
  const endDate = $("#endDate").value || date;
  state.dashboard = await api(`/api/bootstrap?date=${date}&endDate=${endDate}`);
  renderAll();
  await refreshQuote();
}

async function registerDemoUser({ silent = false } = {}) {
  const name = $("#guestName")?.value?.trim() || "现场演示客户";
  const phone = $("#guestPhone")?.value?.trim() || "13800001010";
  const result = await api("/api/users/register", { method: "POST", body: { name, phone } });
  state.user = result.user;
  state.timeCard = result.timeCard;
  sessionStorage.setItem("hotelDemoUser", JSON.stringify(state.user));
  sessionStorage.setItem("hotelTimeCard", JSON.stringify(state.timeCard));
  renderTimeCard();
  if (!silent) toast(result.message || "时间卡已创建。");
  updateContractButtonState();
}

async function ensureTimeCardBeforeBooking() {
  if (state.user?.user_id) return;
  await registerDemoUser({ silent: true });
}

async function refreshCurrentTimeCard() {
  const userId = state.user?.user_id || "demo-user";
  const result = await api(`/api/time-card?userId=${encodeURIComponent(userId)}`);
  state.timeCard = result.timeCard;
  sessionStorage.setItem("hotelTimeCard", JSON.stringify(state.timeCard));
  renderTimeCard();
}

function renderAll() {
  renderRooms();
  renderStoreMode();
  renderTimelines();
  renderHardware();
  renderMetrics();
  renderOrders();
  renderPricing();
  renderCleaning();
  renderAlerts();
  renderTimeCard();
  renderStores();
  $("#clockText").textContent = `系统时间 ${formatDateTime(state.dashboard.now)}`;
}

function renderStoreMode() {
  const banner = $("#storeModeBanner");
  if (!banner) return;
  if (state.storeMode === "B") {
    const r = state.crossStoreRecommendation || {};
    banner.innerHTML = `当前门店：<strong>B店 · 高铁站店</strong> · 距A店${r.distanceKm || 2.3}公里 · 自动跨店转单中`;
    banner.classList.add("active");
  } else {
    banner.textContent = "当前门店：A店 · 时间资产旗舰店";
    banner.classList.remove("active");
  }
}

function renderRooms() {
  const hasFilter = state.roomTypeFilter !== "all" && state.floorFilter !== "all";
  if (!hasFilter) {
    state.selectedRoomId = 0;
    $("#roomCards").innerHTML = "";
    updateCheckinRuleText();
    return;
  }
  const floorMatches = (room) => {
    if (state.floorFilter === "all") return true;
    return String(room.floor) === String(state.floorFilter);
  };
  const rooms = state.dashboard.rooms.filter((room) =>
    (state.roomTypeFilter === "all" || room.type === state.roomTypeFilter) && floorMatches(room)
  );
  if (!rooms.some((room) => room.id === state.selectedRoomId)) state.selectedRoomId = 0;
  $("#roomCards").innerHTML = rooms.map((room) => `
    <button class="room-card ${room.id === state.selectedRoomId ? "active" : ""}" data-room-id="${room.id}">
      <span>
        <strong>${room.number}房 · ${room.typeLabel}</strong><br />
        <small>${room.floor}层${room.floorBand} · ${room.window} · ${room.position}</small>
      </span>
      <span class="status-pill status-idle">${room.guestStatus || "可预订"}</span>
    </button>
  `).join("") || `<div class="empty-row">当前筛选下暂无房间，请更换房型或楼层</div>`;

  $$(".room-card").forEach((card) => card.addEventListener("click", async () => {
    state.userInteracted = true;
    state.selectedRoomId = Number(card.dataset.roomId);
    state.quote = null;
    state.storeMode = "A";
    state.crossStoreRecommendation = null;
    state.crossPromptKey = "";
    renderRooms();
    updateCheckinRuleText();
    renderStoreMode();
    await refreshQuote();
  }));
  updateCheckinRuleText();
}

function renderTimelines() {
  const rowHtml = (timeline, label) => {
    const idle = timeline.counts.idle || 0;
    const rangeText = timeline.rangeDays > 1 ? `${timeline.rangeDays}天连续颗粒` : "当天1440分钟颗粒";
    return `
      <div class="timeline-row">
        <strong>${label}</strong>
        <div class="timeline-track" title="${rangeText}">
          ${timeline.segments.map((seg) => `<span class="timeline-segment ${seg.state}" style="width:${seg.width}%"></span>`).join("")}
        </div>
        <span class="minute-count">${rangeText}<br />空闲${idle}分</span>
      </div>
    `;
  };
  const adminHtml = state.dashboard.timelines.map((timeline) => rowHtml(timeline, `${timeline.roomNumber}房`)).join("");
  if ($("#adminTimelines")) $("#adminTimelines").innerHTML = adminHtml;
}

function renderHardware() {
  $("#guestHardware").innerHTML = state.lastCheckinQr
    ? `
      <div class="guest-status-card">
        <strong>入住二维码已生成</strong>
        <p>到店后出示二维码即可办理入住。</p>
        <div class="qr-card">
          <span>入住二维码</span>
          <img class="qr-image" src="${qrSvgDataUri(state.lastCheckinQr)}" alt="入住二维码" />
          <small>凭证编号</small>
          <code>${escapeHtml(state.lastCheckinQr)}</code>
        </div>
      </div>
    `
    : `<div class="guest-status-card muted-card"><strong>请先完成订房</strong><p>支付完成后，系统会立即生成入住二维码。</p></div>`;

  const rooms = state.dashboard.rooms || [];
  const alertRoomIds = new Set((state.dashboard.alerts || []).filter((alert) => alert.status !== "resolved").map((alert) => alert.room_id).filter(Boolean));
  const roomGroups = [
    {
      key: "total",
      label: "房间总数",
      value: rooms.length,
      hint: "本店当前纳入时间资产管理的房间",
      status: "completed"
    },
    {
      key: "idle",
      label: "空闲",
      value: rooms.filter((room) => ["idle"].includes(room.status)).length,
      hint: "可直接进入销售时间池",
      status: "idle"
    },
    {
      key: "pending",
      label: "已预订",
      value: rooms.filter((room) => ["pending", "sold"].includes(room.status)).length,
      hint: "客户已付款锁定时段，等待到店办理入住",
      status: "pending"
    },
    {
      key: "occupied",
      label: "在住",
      value: rooms.filter((room) => ["occupied", "overtime"].includes(room.status)).length,
      hint: "客户已办理入住，订单正在使用中",
      status: "occupied"
    },
    {
      key: "cleaning",
      label: "清洁/待就绪",
      value: rooms.filter((room) => ["cleaning", "reserved_cleaning", "ready", "inspected"].includes(room.status)).length,
      hint: "保洁调度中的房间，完成后自动回到可售",
      status: "cleaning"
    },
    {
      key: "abnormal",
      label: "异常",
      value: rooms.filter((room) => ["maintenance", "overtime"].includes(room.status) || alertRoomIds.has(room.id)).length,
      hint: "维护、超时或未处理Alert房间",
      status: "overtime"
    }
  ];
  $("#roomOps").innerHTML = `
    <div class="room-status-dashboard">
      ${roomGroups.map((item) => `
        <div class="room-status-card ${item.key === "total" ? "main-card" : ""}">
          <span class="status-pill status-${item.status}">${item.label}</span>
          <strong>${item.value}</strong>
          <small>${item.hint}</small>
        </div>
      `).join("")}
    </div>
  `;
}

function renderMetrics() {
  const m = state.dashboard.metrics;
  $("#metricIncome").textContent = formatMoney(m.todayIncome);
  $("#metricOccupancy").textContent = `${m.occupancyRate}%`;
  $("#metricAvg").textContent = formatMoney(m.averageRoomPrice);
  $("#metricMinutes").textContent = `${m.soldMinutes}分`;

  const orderRevenue = state.dashboard.orders
    .slice(0, 5)
    .reverse()
    .map((o) => ({ label: `#${o.id}`, value: o.price + o.overtime_fee }));
  const max = Math.max(1, ...orderRevenue.map((x) => x.value));
  $("#barChart").innerHTML = orderRevenue.map((x) => `
    <div class="bar" style="height:${Math.max(8, (x.value / max) * 160)}px" title="${x.label} ${formatMoney(x.value)}"><span>${x.label}</span></div>
  `).join("");

  const total = m.soldMinutes + m.idleMinutes;
  const degree = total ? (m.soldMinutes / total) * 360 : 0;
  $("#pieChart").style.setProperty("--sold-deg", `${degree}deg`);
}

function renderOrders() {
  const paymentsByOrder = Object.fromEntries((state.dashboard.payments || []).filter((p) => p.order_id).map((p) => [p.order_id, p]));
  $("#ordersTable").innerHTML = state.dashboard.orders.map((order) => `
    <div class="order-row">
      <div>
        <strong>#${order.id} · ${order.room_number}房 · ${escapeHtml(order.guest)}</strong><br />
        <span>${formatDateTime(order.start_at)} - ${formatDateTime(order.end_at)}</span>
        ${paymentsByOrder[order.id] ? `<small class="payment-tag">Mock支付：${escapeHtml(paymentsByOrder[order.id].status)} · ${escapeHtml(paymentsByOrder[order.id].transaction_id || "无交易号")} · 二维码${paymentsByOrder[order.id].checkin_qr ? "已生成" : "未生成"}</small>` : ""}
      </div>
      <span class="status-pill status-${order.status}">${statusText[order.status]}</span>
      <span>${formatMoney(order.price)} + 押金${formatMoney(order.deposit)}<br />${String(order.note || "").includes("押金自动转为续住房费") ? "押金转房费" : "超时费"} ${formatMoney(order.overtime_fee)}</span>
      <div class="order-actions">
        ${order.status === "pending" ? `<button class="mini-button ok" data-action="checkin" data-id="${order.id}">办理入住/模拟到店</button>` : ""}
        ${["ongoing", "overtime"].includes(order.status) ? `<button class="mini-button ok" data-action="checkout" data-id="${order.id}">退房</button><button class="mini-button warn" data-action="overtime" data-id="${order.id}">超时处理</button>` : ""}
        <button class="mini-button" data-action="contract" data-id="${order.id}">看契约</button>
      </div>
    </div>
  `).join("");
}

function renderPricing() {
  const roomPrices = state.dashboard.rooms.reduce((acc, room) => {
    acc[room.type] = room.base_price;
    return acc;
  }, {});
  const priceRows = Object.entries(roomPrices).map(([type, value]) => `
    <label class="pricing-row">
      <span>${typeText[type]}基础价</span>
      <input data-price-type="${type}" type="number" min="1" step="1" value="${value}" />
    </label>
  `).join("");
  const factorRows = state.dashboard.pricing.map((item) => `
    <label class="pricing-row">
      <span>${escapeHtml(item.label)}</span>
      <input data-factor-key="${item.key}" type="number" min="0.1" step="0.05" value="${item.value}" />
    </label>
  `).join("");
  $("#pricingForm").innerHTML = priceRows + factorRows;
}

function alertIcon(severity) {
  return severity === "critical" ? "🔴" : severity === "warning" ? "🟡" : "🟢";
}

function simulatedAlertRoomId() {
  const rooms = state.dashboard?.rooms || [];
  const preferred = rooms.find((room) => String(room.number) === "203") || rooms[0];
  return preferred?.id || 1;
}

function renderAlerts() {
  const alerts = state.dashboard.alerts || [];
  const open = alerts.filter((a) => a.status !== "resolved");
  const latest = state.dashboard.latestAlert;
  const banner = $("#alertBanner");
  if (open.length) {
    const top = open[0];
    banner.classList.remove("hidden");
    banner.classList.toggle("critical", top.severity === "critical");
    banner.innerHTML = `${alertIcon(top.severity)} ${top.room_number ? `${top.room_number}房 · ` : ""}${top.type} · ${formatDateTime(top.created_at)} <span>已同步：${escapeHtml(top.recipients || "前台、运维")}</span> <button class="mini-button ok" data-action="alertAck" data-id="${top.id}">前台/运维确认</button><button class="mini-button warn" data-action="alertResolve" data-id="${top.id}">一键处理</button>`;
  } else {
    banner.classList.add("hidden");
  }
  if (latest && latest.id !== state.lastAlertId) {
    state.lastAlertId = latest.id;
  }
  $("#alertsList").innerHTML = alerts.map((alert) => `
    <div class="alert-row ${alert.severity}">
      <div>
        <strong>${alertIcon(alert.severity)} ${alert.room_number ? `${alert.room_number}房 · ` : ""}${alert.type}</strong>
        <span class="status-pill status-${alert.status === "resolved" ? "completed" : alert.status === "acknowledged" ? "pending" : "overtime"}">${alert.status === "open" ? "待确认" : alert.status === "acknowledged" ? "处理中" : "已处理"}</span>
        ${alert.escalated ? `<em class="priority urgent">已升级前台/运维/保安/店长</em>` : ""}<br />
        <span>${escapeHtml(alert.message)} · 接收方：${escapeHtml(alert.recipients || "前台、运维")} · 发生 ${formatDateTime(alert.created_at)} ${alert.result ? `· 结果：${escapeHtml(alert.result)}` : ""}</span>
      </div>
      <div class="ops-actions">
        ${alert.status === "open" ? `<button class="mini-button ok" data-action="alertAck" data-id="${alert.id}">前台/运维确认</button>` : ""}
        ${alert.status !== "resolved" ? `<button class="mini-button warn" data-action="alertEscalate" data-id="${alert.id}">升级</button><button class="mini-button ok" data-action="alertResolve" data-id="${alert.id}">一键处理</button>` : `<span class="status-pill status-completed">已归档</span>`}
      </div>
    </div>
  `).join("") || `<div class="empty-row">暂无异常</div>`;
}

function renderStores() {
  const summary = state.dashboard.stores || {};
  const stores = summary.stores || [];
  const zone = summary.crossStoreZone || {};
  $("#storeRoleText").textContent = summary.role || "";
  $("#storeTotalRooms").textContent = summary.totalRooms || 0;
  $("#storeTotalIncome").textContent = formatMoney(summary.totalIncome || 0);
  $("#storeAvgOccupancy").textContent = `${summary.avgOccupancy || 0}%`;
  $("#storeAlertCount").textContent = stores.filter((s) => s.alerts > 0).length;
  $("#crossMetricCount").textContent = zone.todayOrders || 0;
  $("#crossMetricCommission").textContent = formatMoney(zone.sourceCommissionTotal || 0);
  $("#crossMetricHost").textContent = formatMoney(zone.receivingRevenueTotal || 0);
  $("#crossMetricPending").textContent = zone.pendingSettlement || 0;
  renderStoreTransferBanner(summary.latestTransferNotice);
  $("#storesList").innerHTML = stores.map((store) => `
    <button class="store-card" type="button" data-action="storeOpen" data-id="${store.id}">
      <strong>${store.alerts ? "🔴" : "🟢"} ${store.name}</strong>
      <span>${store.address}</span>
      <span>房间${store.rooms}间 · 入住率${store.occupancyRate}% · 今日${formatMoney(store.todayIncome)} · 异常${store.alerts}</span>
      <small>${store.role}</small>
    </button>
  `).join("");
  $("#storeIncomeRanking").innerHTML = (summary.incomeRanking || []).map((s, i) => `<div class="cleaning-row compact-row"><div><strong>${i + 1}. ${s.name}</strong><br /><span>${formatMoney(s.todayIncome)}</span></div></div>`).join("");
  $("#storeOccupancyRanking").innerHTML = (summary.occupancyRanking || []).map((s, i) => `<div class="cleaning-row compact-row"><div><strong>${i + 1}. ${s.name}</strong><br /><span>入住率${s.occupancyRate}%</span></div></div>`).join("");
  const t = summary.transferRecommendation || {};
  const finance = summary.transferFinance || {};
  $("#transferBox").innerHTML = `
    <strong>跨店调度推荐</strong>
    <p>${escapeHtml(t.reason || "")}：推荐 ${escapeHtml(t.to || "")} 的 ${escapeHtml(t.room || "")}，距A店${t.distanceKm || 2.3}公里。</p>
    <p>收益分配：订单${formatMoney(t.estimatedOrder || 0)}，出单店抽成${t.commissionRate || 10}% = ${formatMoney(t.commission || 0)}，接待店收入${formatMoney(t.partnerRevenue || 0)}</p>
    <p>今日跨店：${finance.count || 0}单 · 总额${formatMoney(finance.amount || 0)} · A店抽成${formatMoney(finance.commissionAmount || 0)} · B店收入${formatMoney(finance.partnerRevenue || 0)} · A店候补${summary.waitlistCount || 0}人</p>
    <em class="status-pill status-completed">客户提交后系统自动确认，无需后台手动操作</em>
  `;
  $("#aStoreTransferRecords").innerHTML = (summary.aStoreRecords || []).map((record) => `
    <div class="cleaning-row compact-row transfer-record">
      <div>
        <strong>✅ ${record.title} #${record.id}</strong>
        <em class="priority">待结算</em><br />
        <span>${escapeHtml(record.room || "")} · ${escapeHtml(record.guest || "")} · ${formatDateTime(record.startAt)} - ${formatDateTime(record.endAt)}</span><br />
        <span>订单${formatMoney(record.amount)} · A店分成${formatMoney(record.commissionAmount)} · 状态：${record.settlementStatus === "pending" ? "待结算" : "已结算"}</span>
      </div>
    </div>
  `).join("") || `<div class="empty-row">暂无跨店成功记录；客户在用户端选择B店并付款后会自动同步到这里。</div>`;
  $("#bStoreTransferOrders").innerHTML = (summary.bStoreOrders || []).map((order) => `
    <div class="cleaning-row compact-row transfer-record">
      <div>
        <strong>🏨 #${order.id} · ${escapeHtml(order.room_label)} · ${escapeHtml(order.guest)}</strong>
        <span class="status-pill status-sold">${order.tag}</span><br />
        <span>${escapeHtml(order.noticeTitle)} · 联系方式 ${escapeHtml(order.guest_contact || "138****1010")} · 预计${order.expected_arrival_minutes || 20}分钟后到店</span><br />
        <span>${formatDateTime(order.start_at)} - ${formatDateTime(order.end_at)} · 价格${formatMoney(order.amount)} · 来源：${escapeHtml(order.sourceStore)} · 分成：${order.splitText}</span><br />
        <span>倒计时：距离到店还有${order.minutesToArrival ?? 0}分钟 · 房间状态：已预订-跨店 / ${order.roomStatus} · 用户端显示“已售/隐藏”</span>
      </div>
    </div>
  `).join("") || `<div class="empty-row">B店暂无跨店接待订单。</div>`;
}

function renderStoreTransferBanner(order) {
  const banner = $("#storeTransferBanner");
  if (!banner) return;
  if (!order) {
    banner.classList.add("hidden");
    return;
  }
  banner.classList.remove("hidden");
  banner.classList.add("critical");
  banner.innerHTML = `
    🔔 跨店调度订单：来自A店
    <span>${escapeHtml(order.room_label)} · ${formatDateTime(order.start_at)} - ${formatDateTime(order.end_at)} · ${formatMoney(order.amount)} · 联系方式 ${escapeHtml(order.guest_contact || "138****1010")} · 距离到店${order.minutesToArrival ?? 0}分钟</span>
    <button class="mini-button ok" data-action="storeOpen" data-id="B">查看B店</button>
  `;
  if (order.id !== state.lastTransferId) {
    state.lastTransferId = order.id;
  }
}

function renderTimeCard() {
  const adminTimeCard = state.timeCard || state.dashboard?.stores?.timeCard || {};
  const adminCard = adminTimeCard.card || {};
  const adminBenefits = adminCard.benefits || {};
  const adminLedger = adminTimeCard.ledger || [];
  const adminCardHtml = `
    <strong>${escapeHtml(adminCard.time_card_id || "系统自动创建中")}</strong>
    <p>绑定账号：${escapeHtml(maskPhone(state.user?.phone))}</p>
    <p>状态：${adminCard.status === "normal" ? "正常" : escapeHtml(adminCard.status || "待创建")} · 补偿权益${formatMoney(adminBenefits.compensation || 0)} · 时间权益${adminBenefits.time || 0}</p>
    <div class="time-card-ledger-list">
      ${adminLedger.slice(0, 6).map((item) => `<small class="time-card-ledger">流水${escapeHtml(item.ledger_no)} · ${escapeHtml(item.action)} · ${escapeHtml(item.benefit_type)} ${formatMoney(item.quantity)} · ${escapeHtml(item.reason || item.source || "")}</small>`).join("") || `<small class="time-card-ledger">暂无流水；注册、补偿、抵扣、人工调整都会记录在这里。</small>`}
    </div>
  `;
  if ($("#adminTimeCardBox")) {
    $("#adminTimeCardBox").innerHTML = `
      <div class="time-card-admin-grid">
        <div class="time-card-big">${adminCardHtml}</div>
        <div>
          <strong>模块调用关系</strong>
          <p>${(adminTimeCard.moduleOrder || []).join(" → ")}</p>
          <small>订单、支付、补偿、总部运营和前台服务都会读取时间卡，保证用户权益有记录、可追溯。</small>
        </div>
      </div>
    `;
  }
  if ($("#registeredUserBox")) {
    const registered = Boolean(state.user?.user_id);
    $("#registeredUserBox").classList.toggle("hidden", !registered);
    $("#registerForm").classList.toggle("hidden", registered);
    if (registered) {
      $("#registeredUserBox").innerHTML = `入住人信息已确认`;
    }
  }
}

function renderCleaning() {
  const metrics = state.dashboard.cleaningMetrics || {};
  $("#cleanMetricTotal").textContent = metrics.total || 0;
  $("#cleanMetricPending").textContent = metrics.pending || 0;
  $("#cleanMetricProcessing").textContent = metrics.processing || 0;
  $("#cleanMetricCompleted").textContent = metrics.completed || 0;
  $("#cleanMetricAvg").textContent = `${metrics.averageMinutes || 0}分`;

  const renderTask = (task) => `
    <div class="cleaning-row ${task.minutes_to_checkin !== null && task.minutes_to_checkin < 5 && !["completed","released"].includes(task.status) ? "urgent-clean" : ""}">
      <div>
        <strong>工单#${task.id} · ${task.room_number}房 · ${cleaningStatusText[task.status] || task.status}</strong>
        <em class="priority ${task.priority === "urgent" ? "urgent" : ""}">${cleaningPriorityText[task.priority] || task.priority}</em><br />
        <span>
          负责人：${escapeHtml(task.assignee || "系统待分配")}
          · 房型：${escapeHtml(task.roomTypeLabel || "")}
          · 
          ${task.order_earliest_checkin_at ? `安全截止 ${formatDateTime(task.order_earliest_checkin_at)} · ` : ""}
          ${task.minutes_to_checkin !== null && task.minutes_to_checkin >= 0 ? `倒计时${task.minutes_to_checkin}分钟 · ` : ""}
          订单结束 ${formatDateTime(task.ended_at || task.order_end_at || task.scheduled_at)}
          · SLA${task.estimated_minutes}分钟
          ${task.actual_minutes ? `· 实际${task.actual_minutes}分钟` : ""}
          ${task.target_minutes ? `· 系统目标${task.target_minutes}分钟` : ""}
        </span>
        <small class="time-card-ledger">${escapeHtml(task.dispatch_label || "退房后自动派单；后台可确认接单、开始清洁、完成并上架。")}</small>
      </div>
      <div class="ops-actions">${cleaningActions(task)}</div>
    </div>
  `;

  const pending = state.dashboard.cleaningTasks.filter((task) => ["pending"].includes(task.status));
  const working = state.dashboard.cleaningTasks.filter((task) => ["accepted", "cleaning"].includes(task.status));
  const finished = state.dashboard.cleaningTasks.filter((task) => task.status === "released");
  const history = state.dashboard.cleaningTasks.filter((task) => task.status === "released");

  $("#cleaningPending").innerHTML = pending.map(renderTask).join("") || `<div class="empty-row">暂无待接单工单；客户退房后会自动生成。</div>`;
  $("#cleaningWorking").innerHTML = working.map(renderTask).join("") || `<div class="empty-row">暂无已接单/清洁中工单</div>`;
  $("#cleaningFinished").innerHTML = finished.slice(0, 5).map(renderTask).join("") || `<div class="empty-row">暂无已恢复可售记录</div>`;
  $("#cleaningList").innerHTML = history.slice(0, 5).map(renderTask).join("") || `<div class="empty-row">暂无历史工单</div>`;
  $("#cleaningRanking").innerHTML = (metrics.ranking || []).map((worker, index) => `
    <div class="cleaning-row compact-row">
      <div><strong>${index + 1}. ${escapeHtml(worker.name)}</strong><br /><span>完成${worker.count}单 · 平均${worker.avg}分钟/间</span></div>
      <span class="status-pill status-completed">效率${worker.avg ? Math.max(60, Math.round(100 - worker.avg)) : 90}</span>
    </div>
  `).join("") || `<div class="empty-row">完成工单后生成排名</div>`;
}

function cleaningActions(task) {
  if (task.status === "pending") return `<button class="mini-button ok" data-action="cleaningAccept" data-id="${task.id}">确认接单</button>`;
  if (task.status === "accepted") return `<button class="mini-button ok" data-action="cleaningStart" data-id="${task.id}">开始清洁</button>`;
  if (task.status === "cleaning") return `<button class="mini-button warn" data-action="cleaningFinish" data-id="${task.id}">完成并上架</button>`;
  return `<span class="status-pill status-completed">已完成上架</span>`;
}

function updateContractButtonState() {
  $("#openContract").disabled = !state.quote;
  $("#openContract").textContent = "生成契约并支付";
}

function selectedRoom() {
  return state.dashboard?.rooms?.find((room) => room.id === state.selectedRoomId);
}

function updateCheckinRuleText() {
  const room = selectedRoom();
  if ($("#selectedRoomRule") && room) $("#selectedRoomRule").textContent = `您已选择${room.number}房，该房间将在预订时段为您保留`;
}

async function refreshQuote() {
  const start = state.startMinute;
  const end = state.endMinute;
  ensureEndDate();
  updateTimeUi();
  $("#openContract").disabled = true;
  state.quote = null;

  if (!state.selectedRoomId) {
    $("#quotePrice").textContent = "请选择房间";
    $("#quoteExplain").textContent = "请先选择房型和楼层，再选择具体房间。确认房间后会显示本次入住总价。";
    return;
  }

  if ($("#endDate").value < $("#bookingDate").value) {
    $("#quotePrice").textContent = "结束时间要晚于开始时间";
    $("#quoteExplain").textContent = "结束日期不能早于开始日期。";
    return;
  }

  if (state.storeMode === "B") {
    await refreshBStoreQuote();
    return;
  }

  try {
    const q = await api("/api/quote", {
      method: "POST",
      body: {
        roomId: state.selectedRoomId,
        date: $("#bookingDate").value,
        endDate: $("#endDate").value,
        startMinute: start,
        endMinute: end,
        expectedArrivalMinutes: expectedArrivalMinutes()
      }
    });
    state.quote = q;
    $("#quotePrice").textContent = formatMoney(q.price);
    const days = Math.floor(q.minutes / 1440);
    const hours = Math.floor((q.minutes % 1440) / 60);
    const mins = q.minutes % 60;
    const durationText = `${days ? `${days}天` : ""}${hours ? `${hours}小时` : ""}${mins ? `${mins}分钟` : ""}` || `${q.minutes}分钟`;
    $("#quoteExplain").innerHTML = `${q.room.number}房 · ${q.room.typeLabel || typeText[q.room.type]} · ${q.spatial.floor}层${q.spatial.floorBand} · ${q.spatial.window} · ${q.spatial.position}<br />入住时长：${durationText}（${q.minutes}分钟） · 本次需付${formatMoney(q.payTotal)}，已含押金100元`;
    updateContractButtonState();
  } catch (error) {
    $("#quotePrice").textContent = "为您推荐可订房间";
    $("#quoteExplain").textContent = "";
    if (state.userInteracted && state.storeMode === "A") await showCrossStoreRecommendation(error.message);
  }
}

function selectedTimePayload(extra = {}) {
  const room = selectedRoom();
  const manualDistance = Number($("#distanceKmInput")?.value || 2.3);
  return {
    roomId: state.selectedRoomId,
    roomType: room?.type || "standard",
    date: $("#bookingDate").value,
    endDate: $("#endDate").value,
    startMinute: state.startMinute,
    endMinute: state.endMinute,
    expectedArrivalMinutes: expectedArrivalMinutes(),
    distanceKm: Math.max(0.5, Math.min(20, Number.isFinite(manualDistance) ? manualDistance : 2.3)),
    guest: state.user?.name || "现场演示客户",
    userId: state.user?.user_id || "demo-user",
    ...extra
  };
}

async function refreshBStoreQuote() {
  const result = await api("/api/stores/recommend", { method: "POST", body: selectedTimePayload() });
  const r = result.recommendation;
  state.crossStoreRecommendation = r;
  state.compensationType = state.compensationType || "traffic";
  state.quote = {
    price: r.estimatedOrder,
    payTotal: r.estimatedOrder + 100,
    minutes: r.minutes,
    contract: r.contract
  };
  $("#quotePrice").textContent = formatMoney(r.estimatedOrder);
  $("#quoteExplain").textContent = `${r.to} · ${r.roomType} · 距您${r.distanceKm}公里 · ${arrivalLabel(r.expectedArrivalMinutes)}。`;
  updateContractButtonState();
  renderStoreMode();
}

async function showCrossStoreRecommendation(reason = "", options = {}) {
  const distanceValue = selectedTimePayload().distanceKm;
  const key = `${state.selectedRoomId || "demo"}|${$("#bookingDate").value}|${$("#endDate").value}|${state.startMinute}|${state.endMinute}|${distanceValue}|${reason}`;
  if (state.storeMode !== "A" || (!options.force && state.crossPromptKey === key)) return;
  state.crossPromptKey = key;
  const result = await api("/api/stores/recommend", { method: "POST", body: selectedTimePayload() });
  const r = result.recommendation;
  state.crossStoreRecommendation = r;
  state.compensationType = "traffic";
  $("#crossStoreTitle").textContent = "为您推荐可订房间";
  $("#crossStoreBody").innerHTML = `
    <div class="recommend-card">
      <strong>${escapeHtml(r.to)} · ${escapeHtml(r.roomType)}</strong>
      <span>距您${r.distanceKm}公里 · 当前所选时间可订</span>
      <span>房费 ${formatMoney(r.estimatedOrder)}，含押金合计 ${formatMoney(r.estimatedOrder + 100)}</span>
      <span>${arrivalLabel(r.expectedArrivalMinutes)} · 最早入住 ${formatDateTime(r.earliestCheckinAt)}</span>
    </div>
    <h3 class="benefit-title">请选择一项权益</h3>
    <div class="compensation-options">
      ${(r.compensationOptions || []).map((option) => `
        <button type="button" class="compensation-option ${option.type === state.compensationType ? "active" : ""}" data-compensation-type="${option.type}">
          <strong>${escapeHtml(option.title)} · ${escapeHtml(option.text)}</strong>
          <span>${escapeHtml(option.description)}</span>
        </button>
      `).join("")}
    </div>
  `;
  if (!$("#crossStoreDialog").open) $("#crossStoreDialog").showModal();
}

function refreshCrossStoreDistanceDebounced() {
  window.clearTimeout(state.crossStoreDistanceTimer);
  state.crossStoreDistanceTimer = window.setTimeout(async () => {
    if ($("#crossStoreDialog")?.open && state.storeMode === "A") {
      await showCrossStoreRecommendation("当前门店该时段暂不可订", { force: true });
    }
  }, 250);
}

function showContract(contract) {
  const minutes = contract.expectedArrivalMinutes ?? expectedArrivalMinutes();
  $("#agreeContract").checked = false;
  $("#confirmOrder").disabled = false;
  $("#confirmOrder").textContent = "确认支付";
  renderPaymentMethods();
  const checkinRules = contract.checkinRules || [];
  const overtimeRules = contract.rules || [];
  $("#contractBody").innerHTML = `
    <section class="contract-section">
      <h3>订单信息</h3>
      <div class="contract-info-grid">
        <div><small>房间</small><strong>${contract.roomNumber}房 · ${contract.roomType}</strong><span>${contract.spatial.floor}层${contract.spatial.floorBand} · ${contract.spatial.window} · ${contract.spatial.position}</span></div>
        <div><small>起止时间</small><strong>${formatDateTime(contract.startAt)} - ${formatDateTime(contract.endAt)}</strong><span>该时段将为您锁定，不与其他订单冲突</span></div>
        <div><small>预计到店</small><strong>${arrivalLabel(minutes)}</strong><span>最早入住 ${formatDateTime(contract.earliestCheckinAt || earliestArrivalAt().toISOString())}</span></div>
        <div><small>费用</small><strong>${formatMoney(contract.price)} + 押金${formatMoney(contract.deposit)}</strong><span>押金按契约规则结算或转为续住房费</span></div>
      </div>
    </section>
    <section class="contract-section">
      <h3>入住规则</h3>
      <ol class="contract-rule-list">
        ${checkinRules.map((rule) => `<li>${escapeHtml(rule)}</li>`).join("")}
      </ol>
    </section>
    <section class="contract-section emphasis-section">
      <h3>超时规则</h3>
      <ol class="contract-rule-list">
        ${overtimeRules.map((rule) => `<li>${escapeHtml(rule)}</li>`).join("")}
      </ol>
    </section>
  `;
  $("#contractDialog").showModal();
}

function arrivalLabel(minutes) {
  const value = Math.max(0, Number(minutes || 0));
  return value === 0 ? "现在到店/已跳过填写" : `预计${value}分钟后到店`;
}

async function confirmOrder(event) {
  event.preventDefault();
  if (!state.quote) return;
  if (!$("#agreeContract")?.checked) {
    toast("请先勾选同意时间契约，再确认支付。");
    return;
  }
  const payButton = $("#confirmOrder");
  const originalText = payButton?.textContent || "确认支付";
  try {
    if (payButton) {
      payButton.disabled = true;
      payButton.textContent = "支付处理中…";
    }
    if (state.storeMode === "B") {
      const result = await api("/api/stores/transfer", {
        method: "POST",
        body: selectedTimePayload({
          amount: state.quote.price,
          lockId: state.crossStoreRecommendation?.lockId,
          compensationType: state.compensationType
        })
      });
      state.dashboard = result.dashboard;
      if (result.timeCard) {
        state.timeCard = result.timeCard;
        sessionStorage.setItem("hotelTimeCard", JSON.stringify(state.timeCard));
      }
      state.lastCheckinQr = result.checkinQr || "";
      if (state.lastCheckinQr) sessionStorage.setItem("lastCheckinQr", state.lastCheckinQr);
      $("#contractDialog").close();
      markFlowActive(["flowOrder", "flowCheckin", "flowUse"]);
      toast("支付成功：入住二维码已生成。");
      renderAll();
      await refreshBStoreQuote();
      return;
    }
    state.dashboard = (await api("/api/orders", {
      method: "POST",
      body: {
        roomId: state.selectedRoomId,
        date: $("#bookingDate").value,
        endDate: $("#endDate").value,
        startMinute: state.startMinute,
        endMinute: state.endMinute,
        expectedArrivalMinutes: expectedArrivalMinutes(),
        guest: state.user?.name || "现场演示客户",
        userId: state.user?.user_id || "demo-user",
        paymentMethod: state.paymentMethod,
        // 客户端模拟真实支付：用户只点击“确认支付”，后端Mock支付默认成功。
        // 支付失败/取消保留在后端接口能力中，用于后台测试，不放进客户主流程。
        paymentScenario: "success"
      }
    }));
    const result = state.dashboard;
    state.dashboard = result.dashboard;
    $("#contractDialog").close();
    if (!result.ok) {
      toast(result.message || "支付未完成，订单未生成。");
      renderAll();
      await refreshQuote();
      return;
    }
    state.guestHardwareRoomId = state.selectedRoomId;
    state.lastCheckinQr = result.checkinQr || "";
    sessionStorage.setItem("guestHardwareRoomId", String(state.selectedRoomId));
    if (state.lastCheckinQr) sessionStorage.setItem("lastCheckinQr", state.lastCheckinQr);
    markFlowActive(["flowOrder", "flowCheckin", "flowUse"]);
    toast(result.message || "支付成功：订单已生成，入住凭证已生成。");
    renderAll();
    await refreshQuote();
  } catch (error) {
    toast(error.message);
  } finally {
    if (payButton && $("#contractDialog")?.open) {
      payButton.textContent = originalText;
      payButton.disabled = false;
    }
  }
}

function renderPaymentMethods() {
  $$(".payment-method").forEach((button) => {
    const selected = button.dataset.paymentMethod === state.paymentMethod;
    button.classList.toggle("active", selected);
    button.setAttribute("aria-pressed", selected ? "true" : "false");
  });
}

async function handleAction(action, id, event) {
  try {
    const date = $("#bookingDate").value;
    if (action === "checkin") {
      const targetOrder = state.dashboard.orders.find((order) => order.id === Number(id));
      state.dashboard = await api(`/api/orders/${id}/checkin`, { method: "POST", body: { date, force: true } });
      if (targetOrder) {
        state.guestHardwareRoomId = targetOrder.room_id;
        sessionStorage.setItem("guestHardwareRoomId", String(targetOrder.room_id));
      }
      toast("已办理入住。");
    }
    if (action === "checkout") {
      const targetOrder = state.dashboard.orders.find((order) => order.id === Number(id));
      state.dashboard = await api(`/api/orders/${id}/checkout`, { method: "POST", body: { date, mode: "early" } });
      if (targetOrder && targetOrder.room_id === state.guestHardwareRoomId) {
        state.guestHardwareRoomId = 0;
        state.lastCheckinQr = "";
        sessionStorage.removeItem("guestHardwareRoomId");
        sessionStorage.removeItem("lastCheckinQr");
      }
      markFlowActive(["flowEnd"]);
      notifyCleaning(state.dashboard.latestCleaningNotice);
      toast("已完成离店。");
    }
    if (action === "overtime") {
      state.dashboard = await api(`/api/orders/${id}/overtime`, { method: "POST", body: { date, minutes: 20 } });
      markFlowActive(["flowEnd"]);
      notifyCleaning(state.dashboard.latestCleaningNotice);
      toast("已按超时20分钟规则将押金转为续住房费，并自动开启12小时续住周期。");
    }
    if (action.startsWith("cleaning")) {
      const actionMap = {
        cleaning: "inspect",
        cleaningAccept: "accept",
        cleaningStart: "start",
        cleaningFinish: "finish",
        cleaningInspect: "inspect",
        cleaningRelease: "release"
      };
      state.dashboard = await api(`/api/cleaning/${id}/action`, { method: "POST", body: { date, action: actionMap[action] } });
      const textMap = {
        cleaningAccept: "保洁已接单：负责人已确认。",
        cleaningStart: "保洁已开始：房间状态为清洁中。",
        cleaningFinish: "清洁完成并上架：房间已恢复可售。",
        cleaningInspect: "房间已自动恢复可售。",
        cleaningRelease: "房间已恢复空闲，可重新销售。"
      };
      toast(textMap[action] || "保洁状态已更新。");
    }
    if (action === "contract") {
      const order = state.dashboard.orders.find((o) => o.id === Number(id));
      showContract(order.contract);
      $("#confirmOrder").disabled = true;
    }
    if (action === "simulateAlert") {
      const type = event?.target?.dataset?.type || "安全警报";
      state.dashboard = await api("/api/alerts/simulate", { method: "POST", body: { date, type, roomId: simulatedAlertRoomId() } });
      notifyAlert(state.dashboard.latestAlert);
      toast(`已模拟异常：${type}`);
    }
    if (action.startsWith("alert")) {
      const actionMap = { alertAck: "ack", alertResolve: "resolve", alertEscalate: "escalate" };
      state.dashboard = await api(`/api/alerts/${id}/action`, { method: "POST", body: { date, action: actionMap[action], method: "前台处理", result: "已通知岗位并记录处理结果" } });
      toast(action === "alertResolve" ? "异常已处理并归档。" : action === "alertEscalate" ? "已升级通知店长/保安。" : "前台已确认异常。");
    }
    if (action === "storeOpen") {
      toast(`已进入${id}店视角：店长看本店，前台可处理本店异常。`);
    }
    renderAll();
    await refreshQuote();
  } catch (error) {
    toast(error.message);
  }
}

function toast(message) {
  $("#toast").textContent = message;
  $("#toast").classList.remove("hidden");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => $("#toast").classList.add("hidden"), 3600);
}

function notifyCleaning(task) {
  if (!task) return;
  const popup = $("#notifyPopup");
  popup.innerHTML = `🔔 新保洁工单：${task.room_number}房 · ${cleaningPriorityText[task.priority] || task.priority} · 预计${task.estimated_minutes}分钟<br /><small>保洁、前台、管理端已同步提醒</small>`;
  popup.classList.remove("hidden");
  clearTimeout(window.notifyTimer);
  window.notifyTimer = setTimeout(() => popup.classList.add("hidden"), 5000);
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = task.priority === "urgent" ? 880 : 660;
    gain.gain.value = 0.04;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    setTimeout(() => { osc.stop(); ctx.close(); }, 180);
  } catch {}
}

function beep(frequency = 880) {
  if (!state.alertSound) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = frequency;
    gain.gain.value = 0.05;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    setTimeout(() => { osc.stop(); ctx.close(); }, 220);
  } catch {}
}

function notifyAlert(alert) {
  if (!alert) return;
  const popup = $("#notifyPopup");
  popup.innerHTML = `${alertIcon(alert.severity)} 异常预警：${alert.room_number ? `${alert.room_number}房 · ` : ""}${alert.type}<br /><small>${escapeHtml(alert.message)} · 已同步${escapeHtml(alert.recipients || "前台、运维")}联动处理</small>`;
  popup.classList.remove("hidden");
  clearTimeout(window.notifyTimer);
  window.notifyTimer = setTimeout(() => popup.classList.add("hidden"), 6000);
  beep(alert.severity === "critical" ? 980 : 720);
}

function notifyTransfer(order) {
  if (!order) return;
  const popup = $("#notifyPopup");
  popup.innerHTML = `🔔 跨店调度订单：来自A店<br /><small>${escapeHtml(order.room_label)} · ${formatDateTime(order.start_at)} - ${formatDateTime(order.end_at)} · ${formatMoney(order.amount)} · 联系方式 ${escapeHtml(order.guest_contact || "138****1010")}</small>`;
  popup.classList.remove("hidden");
  clearTimeout(window.notifyTimer);
  window.notifyTimer = setTimeout(() => popup.classList.add("hidden"), 6500);
  beep(920);
}

function bindEvents() {
  $$(".tab").forEach((tab) => tab.addEventListener("click", () => {
    $$(".tab").forEach((x) => x.classList.remove("active"));
    tab.classList.add("active");
    $("#guestView").classList.toggle("hidden", tab.dataset.view !== "guest");
    $("#adminView").classList.toggle("hidden", tab.dataset.view !== "admin");
  }));

  $$(".admin-nav").forEach((button) => button.addEventListener("click", () => {
    $$(".admin-nav").forEach((x) => x.classList.remove("active"));
    button.classList.add("active");
    $$(".admin-page").forEach((page) => page.classList.add("hidden"));
    $(`#admin${button.dataset.admin[0].toUpperCase()}${button.dataset.admin.slice(1)}`).classList.remove("hidden");
  }));

  $("#bookingDate").addEventListener("change", async () => {
    state.userInteracted = true;
    ensureEndDate();
    renderTimeWheel("#startWheel", "start");
    renderTimeWheel("#endWheel", "end");
    setWheelValue("#startWheel", $("#bookingDate").value, state.startMinute);
    setWheelValue("#endWheel", $("#endDate").value, state.endMinute);
    await loadDashboard();
  });
  if ($("#registerUser")) $("#registerUser").addEventListener("click", registerDemoUser);
  if ($("#simulateCrossStore")) $("#simulateCrossStore").addEventListener("click", async () => {
    state.userInteracted = true;
    state.storeMode = "A";
    state.crossPromptKey = "";
    await showCrossStoreRecommendation("当前门店该时段暂不可订");
  });
  $("#issueTimeCardBenefit").addEventListener("click", async () => {
    const userId = state.user?.user_id || "demo-user";
    const result = await api("/api/time-card/adjust", {
      method: "POST",
      body: {
        userId,
        benefitType: "compensation",
        action: "issue",
        quantity: 20,
        source: "frontdesk_service",
        operator: "前台/客服",
        reason: "演示：服务补偿发放至时间卡"
      }
    });
    state.timeCard = result.timeCard;
    sessionStorage.setItem("hotelTimeCard", JSON.stringify(state.timeCard));
    renderTimeCard();
    toast("已向时间卡发放¥20补偿权益。");
  });
  $("#endDate").addEventListener("change", async () => {
    state.userInteracted = true;
    ensureEndDate();
    renderTimeWheel("#startWheel", "start");
    renderTimeWheel("#endWheel", "end");
    setWheelValue("#startWheel", $("#bookingDate").value, state.startMinute);
    setWheelValue("#endWheel", $("#endDate").value, state.endMinute);
    await loadDashboard();
  });
  $("#roomTypeFilter").addEventListener("change", async () => {
    state.userInteracted = true;
    state.roomTypeFilter = $("#roomTypeFilter").value;
    state.quote = null;
    renderRooms();
    await refreshQuote();
  });
  $("#floorFilter").addEventListener("change", async () => {
    state.userInteracted = true;
    state.floorFilter = $("#floorFilter").value;
    state.quote = null;
    renderRooms();
    await refreshQuote();
  });
  $("#openContract").addEventListener("click", openRulesDialog);
  $("#agreeCheckinRules").addEventListener("change", () => {
    $("#confirmRules").disabled = !$("#agreeCheckinRules").checked;
  });
  $("#confirmRules").addEventListener("click", () => {
    if (!$("#agreeCheckinRules").checked) {
      toast("请先勾选“我已阅读并同意入住规则”。");
      return;
    }
    $("#rulesDialog").close();
    openArrivalDialog();
  });
  $("#agreeContract").addEventListener("change", () => {
    $("#confirmOrder").textContent = $("#agreeContract").checked ? "确认支付" : "确认支付";
    $("#confirmOrder").disabled = false;
  });
  $("#confirmOrder").addEventListener("click", confirmOrder);
  $$(".payment-method").forEach((button) => {
    button.addEventListener("click", () => {
      state.paymentMethod = button.dataset.paymentMethod || "微信支付";
      renderPaymentMethods();
      toast(`已选择${state.paymentMethod}`);
    });
  });
  document.body.addEventListener("click", (event) => {
    const option = event.target.closest("[data-compensation-type]");
    if (!option) return;
    state.compensationType = option.dataset.compensationType || "traffic";
    $$(".compensation-option").forEach((item) => item.classList.toggle("active", item === option));
    toast(state.compensationType === "time" ? "已选择时间补偿" : "已选择账户补偿权益");
  });
  $("#arrivalMinutes").addEventListener("input", () => {
    if (Number($("#arrivalMinutes").value) < 0) $("#arrivalMinutes").value = 0;
    if (Number($("#arrivalMinutes").value) > 240) $("#arrivalMinutes").value = 240;
    updateArrivalUi();
  });
  $("#confirmArrival").addEventListener("click", confirmArrivalAndShowContract);
  $("#skipArrival").addEventListener("click", () => {
    $("#arrivalMinutes").value = 0;
    updateArrivalUi();
    confirmArrivalAndShowContract();
  });
  if ($("#goBStore")) $("#goBStore").addEventListener("click", async () => {
    state.storeMode = "B";
    $("#crossStoreDialog").close();
    await refreshBStoreQuote();
  });
  if ($("#joinWaitlist")) $("#joinWaitlist").addEventListener("click", async () => {
    const result = await api("/api/stores/waitlist", { method: "POST", body: selectedTimePayload() });
    state.dashboard = result.dashboard;
    $("#crossStoreDialog").close();
    toast(result.message);
    renderAll();
    await refreshQuote();
  });
  $("#toggleAlertSound").addEventListener("click", () => {
    state.alertSound = !state.alertSound;
    $("#toggleAlertSound").textContent = `声音提醒：${state.alertSound ? "开" : "关"}`;
    toast(`异常声音提醒已${state.alertSound ? "开启" : "关闭"}。`);
  });

  document.body.addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    handleAction(button.dataset.action, button.dataset.id, event);
  });

  $("#savePricing").addEventListener("click", async () => {
    const prices = Object.fromEntries($$("[data-price-type]").map((input) => [input.dataset.priceType, input.value]));
    const factors = Object.fromEntries($$("[data-factor-key]").map((input) => [input.dataset.factorKey, input.value]));
    state.dashboard = await api("/api/pricing", { method: "POST", body: { prices, factors, date: $("#bookingDate").value } });
    toast("定价已保存，报价会立即按新规则计算。");
    renderAll();
    await refreshQuote();
  });

  if ($("#resetDemo")) $("#resetDemo").addEventListener("click", async () => {
    state.dashboard = await api("/api/demo/reset", { method: "POST", body: { date: $("#bookingDate").value } });
    state.selectedRoomId = 0;
    state.roomTypeFilter = "all";
    state.floorFilter = "all";
    $("#roomTypeFilter").value = "all";
    $("#floorFilter").value = "all";
    state.guestHardwareRoomId = 0;
    state.user = null;
    state.timeCard = null;
    sessionStorage.removeItem("guestHardwareRoomId");
    sessionStorage.removeItem("hotelDemoUser");
    sessionStorage.removeItem("hotelTimeCard");
    toast("演示数据已恢复到初始状态。");
    renderAll();
    await refreshQuote();
  });
}

function setDefaultTime() {
  // 默认展示完整 24 小时：开始 00:00，结束 24:00。
  // 后续用户切换日期时只变日期，不重新计算时间，跨日期住宿保持连续。
  state.startMinute = 0;
  state.endMinute = 1440;
  ensureEndDate();
  renderTimeWheel("#endWheel", "end");
  setWheelValue("#startWheel", $("#bookingDate").value, state.startMinute);
  setWheelValue("#endWheel", $("#endDate").value, state.endMinute);
  updateTimeUi();
}

function ensureEndDate() {
  const startDate = $("#bookingDate").value || today();
  if (!$("#endDate").value || $("#endDate").value < startDate) $("#endDate").value = startDate;
  const shouldCrossDay = state.endMinute <= state.startMinute;
  if (shouldCrossDay && $("#endDate").value === startDate) $("#endDate").value = addDays(startDate, 1);
}

async function startSystem() {
  if (state.started) return;
  state.started = true;
  $("#bookingDate").value = today();
  $("#endDate").value = today();
  renderTimeWheel("#startWheel", "start");
  renderTimeWheel("#endWheel", "end");
  setDefaultTime();
  bindEvents();
  await loadDashboard();
  setInterval(loadDashboard, 45_000);
}

function boot() {
  $("#authForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = $("#accessPassword").value.trim();
    try {
      $("#authMessage").textContent = "";
      await loginWithPassword(input);
      $("#authGate").hidden = true;
      document.body.classList.remove("auth-locked");
      await startSystem();
    } catch (error) {
      state.started = false;
      $("#authMessage").textContent = error.message;
      $("#authGate").hidden = false;
      document.body.classList.add("auth-locked");
      $("#accessPassword").select();
    }
  });

  if (sessionStorage.getItem("hotelAccessToken")) {
    $("#authGate").hidden = true;
    document.body.classList.remove("auth-locked");
    startSystem().catch((error) => {
      state.started = false;
      $("#authMessage").textContent = error.message;
      $("#authGate").hidden = false;
      document.body.classList.add("auth-locked");
    });
  }
}

try {
  boot();
} catch (error) {
  toast(error.message);
}
