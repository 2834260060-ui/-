const $ = (selector) => document.querySelector(selector);

function qrSvgDataUri(text) {
  const modules = makeQrMatrix(String(text || ""));
  const size = modules.length;
  const quiet = 4;
  const cell = 7;
  const outer = (size + quiet * 2) * cell;
  const rects = [];
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      if (modules[y][x]) rects.push(`<rect x="${(x + quiet) * cell}" y="${(y + quiet) * cell}" width="${cell}" height="${cell}"/>`);
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${outer}" height="${outer}" viewBox="0 0 ${outer} ${outer}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><g fill="#111">${rects.join("")}</g></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function makeQrMatrix(text) {
  // 本地生成可扫码二维码，不调用任何外部服务。
  const version = 4;
  const size = 17 + version * 4;
  const dataCodewords = 80;
  const eccCodewords = 20;
  const matrix = Array.from({ length: size }, () => Array(size).fill(false));
  const reserved = Array.from({ length: size }, () => Array(size).fill(false));
  const set = (x, y, value, lock = true) => {
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    matrix[y][x] = Boolean(value);
    if (lock) reserved[y][x] = true;
  };
  const finder = (x, y) => {
    for (let dy = -1; dy <= 7; dy += 1) for (let dx = -1; dx <= 7; dx += 1) set(x + dx, y + dy, false);
    for (let dy = 0; dy < 7; dy += 1) for (let dx = 0; dx < 7; dx += 1) {
      const edge = dx === 0 || dx === 6 || dy === 0 || dy === 6;
      const core = dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4;
      set(x + dx, y + dy, edge || core);
    }
  };
  finder(0, 0);
  finder(size - 7, 0);
  finder(0, size - 7);
  for (let i = 8; i < size - 8; i += 1) {
    set(i, 6, i % 2 === 0);
    set(6, i, i % 2 === 0);
  }
  for (let dy = -2; dy <= 2; dy += 1) for (let dx = -2; dx <= 2; dx += 1) {
    const d = Math.max(Math.abs(dx), Math.abs(dy));
    set(26 + dx, 26 + dy, d !== 1);
  }
  set(8, 4 * version + 9, true);
  for (let i = 0; i < 9; i += 1) {
    if (i !== 6) {
      set(8, i, false);
      set(i, 8, false);
    }
  }
  for (let i = 0; i < 8; i += 1) {
    set(size - 1 - i, 8, false);
    set(8, size - 1 - i, false);
  }
  const bytes = [...new TextEncoder().encode(text)].slice(0, 72);
  const bits = [];
  const push = (value, length) => {
    for (let i = length - 1; i >= 0; i -= 1) bits.push((value >>> i) & 1);
  };
  push(0b0100, 4);
  push(bytes.length, 8);
  bytes.forEach((byte) => push(byte, 8));
  const maxBits = dataCodewords * 8;
  for (let i = 0; i < 4 && bits.length < maxBits; i += 1) bits.push(0);
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(Number.parseInt(bits.slice(i, i + 8).join(""), 2));
  for (let pad = 0; data.length < dataCodewords; pad += 1) data.push(pad % 2 ? 0x11 : 0xec);
  const codewords = [...data, ...qrReedSolomon(data, eccCodewords)];
  const allBits = codewords.flatMap((byte) => Array.from({ length: 8 }, (_, i) => (byte >>> (7 - i)) & 1));
  let bitIndex = 0;
  let upward = true;
  for (let x = size - 1; x > 0; x -= 2) {
    if (x === 6) x -= 1;
    for (let yi = 0; yi < size; yi += 1) {
      const y = upward ? size - 1 - yi : yi;
      for (let dx = 0; dx < 2; dx += 1) {
        const xx = x - dx;
        if (reserved[y][xx]) continue;
        const raw = allBits[bitIndex++] || 0;
        set(xx, y, raw ^ ((xx + y) % 2 === 0), false);
      }
    }
    upward = !upward;
  }
  writeQrFormat(matrix, reserved, 0);
  return matrix;
}

function qrReedSolomon(data, degree) {
  const exp = Array(512).fill(0);
  const log = Array(256).fill(0);
  let x = 1;
  for (let i = 0; i < 255; i += 1) {
    exp[i] = x;
    log[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i += 1) exp[i] = exp[i - 255];
  const mul = (a, b) => (a && b ? exp[log[a] + log[b]] : 0);
  let gen = [1];
  for (let i = 0; i < degree; i += 1) {
    const next = Array(gen.length + 1).fill(0);
    gen.forEach((coef, j) => {
      next[j] ^= mul(coef, exp[i]);
      next[j + 1] ^= coef;
    });
    gen = next;
  }
  const rem = Array(degree).fill(0);
  data.forEach((byte) => {
    const factor = byte ^ rem.shift();
    rem.push(0);
    gen.slice(1).forEach((coef, i) => {
      rem[i] ^= mul(coef, factor);
    });
  });
  return rem;
}

function writeQrFormat(matrix, reserved, mask) {
  const size = matrix.length;
  const set = (x, y, value) => {
    matrix[y][x] = Boolean(value);
    reserved[y][x] = true;
  };
  let data = (1 << 3) | mask;
  let bits = data << 10;
  const generator = 0x537;
  for (let i = 14; i >= 10; i -= 1) {
    if ((bits >>> i) & 1) bits ^= generator << (i - 10);
  }
  const format = ((data << 10) | bits) ^ 0x5412;
  const coords1 = [[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[7,8],[8,8],[8,7],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0]];
  const coords2 = [[size-1,8],[size-2,8],[size-3,8],[size-4,8],[size-5,8],[size-6,8],[size-7,8],[8,size-8],[8,size-7],[8,size-6],[8,size-5],[8,size-4],[8,size-3],[8,size-2],[8,size-1]];
  for (let i = 0; i < 15; i += 1) {
    const bit = (format >>> i) & 1;
    set(coords1[i][0], coords1[i][1], bit);
    set(coords2[i][0], coords2[i][1], bit);
  }
}

const qr = sessionStorage.getItem("hotelCheckinQr");
let order = {};
try {
  order = JSON.parse(sessionStorage.getItem("hotelCheckinOrder") || "{}");
} catch {
  order = {};
}
if ($("#checkinOrderInfo")) {
  $("#checkinOrderInfo").innerHTML = `
    <strong>订单已支付，入住凭证已生成</strong>
    <span>${order.store ? `${order.store} · ` : ""}${order.amount ? `支付金额 ¥${Number(order.amount || 0).toFixed(2)}` : "请出示下方二维码办理入住"}</span>
  `;
}
$("#checkinQrBox").innerHTML = qr
  ? `<img class="checkin-qr-image" src="${qrSvgDataUri(qr)}" alt="入住二维码" />`
  : `<div class="empty-qr">暂无二维码，请先完成支付。</div>`;
