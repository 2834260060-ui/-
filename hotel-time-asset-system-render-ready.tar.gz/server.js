import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { existsSync, mkdirSync } from "fs";
import { DatabaseSync } from "node:sqlite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, "data");
if (!existsSync(dataDir)) mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "hotel-time-assets.sqlite"));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public"), {
  setHeaders(res) {
    // 演示系统经常快速迭代，关闭缓存可以保证线上立刻看到最新版。
    res.setHeader("Cache-Control", "no-store");
  }
}));

const DEPOSIT = 100;
const CONTRACT_OVERTIME_RULES = [
  "超时10分钟内：系统提醒，不扣费",
  "超时10-20分钟：扣除20元超时费",
  "超时20分钟以上：扣除全部押金，系统自动开启新周期"
];
const TYPES = {
  economy: "经济型",
  standard: "标准型",
  deluxe: "豪华型"
};

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS rooms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      number TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL,
      base_price REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'idle'
    );
    CREATE TABLE IF NOT EXISTS pricing (
      key TEXT PRIMARY KEY,
      label TEXT NOT NULL,
      value REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      guest TEXT NOT NULL,
      status TEXT NOT NULL,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      actual_checkout_at TEXT,
      price REAL NOT NULL,
      deposit REAL NOT NULL DEFAULT 100,
      overtime_fee REAL NOT NULL DEFAULT 0,
      refund REAL NOT NULL DEFAULT 0,
      paid_total REAL NOT NULL,
      contract_json TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS cleaning_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      order_id INTEGER,
      status TEXT NOT NULL,
      scheduled_at TEXT NOT NULL,
      completed_at TEXT,
      ended_at TEXT,
      estimated_minutes INTEGER NOT NULL DEFAULT 30,
      priority TEXT NOT NULL DEFAULT 'normal',
      assignee TEXT,
      accepted_at TEXT,
      started_at TEXT,
      inspected_at TEXT,
      FOREIGN KEY(room_id) REFERENCES rooms(id),
      FOREIGN KEY(order_id) REFERENCES orders(id)
    );
    CREATE TABLE IF NOT EXISTS maintenance_blocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      reason TEXT
    );
    CREATE TABLE IF NOT EXISTS hardware (
      room_id INTEGER PRIMARY KEY,
      lock_authorized INTEGER NOT NULL DEFAULT 0,
      lock_open INTEGER NOT NULL DEFAULT 0,
      power_on INTEGER NOT NULL DEFAULT 0,
      emergency_light_on INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER,
      type TEXT NOT NULL,
      severity TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      message TEXT NOT NULL,
      method TEXT,
      result TEXT,
      escalated INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      acknowledged_at TEXT,
      resolved_at TEXT,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS waitlist (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      store_id TEXT NOT NULL,
      room_type TEXT,
      guest TEXT NOT NULL,
      requested_start_at TEXT NOT NULL,
      requested_end_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'waiting',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS store_transfers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_store TEXT NOT NULL,
      to_store TEXT NOT NULL,
      room_label TEXT NOT NULL,
      guest TEXT NOT NULL,
      guest_contact TEXT,
      start_at TEXT,
      end_at TEXT,
      amount REAL NOT NULL,
      commission_rate REAL NOT NULL,
      commission_amount REAL NOT NULL,
      host_revenue REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'locked',
      settlement_status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL
    );
  `);

  migrateCleaningTasks();
  migrateAlerts();
  migrateStoreTransfers();

  const seeded = db.prepare("SELECT value FROM metadata WHERE key = 'seeded'").get();
  if (!seeded) seedDemoData();
}

function migrateAlerts() {
  db.exec(`CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER,
    type TEXT NOT NULL,
    severity TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    message TEXT NOT NULL,
    method TEXT,
    result TEXT,
    escalated INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    acknowledged_at TEXT,
    resolved_at TEXT
  );`);
}

function migrateCleaningTasks() {
  const columns = db.prepare("PRAGMA table_info(cleaning_tasks)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE cleaning_tasks ADD COLUMN ${sql}`);
  };
  addColumn("ended_at", "ended_at TEXT");
  addColumn("estimated_minutes", "estimated_minutes INTEGER NOT NULL DEFAULT 30");
  addColumn("priority", "priority TEXT NOT NULL DEFAULT 'normal'");
  addColumn("assignee", "assignee TEXT");
  addColumn("accepted_at", "accepted_at TEXT");
  addColumn("started_at", "started_at TEXT");
  addColumn("inspected_at", "inspected_at TEXT");
}

function migrateStoreTransfers() {
  const columns = db.prepare("PRAGMA table_info(store_transfers)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE store_transfers ADD COLUMN ${sql}`);
  };
  addColumn("guest_contact", "guest_contact TEXT");
  addColumn("start_at", "start_at TEXT");
  addColumn("end_at", "end_at TEXT");
  addColumn("settlement_status", "settlement_status TEXT NOT NULL DEFAULT 'pending'");
}

function seedDemoData() {
  const now = new Date();
  const today = ymd(now);
  const yesterday = ymd(addMinutes(now, -1440));
  const createdAt = now.toISOString();

  const roomStmt = db.prepare("INSERT INTO rooms(number, type, base_price, status) VALUES (?, ?, ?, ?)");
  roomStmt.run("201", "economy", 199, "occupied");
  roomStmt.run("202", "standard", 299, "idle");
  roomStmt.run("203", "deluxe", 499, "overtime");

  const priceStmt = db.prepare("INSERT INTO pricing(key, label, value) VALUES (?, ?, ?)");
  [
    ["golden", "黄金时段 周五20:00-周六08:00", 1.3],
    ["standard", "标准时段 工作日08:00-20:00", 1.0],
    ["fragment", "碎片时段 工作日14:00-18:00", 0.7],
    ["waste", "垃圾时段 工作日02:00-08:00", 0.5],
    ["demand_low", "剩余可售时间 <30%", 1.2],
    ["demand_hot", "剩余可售时间 <10%", 1.5]
  ].forEach((row) => priceStmt.run(...row));

  createOrderRaw({
    roomId: 1,
    guest: "演示客人A",
    status: "ongoing",
    startAt: addMinutes(now, -70).toISOString(),
    endAt: addMinutes(now, 80).toISOString(),
    price: 36.8,
    note: "预置：当前入住"
  });
  createOrderRaw({
    roomId: 1,
    guest: "商务客人B",
    status: "completed",
    startAt: `${today}T08:00:00`,
    endAt: `${today}T10:30:00`,
    actualCheckoutAt: `${today}T10:22:00`,
    price: 34.6,
    refund: 100,
    note: "预置：已完成"
  });
  createOrderRaw({
    roomId: 2,
    guest: "钟点客人C",
    status: "completed",
    startAt: `${yesterday}T15:00:00`,
    endAt: `${yesterday}T18:00:00`,
    actualCheckoutAt: `${yesterday}T17:50:00`,
    price: 26.2,
    refund: 100,
    note: "预置：已完成"
  });
  createOrderRaw({
    roomId: 2,
    guest: "预约客人D",
    status: "pending",
    startAt: addMinutes(now, 90).toISOString(),
    endAt: addMinutes(now, 240).toISOString(),
    price: 48.1,
    note: "预置：待入住"
  });
  createOrderRaw({
    roomId: 3,
    guest: "超时客人E",
    status: "overtime",
    startAt: addMinutes(now, -210).toISOString(),
    endAt: addMinutes(now, -35).toISOString(),
    price: 72.7,
    overtimeFee: 100,
    refund: 0,
    note: "预置：超时"
  });

  createCleaningTask({
    roomId: 2,
    orderId: 3,
    endedAt: addMinutes(now, -1240).toISOString(),
    priority: "normal",
    status: "released",
    assignee: "王阿姨",
    scheduledAt: addMinutes(now, -1200).toISOString(),
    completedAt: addMinutes(now, -1160).toISOString()
  });
  db.prepare("INSERT INTO maintenance_blocks(room_id, start_at, end_at, reason) VALUES (?, ?, ?, ?)").run(2, `${today}T02:00:00`, `${today}T03:00:00`, "空调巡检");
  createAlert({ roomId: 3, type: "安全警报", severity: "critical", message: "203房触发紧急按钮，已同步前台/保安/店长" });
  createAlert({ roomId: 1, type: "用户投诉", severity: "warning", message: "201房用户评分2星，关键词：卫生/噪音" });

  [1, 2, 3].forEach((roomId) => updateHardware(roomId));
  db.prepare("INSERT INTO metadata(key, value) VALUES ('seeded', '1')").run();
}

function createOrderRaw({ roomId, guest, status, startAt, endAt, price, actualCheckoutAt = null, overtimeFee = 0, refund = 0, note = "" }) {
  const contract = buildContract(roomId, startAt, endAt, price);
  const info = db.prepare(`
    INSERT INTO orders(room_id, guest, status, start_at, end_at, actual_checkout_at, price, deposit, overtime_fee, refund, paid_total, contract_json, note, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(roomId, guest, status, startAt, endAt, actualCheckoutAt, round(price), DEPOSIT, overtimeFee, refund, round(price + DEPOSIT), JSON.stringify(contract), note, new Date().toISOString());
  return info.lastInsertRowid;
}

function cleaningMinutesByType(type) {
  return type === "deluxe" ? 50 : type === "standard" ? 40 : 30;
}

function cleaningBufferByType(type) {
  return type === "deluxe" ? 25 : type === "standard" ? 20 : 15;
}

function roomCleaningBuffer(roomId) {
  const room = db.prepare("SELECT type FROM rooms WHERE id = ?").get(roomId);
  return cleaningBufferByType(room?.type);
}

function createCleaningTask({ roomId, orderId, endedAt, priority = "normal", status = "pending", assignee = null, scheduledAt = null, completedAt = null, note = "" }) {
  const room = db.prepare("SELECT type FROM rooms WHERE id = ?").get(roomId);
  const estimated = cleaningMinutesByType(room?.type);
  const existing = orderId ? db.prepare("SELECT id FROM cleaning_tasks WHERE order_id = ? AND status != 'released' LIMIT 1").get(orderId) : null;
  if (existing) return existing.id;
  const info = db.prepare(`
    INSERT INTO cleaning_tasks(room_id, order_id, status, scheduled_at, completed_at, ended_at, estimated_minutes, priority, assignee)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(roomId, orderId, status, scheduledAt || new Date().toISOString(), completedAt, endedAt, estimated, priority, assignee);
  if (note) createAlert({ roomId, type: "保洁调度", severity: priority === "urgent" ? "warning" : "info", message: note });
  return info.lastInsertRowid;
}

function actualCleaningMinutes(task) {
  if (!task.started_at || !task.completed_at) return null;
  return Math.max(1, Math.round((new Date(task.completed_at) - new Date(task.started_at)) / 60_000));
}

function createAlert({ roomId = null, type, severity = "warning", message }) {
  const duplicate = db.prepare(`
    SELECT id FROM alerts
    WHERE status != 'resolved' AND type = ? AND IFNULL(room_id, 0) = IFNULL(?, 0)
    LIMIT 1
  `).get(type, roomId);
  if (duplicate) return duplicate.id;
  const info = db.prepare(`
    INSERT INTO alerts(room_id, type, severity, status, message, created_at)
    VALUES (?, ?, ?, 'open', ?, ?)
  `).run(roomId, type, severity, message, new Date().toISOString());
  return info.lastInsertRowid;
}

function buildStoresSummary(metrics, alerts) {
  const today = ymd(new Date());
  const transfers = db.prepare(`
    SELECT * FROM store_transfers
    WHERE date(created_at) = date(?)
    ORDER BY datetime(created_at) DESC
  `).all(today);
  const waitlistCount = db.prepare("SELECT COUNT(*) AS count FROM waitlist WHERE status = 'waiting'").get().count;
  const transferAmount = transfers.reduce((sum, t) => sum + t.amount, 0);
  const commissionAmount = transfers.reduce((sum, t) => sum + t.commission_amount, 0);
  const partnerRevenue = transfers.reduce((sum, t) => sum + t.host_revenue, 0);
  const recommendation = crossStoreRecommendation();
  const bStoreOrders = transfers.map((t) => ({
    ...t,
    tag: "跨店调度",
    sourceStore: t.from_store,
    receiveStore: t.to_store,
    splitText: `A店${t.commission_rate}% / B店${100 - t.commission_rate}%`,
    roomStatus: t.status === "locked" ? "已售/已锁定" : "已完成",
    noticeTitle: "跨店调度订单：来自A店"
  }));
  const bLockedRooms = bStoreOrders
    .filter((t) => t.status === "locked")
    .map((t) => ({ room: t.room_label, status: "已售", guest: t.guest, startAt: t.start_at, endAt: t.end_at }));
  const current = {
    id: "A",
    name: "A店 · 时间资产旗舰店",
    address: "上海市静安区南京西路88号",
    rooms: 3,
    occupancyRate: metrics.occupancyRate,
    todayIncome: round(metrics.todayIncome + commissionAmount),
    alerts: alerts.filter((a) => a.status !== "resolved").length,
    role: "总部/店长/前台"
  };
  const stores = [
    current,
    { id: "B", name: "B店 · 高铁站店", address: "上海虹桥枢纽T2旁", rooms: 36, occupancyRate: 42, todayIncome: round(8620 + partnerRevenue), alerts: 0, role: "总部可见" },
    { id: "C", name: "C店 · 商务公园店", address: "浦东张江科创园18号", rooms: 52, occupancyRate: 76, todayIncome: 15380, alerts: 1, role: "总部可见" }
  ];
  const totalRooms = stores.reduce((sum, s) => sum + s.rooms, 0);
  const totalIncome = stores.reduce((sum, s) => sum + s.todayIncome, 0);
  const avgOccupancy = round(stores.reduce((sum, s) => sum + s.occupancyRate, 0) / stores.length);
  return {
    role: "总部：看所有店；店长：看本店；前台：看本店并处理异常",
    stores,
    totalRooms,
    totalIncome: round(totalIncome),
    avgOccupancy,
    incomeRanking: [...stores].sort((a, b) => b.todayIncome - a.todayIncome),
    occupancyRanking: [...stores].sort((a, b) => b.occupancyRate - a.occupancyRate),
    waitlistCount,
    transferFinance: {
      count: transfers.length,
      amount: round(transferAmount),
      commissionAmount: round(commissionAmount),
      partnerRevenue: round(partnerRevenue),
      latest: transfers.slice(0, 5)
    },
    crossStoreZone: {
      todayOrders: transfers.length,
      sourceCommissionTotal: round(commissionAmount),
      receivingRevenueTotal: round(partnerRevenue),
      pendingSettlement: transfers.filter((t) => (t.settlement_status || "pending") === "pending").length
    },
    aStoreRecords: transfers.map((t) => ({
      id: t.id,
      title: "跨店调度成功",
      room: t.room_label,
      guest: t.guest,
      guestContact: t.guest_contact || "138****1010",
      startAt: t.start_at,
      endAt: t.end_at,
      amount: t.amount,
      commissionAmount: t.commission_amount,
      settlementStatus: t.settlement_status || "pending",
      createdAt: t.created_at
    })),
    bStoreOrders,
    bStoreRooms: bLockedRooms,
    latestTransferNotice: bStoreOrders[0] || null,
    transferRecommendation: {
      ...recommendation,
      reason: current.occupancyRate >= 90 ? "A店满房，推荐B店空闲房" : "演示：当A店满房时，系统推荐B店空闲房"
    }
  };
}

function crossStoreRecommendation(input = {}) {
  const selectedRoom = input.roomId ? db.prepare("SELECT * FROM rooms WHERE id = ?").get(Number(input.roomId)) : null;
  const type = selectedRoom?.type || input.roomType || "standard";
  const basePrice = selectedRoom?.base_price || db.prepare("SELECT base_price FROM rooms WHERE type = ? LIMIT 1").get(type)?.base_price || 299;
  const bRooms = {
    economy: "B-0806",
    standard: "B-1206",
    deluxe: "B-2308"
  };
  const startMinute = Number(input.startMinute ?? 20 * 60);
  const endMinute = Number(input.endMinute ?? startMinute + 120);
  const date = input.date || ymd(new Date());
  const endDate = input.endDate || date;
  const { startAt, endAt } = parseRange(date, startMinute, endMinute, endDate);
  const minutes = Math.max(1, Math.round((endAt - startAt) / 60_000));
  const pricing = getPricingConfig();
  const perMinute = basePrice / 1440;
  let total = 0;
  for (let i = 0; i < minutes; i++) {
    total += perMinute * timeCoefficient(addMinutes(startAt, i), pricing);
  }
  const estimatedOrder = round(total);
  const commission = round(estimatedOrder * 0.1);
  const partner = round(estimatedOrder - commission);
  return {
    fromStoreId: "A",
    toStoreId: "B",
    from: "A店 · 时间资产旗舰店",
    to: "B店 · 高铁站店",
    distanceKm: 2.3,
    roomNumber: bRooms[type] || "B-1206",
    roomTypeKey: type,
    roomType: TYPES[type] || "标准型",
    room: `${bRooms[type] || "B-1206"} ${TYPES[type] || "标准型"}`,
    startAt: startAt.toISOString(),
    endAt: endAt.toISOString(),
    minutes,
    commissionRate: 10,
    estimatedOrder,
    commission,
    partnerRevenue: partner,
    contract: {
      title: "跨店点对点时间契约",
      roomNumber: bRooms[type] || "B-1206",
      roomType: `${TYPES[type] || "标准型"}（B店·高铁站店）`,
      startAt: startAt.toISOString(),
      endAt: endAt.toISOString(),
      price: estimatedOrder,
      deposit: DEPOSIT,
      rules: CONTRACT_OVERTIME_RULES,
      transferNote: "A店已满：系统推荐最近B店并自动转单；出单店A抽成10%，接待店B获得90%房费收入。",
      hardware: "B店订单开始时门锁授权并供电，订单结束时失效并触发保洁。"
    }
  };
}

function ymd(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addMinutes(date, minutes) {
  return new Date(new Date(date).getTime() + minutes * 60_000);
}

function minuteOfDay(date) {
  const d = new Date(date);
  return d.getHours() * 60 + d.getMinutes();
}

function round(value) {
  return Math.round(value * 100) / 100;
}

function getPricingConfig() {
  return Object.fromEntries(db.prepare("SELECT key, value FROM pricing").all().map((r) => [r.key, r.value]));
}

function weekday(date) {
  return new Date(date).getDay();
}

function timeCoefficient(date, pricing) {
  const day = weekday(date);
  const m = minuteOfDay(date);
  const isWorkday = day >= 1 && day <= 5;
  if ((day === 5 && m >= 20 * 60) || (day === 6 && m < 8 * 60)) return pricing.golden;
  if (isWorkday && m >= 14 * 60 && m < 18 * 60) return pricing.fragment;
  if (isWorkday && m >= 2 * 60 && m < 8 * 60) return pricing.waste;
  if (isWorkday && m >= 8 * 60 && m < 20 * 60) return pricing.standard;
  return 0.85;
}

function demandCoefficient(roomId, date, pricing) {
  const map = buildMinuteMap(roomId, date);
  const idle = map.filter((x) => x === "idle").length;
  const ratio = idle / 1440;
  if (ratio < 0.1) return pricing.demand_hot;
  if (ratio < 0.3) return pricing.demand_low;
  return 1;
}

function parseRange(date, startMinute, endMinute, endDate = date) {
  const start = new Date(`${date}T00:00:00`);
  const end = new Date(`${endDate}T00:00:00`);
  start.setMinutes(startMinute);
  end.setMinutes(endMinute);
  return { startAt: start, endAt: end };
}

function roomEarliestStart(roomId, now = new Date()) {
  const buffer = roomCleaningBuffer(roomId);
  const base = addMinutes(now, buffer);
  const orders = db.prepare(`
    SELECT status, start_at, end_at FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime','completed')
    ORDER BY datetime(end_at) DESC
  `).all(roomId);
  const lastEnd = orders
    .filter((o) => o.status !== "pending" || new Date(o.start_at) <= now)
    .map((o) => addMinutes(o.end_at, buffer))
    .filter((d) => d > now)
    .sort((a, b) => b - a)[0];
  const earliest = lastEnd && lastEnd > base ? lastEnd : base;
  return { earliest, buffer };
}

function rangeIsIdle(roomId, startAt, endAt) {
  const buffer = roomCleaningBuffer(roomId);
  const requestedEndWithClean = addMinutes(endAt, buffer);
  const orders = db.prepare(`
    SELECT * FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime','completed')
  `).all(roomId);
  for (const order of orders) {
    const blockedStart = new Date(order.start_at);
    const blockedEnd = addMinutes(order.end_at, buffer);
    if (requestedEndWithClean > blockedStart && startAt < blockedEnd) return false;
  }

  const overlaps = db.prepare(`
    SELECT COUNT(*) AS count FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime')
      AND datetime(end_at) > datetime(?) AND datetime(start_at) < datetime(?)
  `).get(roomId, startAt.toISOString(), endAt.toISOString()).count;
  if (overlaps > 0) return false;

  const maintenance = db.prepare(`
    SELECT COUNT(*) AS count FROM maintenance_blocks
    WHERE room_id = ?
      AND datetime(end_at) > datetime(?) AND datetime(start_at) < datetime(?)
  `).get(roomId, startAt.toISOString(), endAt.toISOString()).count;
  return maintenance === 0;
}

function demandCoefficientForRange(roomId, startAt, pricing) {
  return demandCoefficient(roomId, ymd(startAt), pricing);
}

function quote(roomId, date, startMinute, endMinute, endDate = date) {
  const room = db.prepare("SELECT * FROM rooms WHERE id = ?").get(roomId);
  if (!room) throw new Error("房间不存在");
  const { startAt, endAt } = parseRange(date, startMinute, endMinute, endDate);
  const minutes = Math.round((endAt - startAt) / 60_000);
  if (minutes <= 0) throw new Error("结束时间必须晚于开始时间，可以把结束日期选到明天或更后面");
  const availability = roomEarliestStart(roomId);
  if (startAt < availability.earliest) {
    throw new Error(`需预留${availability.buffer}分钟清洁缓冲，最早可入住 ${availability.earliest.toLocaleString("zh-CN", { hour12: false })}`);
  }

  if (!rangeIsIdle(roomId, startAt, endAt)) throw new Error(`所选时间段与订单或清洁缓冲冲突，请选择更晚时间`);

  const pricing = getPricingConfig();
  const demand = demandCoefficientForRange(roomId, startAt, pricing);
  const perMinute = room.base_price / 1440;
  let total = 0;
  const segmentStats = {};
  for (let i = 0; i < minutes; i++) {
    const current = addMinutes(startAt, i);
    const coeff = timeCoefficient(current, pricing);
    total += perMinute * coeff * demand;
    const key = coeff === pricing.golden ? "黄金" : coeff === pricing.fragment ? "碎片" : coeff === pricing.waste ? "垃圾" : "标准/普通";
    segmentStats[key] = (segmentStats[key] || 0) + 1;
  }
  return {
    room,
    date,
    endDate,
    startMinute,
    endMinute,
    minutes,
    price: round(total),
    deposit: DEPOSIT,
    payTotal: round(total + DEPOSIT),
    demandCoefficient: demand,
    segmentStats,
    contract: buildContract(roomId, startAt.toISOString(), endAt.toISOString(), total)
  };
}

function buildContract(roomId, startAt, endAt, price) {
  const room = db.prepare("SELECT number, type FROM rooms WHERE id = ?").get(roomId);
  return {
    title: "点对点时间契约",
    roomNumber: room?.number || "",
    roomType: TYPES[room?.type] || room?.type || "",
    startAt,
    endAt,
    price: round(price),
    deposit: DEPOSIT,
    rules: CONTRACT_OVERTIME_RULES,
    hardware: "订单开始时门锁授权并供电，订单结束时门锁失效并断电，仅保留应急照明。"
  };
}

function buildMinuteMap(roomId, date) {
  return buildMinuteRangeMap(roomId, date, date).map;
}

function normalizeTimelineRange(startDate, endDate = startDate) {
  const rangeStart = new Date(`${startDate}T00:00:00`);
  const rangeEnd = new Date(`${endDate}T00:00:00`);
  if (Number.isNaN(rangeStart.getTime()) || Number.isNaN(rangeEnd.getTime()) || rangeEnd < rangeStart) {
    return normalizeTimelineRange(ymd(new Date()), ymd(new Date()));
  }
  rangeEnd.setDate(rangeEnd.getDate() + 1);
  const minutes = Math.max(1440, Math.round((rangeEnd - rangeStart) / 60_000));
  return { rangeStart, rangeEnd, minutes };
}

function buildMinuteRangeMap(roomId, startDate, endDate = startDate) {
  // 按“开始日期00:00 → 结束日期24:00”生成连续分钟颗粒。
  // 例如22号住到26号，后台会得到一条连续的5天时间轴，而不是只展示22号当天。
  const { rangeStart, rangeEnd, minutes } = normalizeTimelineRange(startDate, endDate);
  const map = new Array(minutes).fill("idle");
  const orders = db.prepare(`
    SELECT * FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime')
      AND datetime(end_at) >= datetime(?) AND datetime(start_at) <= datetime(?)
  `).all(roomId, rangeStart.toISOString(), rangeEnd.toISOString());

  orders.forEach((order) => paintRange(map, order.start_at, order.end_at, rangeStart, "sold"));
  const cleaning = db.prepare("SELECT * FROM cleaning_tasks WHERE room_id = ? AND status IN ('pending','accepted','cleaning','finished','completed')").all(roomId);
  cleaning.forEach((task) => paintRange(map, task.scheduled_at, addMinutes(task.scheduled_at, task.estimated_minutes || 30).toISOString(), rangeStart, "cleaning"));
  const maintenance = db.prepare("SELECT * FROM maintenance_blocks WHERE room_id = ?").all(roomId);
  maintenance.forEach((block) => paintRange(map, block.start_at, block.end_at, rangeStart, "maintenance"));
  return { map, rangeStart, rangeEnd, minutes };
}

function paintRange(map, startAt, endAt, rangeStart, state) {
  const start = new Date(startAt);
  const end = new Date(endAt);
  const from = Math.max(0, Math.floor((start - rangeStart) / 60_000));
  const to = Math.min(map.length, Math.ceil((end - rangeStart) / 60_000));
  for (let i = from; i < to; i++) map[i] = state;
}

function compressMap(map) {
  const segments = [];
  let start = 0;
  for (let i = 1; i <= map.length; i++) {
    if (i === map.length || map[i] !== map[start]) {
      segments.push({ state: map[start], start, end: i, width: ((i - start) / map.length) * 100 });
      start = i;
    }
  }
  const counts = map.reduce((acc, state) => {
    acc[state] = (acc[state] || 0) + 1;
    return acc;
  }, {});
  return { segments, counts };
}

function updateOrderAutomation() {
  const now = new Date();
  const pending = db.prepare("SELECT * FROM orders WHERE status = 'pending' AND datetime(start_at) <= datetime(?)").all(now.toISOString());
  pending.forEach((order) => {
    db.prepare("UPDATE orders SET status = 'ongoing' WHERE id = ?").run(order.id);
    updateHardware(order.room_id);
  });

  const ongoing = db.prepare("SELECT * FROM orders WHERE status = 'ongoing'").all();
  ongoing.forEach((order) => {
    const overtimeMinutes = Math.floor((now - new Date(order.end_at)) / 60_000);
    if (overtimeMinutes > 0) {
      db.prepare("UPDATE orders SET status = 'overtime', note = ? WHERE id = ?").run(`系统检测：已超时${overtimeMinutes}分钟`, order.id);
      if (overtimeMinutes >= 10) {
        createAlert({
          roomId: order.room_id,
          type: "超时未退房",
          severity: overtimeMinutes >= 20 ? "critical" : "warning",
          message: `订单#${order.id}结束后${overtimeMinutes}分钟仍未退房`
        });
      }
      createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: order.end_at, priority: "urgent" });
      updateHardware(order.room_id);
    }
  });

  const rooms = db.prepare("SELECT id FROM rooms").all();
  rooms.forEach((room) => updateRoomStatus(room.id));
  updateCleaningPreAlerts();
}

function updateCleaningPreAlerts() {
  const now = new Date();
  const tasks = db.prepare(`
    SELECT c.*, o.start_at, r.number AS room_number
    FROM cleaning_tasks c
    LEFT JOIN orders o ON c.order_id = o.id
    LEFT JOIN rooms r ON c.room_id = r.id
    WHERE c.status IN ('pending','accepted','cleaning','finished')
  `).all();
  tasks.forEach((task) => {
    const sinceDispatch = Math.floor((now - new Date(task.scheduled_at)) / 60_000);
    const minutesToCheckin = task.start_at ? Math.floor((new Date(task.start_at) - now) / 60_000) : null;
    if (task.status === "pending" && sinceDispatch >= 2) {
      db.prepare("UPDATE cleaning_tasks SET assignee = COALESCE(assignee, ?) WHERE id = ?").run("自动改派：李师傅", task.id);
      createAlert({ roomId: task.room_id, type: "保洁未接单", severity: "warning", message: `${task.room_number}房保洁工单2分钟未接单，系统已自动改派/提醒前台介入` });
    }
    if (minutesToCheckin !== null && minutesToCheckin < 5 && minutesToCheckin >= 0 && !["completed", "released"].includes(task.status)) {
      createAlert({ roomId: task.room_id, type: "清洁可能超时", severity: "critical", message: `${task.room_number}房距离入住仅${minutesToCheckin}分钟，清洁未完成；已建议用户延迟入住或换房` });
    }
  });
}

function updateRoomStatus(roomId) {
  const active = db.prepare("SELECT status FROM orders WHERE room_id = ? AND status IN ('ongoing','overtime') ORDER BY id DESC LIMIT 1").get(roomId);
  const cleaning = db.prepare("SELECT status FROM cleaning_tasks WHERE room_id = ? AND status IN ('pending','accepted','cleaning','finished','completed') ORDER BY id DESC LIMIT 1").get(roomId);
  const futureOrder = db.prepare("SELECT id FROM orders WHERE room_id = ? AND status = 'pending' ORDER BY datetime(start_at) ASC LIMIT 1").get(roomId);
  const status = active?.status === "overtime"
    ? "overtime"
    : active
      ? "occupied"
      : futureOrder && cleaning && cleaning.status !== "completed"
        ? "reserved_cleaning"
        : futureOrder && cleaning?.status === "completed"
          ? "ready"
          : cleaning?.status === "completed"
            ? "inspected"
        : cleaning
          ? "cleaning"
          : "idle";
  db.prepare("UPDATE rooms SET status = ? WHERE id = ?").run(status, roomId);
}

function updateHardware(roomId) {
  updateRoomStatus(roomId);
  const room = db.prepare("SELECT status FROM rooms WHERE id = ?").get(roomId);
  const active = room?.status === "occupied" || room?.status === "overtime";
  db.prepare(`
    INSERT INTO hardware(room_id, lock_authorized, lock_open, power_on, emergency_light_on, updated_at)
    VALUES (?, ?, ?, ?, 1, ?)
    ON CONFLICT(room_id) DO UPDATE SET
      lock_authorized = excluded.lock_authorized,
      lock_open = excluded.lock_open,
      power_on = excluded.power_on,
      emergency_light_on = 1,
      updated_at = excluded.updated_at
  `).run(roomId, active ? 1 : 0, active ? 1 : 0, active ? 1 : 0, new Date().toISOString());
}

function updateAlertEscalation() {
  const now = new Date();
  const open = db.prepare("SELECT * FROM alerts WHERE status != 'resolved'").all();
  open.forEach((alert) => {
    const minutes = Math.floor((now - new Date(alert.created_at)) / 60_000);
    if (minutes >= 15 && !alert.escalated) {
      db.prepare("UPDATE alerts SET escalated = 1, severity = 'critical', message = message || ' · 超时未处理，已升级通知店长/保安' WHERE id = ?").run(alert.id);
    }
  });
}

function serializeRoom(room) {
  const availability = roomEarliestStart(room.id);
  return {
    ...room,
    typeLabel: TYPES[room.type],
    guestStatus: "可预订",
    cleaningBuffer: availability.buffer,
    earliestStartAt: availability.earliest.toISOString()
  };
}

function getDashboard(date = ymd(new Date()), endDate = date) {
  updateOrderAutomation();
  updateAlertEscalation();
  const { minutes: rangeMinutes } = normalizeTimelineRange(date, endDate);
  const rooms = db.prepare("SELECT * FROM rooms ORDER BY number").all().map(serializeRoom);
  const orders = db.prepare(`
    SELECT o.*, r.number AS room_number, r.type AS room_type
    FROM orders o JOIN rooms r ON o.room_id = r.id
    ORDER BY datetime(o.start_at) DESC
  `).all().map((o) => ({ ...o, contract: JSON.parse(o.contract_json), roomTypeLabel: TYPES[o.room_type] }));
  const hardware = db.prepare("SELECT * FROM hardware").all();
  const cleaningTasks = db.prepare(`
    SELECT c.*, r.number AS room_number, r.type AS room_type, o.end_at AS order_end_at, o.start_at AS order_start_at
    FROM cleaning_tasks c
    JOIN rooms r ON c.room_id = r.id
    LEFT JOIN orders o ON c.order_id = o.id
    ORDER BY CASE c.status
      WHEN 'pending' THEN 1
      WHEN 'accepted' THEN 2
      WHEN 'cleaning' THEN 3
      WHEN 'finished' THEN 4
      WHEN 'completed' THEN 5
      ELSE 6
    END, datetime(c.scheduled_at) DESC
  `).all().map((task) => {
    const minutesToCheckin = task.order_start_at ? Math.floor((new Date(task.order_start_at) - new Date()) / 60_000) : null;
    return {
      ...task,
      actual_minutes: actualCleaningMinutes(task),
      roomTypeLabel: TYPES[task.room_type],
      minutes_to_checkin: minutesToCheckin,
      dispatch_label: minutesToCheckin !== null && minutesToCheckin >= 0 ? "即将入住，优先清洁" : ""
    };
  });
  const timelines = rooms.map((room) => {
    const { map, rangeStart, rangeEnd, minutes } = buildMinuteRangeMap(room.id, date, endDate);
    return {
      roomId: room.id,
      roomNumber: room.number,
      rangeStart: rangeStart.toISOString(),
      rangeEnd: rangeEnd.toISOString(),
      rangeMinutes: minutes,
      rangeDays: Math.ceil(minutes / 1440),
      ...compressMap(map)
    };
  });
  const viewStart = new Date(`${date}T00:00:00`);
  const viewEnd = new Date(`${endDate}T00:00:00`);
  viewEnd.setDate(viewEnd.getDate() + 1);
  const todayOrders = orders.filter((o) => new Date(o.end_at) >= viewStart && new Date(o.start_at) <= viewEnd);
  const income = todayOrders.reduce((sum, o) => sum + (o.status === "completed" || o.status === "overtime" || o.status === "ongoing" ? o.price + o.overtime_fee : 0), 0);
  const soldMinutes = timelines.reduce((sum, t) => sum + (t.counts.sold || 0), 0);
  const avgPrice = todayOrders.length ? income / todayOrders.length : 0;
  const alerts = db.prepare(`
    SELECT a.*, r.number AS room_number
    FROM alerts a
    LEFT JOIN rooms r ON a.room_id = r.id
    ORDER BY CASE a.severity WHEN 'critical' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END,
      CASE a.status WHEN 'open' THEN 1 WHEN 'acknowledged' THEN 2 ELSE 3 END,
      datetime(a.created_at) DESC
  `).all();
  const metrics = {
    todayIncome: round(income),
    occupancyRate: round((soldMinutes / (rooms.length * rangeMinutes)) * 100),
    averageRoomPrice: round(avgPrice),
    soldMinutes,
    idleMinutes: rooms.length * rangeMinutes - soldMinutes
  };
  return {
    now: new Date().toISOString(),
    date,
    endDate,
    rangeMinutes,
    rooms,
    orders,
    hardware,
    timelines,
    pricing: db.prepare("SELECT * FROM pricing ORDER BY key").all(),
    cleaningTasks,
    latestCleaningNotice: cleaningTasks.find((t) => t.status === "pending") || null,
    alerts,
    latestAlert: alerts.find((a) => a.status === "open") || null,
    metrics,
    cleaningMetrics: buildCleaningMetrics(cleaningTasks),
    stores: buildStoresSummary(metrics, alerts)
  };
}

function buildCleaningMetrics(tasks) {
  const today = ymd(new Date());
  const todayTasks = tasks.filter((t) => ymd(t.scheduled_at) === today || ymd(t.completed_at) === today);
  const completed = todayTasks.filter((t) => ["completed", "released"].includes(t.status));
  const actuals = completed.map(actualCleaningMinutes).filter(Boolean);
  const byAssignee = {};
  completed.forEach((task) => {
    const name = task.assignee || "未分配";
    const actual = actualCleaningMinutes(task) || task.estimated_minutes;
    if (!byAssignee[name]) byAssignee[name] = { name, count: 0, total: 0 };
    byAssignee[name].count += 1;
    byAssignee[name].total += actual;
  });
  return {
    total: todayTasks.length,
    pending: todayTasks.filter((t) => t.status === "pending").length,
    processing: todayTasks.filter((t) => ["accepted", "cleaning", "finished"].includes(t.status)).length,
    completed: completed.length,
    averageMinutes: actuals.length ? round(actuals.reduce((sum, x) => sum + x, 0) / actuals.length) : 0,
    ranking: Object.values(byAssignee)
      .map((x) => ({ name: x.name, count: x.count, avg: round(x.total / x.count) }))
      .sort((a, b) => b.count - a.count || a.avg - b.avg)
  };
}

app.get("/api/bootstrap", (req, res) => {
  res.json(getDashboard(req.query.date || ymd(new Date()), req.query.endDate || req.query.date || ymd(new Date())));
});

app.post("/api/quote", (req, res) => {
  try {
    const data = quote(Number(req.body.roomId), req.body.date, Number(req.body.startMinute), Number(req.body.endMinute), req.body.endDate || req.body.date);
    res.json(data);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.post("/api/orders", (req, res) => {
  try {
    const q = quote(Number(req.body.roomId), req.body.date, Number(req.body.startMinute), Number(req.body.endMinute), req.body.endDate || req.body.date);
    const status = new Date(q.contract.startAt) <= new Date() ? "ongoing" : "pending";
    const orderId = createOrderRaw({
      roomId: Number(req.body.roomId),
      guest: req.body.guest || "演示客人",
      status,
      startAt: q.contract.startAt,
      endAt: q.contract.endAt,
      price: q.price,
      note: "用户端模拟支付成功"
    });
    if (status === "pending") {
      createCleaningTask({
        roomId: Number(req.body.roomId),
        orderId,
        endedAt: new Date().toISOString(),
        priority: "urgent",
        scheduledAt: new Date().toISOString(),
        note: "即将入住，优先清洁"
      });
      db.prepare("UPDATE rooms SET status = 'reserved_cleaning' WHERE id = ?").run(Number(req.body.roomId));
    }
    updateHardware(Number(req.body.roomId));
    res.json({ ok: true, dashboard: getDashboard(req.body.date) });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.post("/api/orders/:id/checkin", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  db.prepare("UPDATE orders SET status = 'ongoing', note = '演示：手动触发入住，门锁与供电已生效' WHERE id = ?").run(order.id);
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/alerts/simulate", (req, res) => {
  const roomId = Number(req.body.roomId || 3);
  const type = req.body.type || "安全警报";
  const severity = type === "安全警报" ? "critical" : ["门锁故障", "电路异常", "用户投诉"].includes(type) ? "warning" : "info";
  const room = db.prepare("SELECT number FROM rooms WHERE id = ?").get(roomId);
  const messageMap = {
    门锁故障: `${room?.number || ""}房开锁/关锁失败，请前台介入`,
    电路异常: `${room?.number || ""}房供电/断电失败，请工程巡检`,
    用户投诉: `${room?.number || ""}房评分低于3星或触发投诉关键词`,
    安全警报: `${room?.number || ""}房烟雾/水浸/紧急按钮触发，已同步保安`,
    超时未退房: `${room?.number || ""}房订单结束10分钟仍未退房`
  };
  createAlert({ roomId, type, severity, message: messageMap[type] || `${room?.number || ""}房出现异常` });
  res.json(getDashboard(req.body.date));
});

app.post("/api/alerts/:id/action", (req, res) => {
  const alert = db.prepare("SELECT * FROM alerts WHERE id = ?").get(req.params.id);
  if (!alert) return res.status(404).json({ message: "异常不存在" });
  const now = new Date().toISOString();
  const action = req.body.action || "resolve";
  if (action === "ack") {
    db.prepare("UPDATE alerts SET status = 'acknowledged', acknowledged_at = ? WHERE id = ?").run(now, alert.id);
  } else if (action === "resolve") {
    db.prepare("UPDATE alerts SET status = 'resolved', method = ?, result = ?, resolved_at = ? WHERE id = ?").run(req.body.method || "前台一键处理", req.body.result || "已记录并通知对应岗位", now, alert.id);
  } else if (action === "escalate") {
    db.prepare("UPDATE alerts SET status = 'acknowledged', escalated = 1, severity = 'critical', method = ?, result = ?, acknowledged_at = COALESCE(acknowledged_at, ?) WHERE id = ?").run("升级通知", "已通知店长/保安", now, alert.id);
  } else {
    return res.status(400).json({ message: "未知异常动作" });
  }
  res.json(getDashboard(req.body.date));
});

app.post("/api/orders/:id/checkout", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  const now = new Date();
  const plannedMinutes = Math.max(1, (new Date(order.end_at) - new Date(order.start_at)) / 60_000);
  const usedMinutes = Math.max(1, Math.min(plannedMinutes, (now - new Date(order.start_at)) / 60_000));
  const actualPrice = req.body.mode === "early" ? round(order.price * (usedMinutes / plannedMinutes)) : order.price;
  const refund = round(DEPOSIT + Math.max(0, order.price - actualPrice));
  db.prepare(`
    UPDATE orders SET status = 'completed', actual_checkout_at = ?, end_at = ?, price = ?, refund = ?, note = ?
    WHERE id = ?
  `).run(now.toISOString(), now.toISOString(), actualPrice, refund, req.body.mode === "early" ? "提前退房：按实际使用分钟重新结算" : "正常退房：押金已退还", order.id);
  createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: now.toISOString(), priority: req.body.mode === "early" ? "normal" : "normal" });
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/orders/:id/overtime", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  const minutes = Number(req.body.minutes || 25);
  let fee = 0;
  let note = "超时10分钟内：仅提醒客人";
  if (minutes > 20) {
    fee = DEPOSIT;
    note = "超时20分钟以上：扣除全部押金，并自动开启新周期";
    const nextStart = new Date(order.end_at);
    const nextEnd = addMinutes(nextStart, 60);
    createOrderRaw({
      roomId: order.room_id,
      guest: `${order.guest}续住`,
      status: "ongoing",
      startAt: nextStart.toISOString(),
      endAt: nextEnd.toISOString(),
      price: round(order.price / 2),
      note: "系统自动开启的新周期"
    });
  } else if (minutes > 10) {
    fee = 20;
    note = "超时10-20分钟：扣除20元超时费";
  }
  db.prepare("UPDATE orders SET status = 'overtime', overtime_fee = ?, refund = ?, note = ? WHERE id = ?").run(fee, Math.max(0, DEPOSIT - fee), note, order.id);
  createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: new Date().toISOString(), priority: minutes > 10 ? "urgent" : "normal" });
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/cleaning/:id/action", (req, res) => {
  const task = db.prepare("SELECT * FROM cleaning_tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ message: "保洁任务不存在" });
  const now = new Date().toISOString();
  const worker = req.body.assignee || task.assignee || ["王阿姨", "李师傅", "赵姐"][task.id % 3];
  const action = req.body.action;
  if (action === "accept") {
    db.prepare("UPDATE cleaning_tasks SET status = 'accepted', assignee = ?, accepted_at = ? WHERE id = ?").run(worker, now, task.id);
  } else if (action === "start") {
    db.prepare("UPDATE cleaning_tasks SET status = 'cleaning', assignee = ?, started_at = COALESCE(started_at, ?) WHERE id = ?").run(worker, now, task.id);
  } else if (action === "finish") {
    db.prepare("UPDATE cleaning_tasks SET status = 'finished', completed_at = COALESCE(completed_at, ?) WHERE id = ?").run(now, task.id);
  } else if (action === "inspect") {
    db.prepare("UPDATE cleaning_tasks SET status = 'completed', inspected_at = ? WHERE id = ?").run(now, task.id);
  } else if (action === "release") {
    db.prepare("UPDATE cleaning_tasks SET status = 'released' WHERE id = ?").run(task.id);
  } else {
    return res.status(400).json({ message: "未知保洁动作" });
  }
  updateHardware(task.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/cleaning/:id/complete", (req, res) => {
  const task = db.prepare("SELECT * FROM cleaning_tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ message: "保洁任务不存在" });
  const now = new Date().toISOString();
  db.prepare("UPDATE cleaning_tasks SET status = 'completed', completed_at = COALESCE(completed_at, ?), inspected_at = ? WHERE id = ?").run(now, now, task.id);
  updateHardware(task.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/stores/recommend", (req, res) => {
  const recommendation = crossStoreRecommendation(req.body);
  res.json({
    ok: true,
    title: "A店已满，为您推荐最近的B店·高铁站店，距您2.3公里",
    message: `推荐 ${recommendation.to} 的 ${recommendation.room}，按所选点对点时间预计 ${recommendation.estimatedOrder} 元。`,
    recommendation
  });
});

app.post("/api/stores/transfer", (req, res) => {
  const recommendation = crossStoreRecommendation(req.body);
  const amount = round(Number(req.body.amount || recommendation.estimatedOrder));
  const commission = round(amount * 0.1);
  const partner = round(amount - commission);
  db.prepare(`
    INSERT INTO store_transfers(from_store, to_store, room_label, guest, guest_contact, start_at, end_at, amount, commission_rate, commission_amount, host_revenue, status, settlement_status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 10, ?, ?, 'locked', 'pending', ?)
  `).run(
    recommendation.from,
    recommendation.to,
    `${recommendation.roomNumber} ${recommendation.roomType}`,
    req.body.guest || "跨店演示客户",
    req.body.guestContact || "138****1010",
    recommendation.startAt,
    recommendation.endAt,
    amount,
    commission,
    partner,
    new Date().toISOString()
  );
  createAlert({
    type: "跨店调度订单",
    severity: "warning",
    message: `跨店调度订单：来自A店，${recommendation.roomType} ${recommendation.roomNumber}，价格${amount}元，客户${req.body.guestContact || "138****1010"}`
  });
  res.json({
    ok: true,
    message: `已自动转单到B店：A店抽成10%=${commission}元，B店接待收入=${partner}元。`,
    transfer: { ...recommendation, estimatedOrder: amount, commission, partnerRevenue: partner },
    dashboard: getDashboard(req.body.date, req.body.endDate || req.body.date)
  });
});

app.post("/api/stores/waitlist", (req, res) => {
  const recommendation = crossStoreRecommendation(req.body);
  db.prepare(`
    INSERT INTO waitlist(store_id, room_type, guest, requested_start_at, requested_end_at, status, created_at)
    VALUES ('A', ?, ?, ?, ?, 'waiting', ?)
  `).run(
    recommendation.roomType,
    req.body.guest || "候补演示客户",
    recommendation.startAt,
    recommendation.endAt,
    new Date().toISOString()
  );
  res.json({
    ok: true,
    message: "已加入A店候补队列：如有房间释放，前台会优先联系客户。",
    dashboard: getDashboard(req.body.date, req.body.endDate || req.body.date)
  });
});

app.post("/api/pricing", (req, res) => {
  const { prices, factors } = req.body;
  if (prices) {
    Object.entries(prices).forEach(([type, price]) => {
      db.prepare("UPDATE rooms SET base_price = ? WHERE type = ?").run(Number(price), type);
    });
  }
  if (factors) {
    Object.entries(factors).forEach(([key, value]) => {
      db.prepare("UPDATE pricing SET value = ? WHERE key = ?").run(Number(value), key);
    });
  }
  res.json(getDashboard(req.body.date));
});

app.post("/api/demo/reset", (req, res) => {
  db.exec("DELETE FROM metadata; DELETE FROM alerts; DELETE FROM waitlist; DELETE FROM store_transfers; DELETE FROM hardware; DELETE FROM cleaning_tasks; DELETE FROM maintenance_blocks; DELETE FROM orders; DELETE FROM rooms; DELETE FROM pricing;");
  seedDemoData();
  res.json(getDashboard(req.body.date));
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

initDb();

if (!process.env.NO_LISTEN && !process.env.VERCEL) {
  setInterval(updateOrderAutomation, 30_000);
  const host = process.env.HOST || "127.0.0.1";
  app.listen(PORT, host, () => {
    console.log(`酒店时间资产管理系统已启动：http://localhost:${PORT}`);
  });
}

export { app, getDashboard, quote };
export default app;
