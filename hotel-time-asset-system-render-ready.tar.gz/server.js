import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { existsSync, mkdirSync } from "fs";
import { DatabaseSync } from "node:sqlite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, "data");
if (!existsSync(dataDir)) mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "hotel-time-assets.sqlite"));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public"), {
  setHeaders(res) {
    // 演示系统经常快速迭代，关闭缓存可以保证线上立刻看到最新版。
    res.setHeader("Cache-Control", "no-store");
  }
}));

const DEPOSIT = 100;
const TYPES = {
  economy: "经济型",
  standard: "标准型",
  deluxe: "豪华型"
};

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS rooms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      number TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL,
      base_price REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'idle'
    );
    CREATE TABLE IF NOT EXISTS pricing (
      key TEXT PRIMARY KEY,
      label TEXT NOT NULL,
      value REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      guest TEXT NOT NULL,
      status TEXT NOT NULL,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      actual_checkout_at TEXT,
      price REAL NOT NULL,
      deposit REAL NOT NULL DEFAULT 100,
      overtime_fee REAL NOT NULL DEFAULT 0,
      refund REAL NOT NULL DEFAULT 0,
      paid_total REAL NOT NULL,
      contract_json TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS cleaning_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      order_id INTEGER,
      status TEXT NOT NULL,
      scheduled_at TEXT NOT NULL,
      completed_at TEXT,
      ended_at TEXT,
      estimated_minutes INTEGER NOT NULL DEFAULT 30,
      priority TEXT NOT NULL DEFAULT 'normal',
      assignee TEXT,
      accepted_at TEXT,
      started_at TEXT,
      inspected_at TEXT,
      FOREIGN KEY(room_id) REFERENCES rooms(id),
      FOREIGN KEY(order_id) REFERENCES orders(id)
    );
    CREATE TABLE IF NOT EXISTS maintenance_blocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      reason TEXT
    );
    CREATE TABLE IF NOT EXISTS hardware (
      room_id INTEGER PRIMARY KEY,
      lock_authorized INTEGER NOT NULL DEFAULT 0,
      lock_open INTEGER NOT NULL DEFAULT 0,
      power_on INTEGER NOT NULL DEFAULT 0,
      emergency_light_on INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
  `);

  migrateCleaningTasks();

  const seeded = db.prepare("SELECT value FROM metadata WHERE key = 'seeded'").get();
  if (!seeded) seedDemoData();
}

function migrateCleaningTasks() {
  const columns = db.prepare("PRAGMA table_info(cleaning_tasks)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE cleaning_tasks ADD COLUMN ${sql}`);
  };
  addColumn("ended_at", "ended_at TEXT");
  addColumn("estimated_minutes", "estimated_minutes INTEGER NOT NULL DEFAULT 30");
  addColumn("priority", "priority TEXT NOT NULL DEFAULT 'normal'");
  addColumn("assignee", "assignee TEXT");
  addColumn("accepted_at", "accepted_at TEXT");
  addColumn("started_at", "started_at TEXT");
  addColumn("inspected_at", "inspected_at TEXT");
}

function seedDemoData() {
  const now = new Date();
  const today = ymd(now);
  const yesterday = ymd(addMinutes(now, -1440));
  const createdAt = now.toISOString();

  const roomStmt = db.prepare("INSERT INTO rooms(number, type, base_price, status) VALUES (?, ?, ?, ?)");
  roomStmt.run("201", "economy", 199, "occupied");
  roomStmt.run("202", "standard", 299, "idle");
  roomStmt.run("203", "deluxe", 499, "overtime");

  const priceStmt = db.prepare("INSERT INTO pricing(key, label, value) VALUES (?, ?, ?)");
  [
    ["golden", "黄金时段 周五20:00-周六08:00", 1.3],
    ["standard", "标准时段 工作日08:00-20:00", 1.0],
    ["fragment", "碎片时段 工作日14:00-18:00", 0.7],
    ["waste", "垃圾时段 工作日02:00-08:00", 0.5],
    ["demand_low", "剩余可售时间 <30%", 1.2],
    ["demand_hot", "剩余可售时间 <10%", 1.5]
  ].forEach((row) => priceStmt.run(...row));

  createOrderRaw({
    roomId: 1,
    guest: "演示客人A",
    status: "ongoing",
    startAt: addMinutes(now, -70).toISOString(),
    endAt: addMinutes(now, 80).toISOString(),
    price: 36.8,
    note: "预置：当前入住"
  });
  createOrderRaw({
    roomId: 1,
    guest: "商务客人B",
    status: "completed",
    startAt: `${today}T08:00:00`,
    endAt: `${today}T10:30:00`,
    actualCheckoutAt: `${today}T10:22:00`,
    price: 34.6,
    refund: 100,
    note: "预置：已完成"
  });
  createOrderRaw({
    roomId: 2,
    guest: "钟点客人C",
    status: "completed",
    startAt: `${yesterday}T15:00:00`,
    endAt: `${yesterday}T18:00:00`,
    actualCheckoutAt: `${yesterday}T17:50:00`,
    price: 26.2,
    refund: 100,
    note: "预置：已完成"
  });
  createOrderRaw({
    roomId: 2,
    guest: "预约客人D",
    status: "pending",
    startAt: addMinutes(now, 90).toISOString(),
    endAt: addMinutes(now, 240).toISOString(),
    price: 48.1,
    note: "预置：待入住"
  });
  createOrderRaw({
    roomId: 3,
    guest: "超时客人E",
    status: "overtime",
    startAt: addMinutes(now, -210).toISOString(),
    endAt: addMinutes(now, -35).toISOString(),
    price: 72.7,
    overtimeFee: 100,
    refund: 0,
    note: "预置：超时"
  });

  createCleaningTask({
    roomId: 2,
    orderId: 3,
    endedAt: addMinutes(now, -1240).toISOString(),
    priority: "normal",
    status: "released",
    assignee: "王阿姨",
    scheduledAt: addMinutes(now, -1200).toISOString(),
    completedAt: addMinutes(now, -1160).toISOString()
  });
  db.prepare("INSERT INTO maintenance_blocks(room_id, start_at, end_at, reason) VALUES (?, ?, ?, ?)").run(2, `${today}T02:00:00`, `${today}T03:00:00`, "空调巡检");

  [1, 2, 3].forEach((roomId) => updateHardware(roomId));
  db.prepare("INSERT INTO metadata(key, value) VALUES ('seeded', '1')").run();
}

function createOrderRaw({ roomId, guest, status, startAt, endAt, price, actualCheckoutAt = null, overtimeFee = 0, refund = 0, note = "" }) {
  const contract = buildContract(roomId, startAt, endAt, price);
  const info = db.prepare(`
    INSERT INTO orders(room_id, guest, status, start_at, end_at, actual_checkout_at, price, deposit, overtime_fee, refund, paid_total, contract_json, note, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(roomId, guest, status, startAt, endAt, actualCheckoutAt, round(price), DEPOSIT, overtimeFee, refund, round(price + DEPOSIT), JSON.stringify(contract), note, new Date().toISOString());
  return info.lastInsertRowid;
}

function cleaningMinutesByType(type) {
  return type === "deluxe" ? 50 : type === "standard" ? 40 : 30;
}

function createCleaningTask({ roomId, orderId, endedAt, priority = "normal", status = "pending", assignee = null, scheduledAt = null, completedAt = null }) {
  const room = db.prepare("SELECT type FROM rooms WHERE id = ?").get(roomId);
  const estimated = cleaningMinutesByType(room?.type);
  const existing = orderId ? db.prepare("SELECT id FROM cleaning_tasks WHERE order_id = ? LIMIT 1").get(orderId) : null;
  if (existing) return existing.id;
  const info = db.prepare(`
    INSERT INTO cleaning_tasks(room_id, order_id, status, scheduled_at, completed_at, ended_at, estimated_minutes, priority, assignee)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(roomId, orderId, status, scheduledAt || new Date().toISOString(), completedAt, endedAt, estimated, priority, assignee);
  return info.lastInsertRowid;
}

function actualCleaningMinutes(task) {
  if (!task.started_at || !task.completed_at) return null;
  return Math.max(1, Math.round((new Date(task.completed_at) - new Date(task.started_at)) / 60_000));
}

function ymd(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addMinutes(date, minutes) {
  return new Date(new Date(date).getTime() + minutes * 60_000);
}

function minuteOfDay(date) {
  const d = new Date(date);
  return d.getHours() * 60 + d.getMinutes();
}

function round(value) {
  return Math.round(value * 100) / 100;
}

function getPricingConfig() {
  return Object.fromEntries(db.prepare("SELECT key, value FROM pricing").all().map((r) => [r.key, r.value]));
}

function weekday(date) {
  return new Date(date).getDay();
}

function timeCoefficient(date, pricing) {
  const day = weekday(date);
  const m = minuteOfDay(date);
  const isWorkday = day >= 1 && day <= 5;
  if ((day === 5 && m >= 20 * 60) || (day === 6 && m < 8 * 60)) return pricing.golden;
  if (isWorkday && m >= 14 * 60 && m < 18 * 60) return pricing.fragment;
  if (isWorkday && m >= 2 * 60 && m < 8 * 60) return pricing.waste;
  if (isWorkday && m >= 8 * 60 && m < 20 * 60) return pricing.standard;
  return 0.85;
}

function demandCoefficient(roomId, date, pricing) {
  const map = buildMinuteMap(roomId, date);
  const idle = map.filter((x) => x === "idle").length;
  const ratio = idle / 1440;
  if (ratio < 0.1) return pricing.demand_hot;
  if (ratio < 0.3) return pricing.demand_low;
  return 1;
}

function parseRange(date, startMinute, endMinute, endDate = date) {
  const start = new Date(`${date}T00:00:00`);
  const end = new Date(`${endDate}T00:00:00`);
  start.setMinutes(startMinute);
  end.setMinutes(endMinute);
  return { startAt: start, endAt: end };
}

function rangeIsIdle(roomId, startAt, endAt) {
  const overlaps = db.prepare(`
    SELECT COUNT(*) AS count FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime')
      AND datetime(end_at) > datetime(?) AND datetime(start_at) < datetime(?)
  `).get(roomId, startAt.toISOString(), endAt.toISOString()).count;
  if (overlaps > 0) return false;

  const maintenance = db.prepare(`
    SELECT COUNT(*) AS count FROM maintenance_blocks
    WHERE room_id = ?
      AND datetime(end_at) > datetime(?) AND datetime(start_at) < datetime(?)
  `).get(roomId, startAt.toISOString(), endAt.toISOString()).count;
  return maintenance === 0;
}

function demandCoefficientForRange(roomId, startAt, pricing) {
  return demandCoefficient(roomId, ymd(startAt), pricing);
}

function quote(roomId, date, startMinute, endMinute, endDate = date) {
  const room = db.prepare("SELECT * FROM rooms WHERE id = ?").get(roomId);
  if (!room) throw new Error("房间不存在");
  const { startAt, endAt } = parseRange(date, startMinute, endMinute, endDate);
  const minutes = Math.round((endAt - startAt) / 60_000);
  if (minutes <= 0) throw new Error("结束时间必须晚于开始时间，可以把结束日期选到明天或更后面");

  if (!rangeIsIdle(roomId, startAt, endAt)) throw new Error("所选时间段包含已售或维护分钟，请换一个时间");

  const pricing = getPricingConfig();
  const demand = demandCoefficientForRange(roomId, startAt, pricing);
  const perMinute = room.base_price / 1440;
  let total = 0;
  const segmentStats = {};
  for (let i = 0; i < minutes; i++) {
    const current = addMinutes(startAt, i);
    const coeff = timeCoefficient(current, pricing);
    total += perMinute * coeff * demand;
    const key = coeff === pricing.golden ? "黄金" : coeff === pricing.fragment ? "碎片" : coeff === pricing.waste ? "垃圾" : "标准/普通";
    segmentStats[key] = (segmentStats[key] || 0) + 1;
  }
  return {
    room,
    date,
    endDate,
    startMinute,
    endMinute,
    minutes,
    price: round(total),
    deposit: DEPOSIT,
    payTotal: round(total + DEPOSIT),
    demandCoefficient: demand,
    segmentStats,
    contract: buildContract(roomId, startAt.toISOString(), endAt.toISOString(), total)
  };
}

function buildContract(roomId, startAt, endAt, price) {
  const room = db.prepare("SELECT number, type FROM rooms WHERE id = ?").get(roomId);
  return {
    title: "点对点时间契约",
    roomNumber: room?.number || "",
    roomType: TYPES[room?.type] || room?.type || "",
    startAt,
    endAt,
    price: round(price),
    deposit: DEPOSIT,
    rules: [
      "超时10分钟内：系统提醒，不扣费",
      "超时10-20分钟：扣除20元超时费",
      "超时20分钟以上：扣除全部押金，系统自动开启新周期"
    ],
    hardware: "订单开始时门锁授权并供电，订单结束时门锁失效并断电，仅保留应急照明。"
  };
}

function buildMinuteMap(roomId, date) {
  return buildMinuteRangeMap(roomId, date, date).map;
}

function normalizeTimelineRange(startDate, endDate = startDate) {
  const rangeStart = new Date(`${startDate}T00:00:00`);
  const rangeEnd = new Date(`${endDate}T00:00:00`);
  if (Number.isNaN(rangeStart.getTime()) || Number.isNaN(rangeEnd.getTime()) || rangeEnd < rangeStart) {
    return normalizeTimelineRange(ymd(new Date()), ymd(new Date()));
  }
  rangeEnd.setDate(rangeEnd.getDate() + 1);
  const minutes = Math.max(1440, Math.round((rangeEnd - rangeStart) / 60_000));
  return { rangeStart, rangeEnd, minutes };
}

function buildMinuteRangeMap(roomId, startDate, endDate = startDate) {
  // 按“开始日期00:00 → 结束日期24:00”生成连续分钟颗粒。
  // 例如22号住到26号，后台会得到一条连续的5天时间轴，而不是只展示22号当天。
  const { rangeStart, rangeEnd, minutes } = normalizeTimelineRange(startDate, endDate);
  const map = new Array(minutes).fill("idle");
  const orders = db.prepare(`
    SELECT * FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime')
      AND datetime(end_at) >= datetime(?) AND datetime(start_at) <= datetime(?)
  `).all(roomId, rangeStart.toISOString(), rangeEnd.toISOString());

  orders.forEach((order) => paintRange(map, order.start_at, order.end_at, rangeStart, "sold"));
  const cleaning = db.prepare("SELECT * FROM cleaning_tasks WHERE room_id = ? AND status IN ('pending','accepted','cleaning','finished','completed')").all(roomId);
  cleaning.forEach((task) => paintRange(map, task.scheduled_at, addMinutes(task.scheduled_at, task.estimated_minutes || 30).toISOString(), rangeStart, "cleaning"));
  const maintenance = db.prepare("SELECT * FROM maintenance_blocks WHERE room_id = ?").all(roomId);
  maintenance.forEach((block) => paintRange(map, block.start_at, block.end_at, rangeStart, "maintenance"));
  return { map, rangeStart, rangeEnd, minutes };
}

function paintRange(map, startAt, endAt, rangeStart, state) {
  const start = new Date(startAt);
  const end = new Date(endAt);
  const from = Math.max(0, Math.floor((start - rangeStart) / 60_000));
  const to = Math.min(map.length, Math.ceil((end - rangeStart) / 60_000));
  for (let i = from; i < to; i++) map[i] = state;
}

function compressMap(map) {
  const segments = [];
  let start = 0;
  for (let i = 1; i <= map.length; i++) {
    if (i === map.length || map[i] !== map[start]) {
      segments.push({ state: map[start], start, end: i, width: ((i - start) / map.length) * 100 });
      start = i;
    }
  }
  const counts = map.reduce((acc, state) => {
    acc[state] = (acc[state] || 0) + 1;
    return acc;
  }, {});
  return { segments, counts };
}

function updateOrderAutomation() {
  const now = new Date();
  const pending = db.prepare("SELECT * FROM orders WHERE status = 'pending' AND datetime(start_at) <= datetime(?)").all(now.toISOString());
  pending.forEach((order) => {
    db.prepare("UPDATE orders SET status = 'ongoing' WHERE id = ?").run(order.id);
    updateHardware(order.room_id);
  });

  const ongoing = db.prepare("SELECT * FROM orders WHERE status = 'ongoing'").all();
  ongoing.forEach((order) => {
    const overtimeMinutes = Math.floor((now - new Date(order.end_at)) / 60_000);
    if (overtimeMinutes > 0) {
      db.prepare("UPDATE orders SET status = 'overtime', note = ? WHERE id = ?").run(`系统检测：已超时${overtimeMinutes}分钟`, order.id);
      createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: order.end_at, priority: "urgent" });
      updateHardware(order.room_id);
    }
  });

  const rooms = db.prepare("SELECT id FROM rooms").all();
  rooms.forEach((room) => updateRoomStatus(room.id));
}

function updateRoomStatus(roomId) {
  const active = db.prepare("SELECT status FROM orders WHERE room_id = ? AND status IN ('ongoing','overtime') ORDER BY id DESC LIMIT 1").get(roomId);
  const cleaning = db.prepare("SELECT status FROM cleaning_tasks WHERE room_id = ? AND status IN ('pending','accepted','cleaning','finished','completed') ORDER BY id DESC LIMIT 1").get(roomId);
  const status = active?.status === "overtime"
    ? "overtime"
    : active
      ? "occupied"
      : cleaning?.status === "completed"
        ? "inspected"
        : cleaning
          ? "cleaning"
          : "idle";
  db.prepare("UPDATE rooms SET status = ? WHERE id = ?").run(status, roomId);
}

function updateHardware(roomId) {
  updateRoomStatus(roomId);
  const room = db.prepare("SELECT status FROM rooms WHERE id = ?").get(roomId);
  const active = room?.status === "occupied" || room?.status === "overtime";
  db.prepare(`
    INSERT INTO hardware(room_id, lock_authorized, lock_open, power_on, emergency_light_on, updated_at)
    VALUES (?, ?, ?, ?, 1, ?)
    ON CONFLICT(room_id) DO UPDATE SET
      lock_authorized = excluded.lock_authorized,
      lock_open = excluded.lock_open,
      power_on = excluded.power_on,
      emergency_light_on = 1,
      updated_at = excluded.updated_at
  `).run(roomId, active ? 1 : 0, active ? 1 : 0, active ? 1 : 0, new Date().toISOString());
}

function serializeRoom(room) {
  return { ...room, typeLabel: TYPES[room.type] };
}

function getDashboard(date = ymd(new Date()), endDate = date) {
  updateOrderAutomation();
  const { minutes: rangeMinutes } = normalizeTimelineRange(date, endDate);
  const rooms = db.prepare("SELECT * FROM rooms ORDER BY number").all().map(serializeRoom);
  const orders = db.prepare(`
    SELECT o.*, r.number AS room_number, r.type AS room_type
    FROM orders o JOIN rooms r ON o.room_id = r.id
    ORDER BY datetime(o.start_at) DESC
  `).all().map((o) => ({ ...o, contract: JSON.parse(o.contract_json), roomTypeLabel: TYPES[o.room_type] }));
  const hardware = db.prepare("SELECT * FROM hardware").all();
  const cleaningTasks = db.prepare(`
    SELECT c.*, r.number AS room_number, r.type AS room_type, o.end_at AS order_end_at
    FROM cleaning_tasks c
    JOIN rooms r ON c.room_id = r.id
    LEFT JOIN orders o ON c.order_id = o.id
    ORDER BY CASE c.status
      WHEN 'pending' THEN 1
      WHEN 'accepted' THEN 2
      WHEN 'cleaning' THEN 3
      WHEN 'finished' THEN 4
      WHEN 'completed' THEN 5
      ELSE 6
    END, datetime(c.scheduled_at) DESC
  `).all().map((task) => ({ ...task, actual_minutes: actualCleaningMinutes(task), roomTypeLabel: TYPES[task.room_type] }));
  const timelines = rooms.map((room) => {
    const { map, rangeStart, rangeEnd, minutes } = buildMinuteRangeMap(room.id, date, endDate);
    return {
      roomId: room.id,
      roomNumber: room.number,
      rangeStart: rangeStart.toISOString(),
      rangeEnd: rangeEnd.toISOString(),
      rangeMinutes: minutes,
      rangeDays: Math.ceil(minutes / 1440),
      ...compressMap(map)
    };
  });
  const viewStart = new Date(`${date}T00:00:00`);
  const viewEnd = new Date(`${endDate}T00:00:00`);
  viewEnd.setDate(viewEnd.getDate() + 1);
  const todayOrders = orders.filter((o) => new Date(o.end_at) >= viewStart && new Date(o.start_at) <= viewEnd);
  const income = todayOrders.reduce((sum, o) => sum + (o.status === "completed" || o.status === "overtime" || o.status === "ongoing" ? o.price + o.overtime_fee : 0), 0);
  const soldMinutes = timelines.reduce((sum, t) => sum + (t.counts.sold || 0), 0);
  const avgPrice = todayOrders.length ? income / todayOrders.length : 0;
  return {
    now: new Date().toISOString(),
    date,
    endDate,
    rangeMinutes,
    rooms,
    orders,
    hardware,
    timelines,
    pricing: db.prepare("SELECT * FROM pricing ORDER BY key").all(),
    cleaningTasks,
    latestCleaningNotice: cleaningTasks.find((t) => t.status === "pending") || null,
    metrics: {
      todayIncome: round(income),
      occupancyRate: round((soldMinutes / (rooms.length * rangeMinutes)) * 100),
      averageRoomPrice: round(avgPrice),
      soldMinutes,
      idleMinutes: rooms.length * rangeMinutes - soldMinutes
    },
    cleaningMetrics: buildCleaningMetrics(cleaningTasks)
  };
}

function buildCleaningMetrics(tasks) {
  const today = ymd(new Date());
  const todayTasks = tasks.filter((t) => ymd(t.scheduled_at) === today || ymd(t.completed_at) === today);
  const completed = todayTasks.filter((t) => ["completed", "released"].includes(t.status));
  const actuals = completed.map(actualCleaningMinutes).filter(Boolean);
  const byAssignee = {};
  completed.forEach((task) => {
    const name = task.assignee || "未分配";
    const actual = actualCleaningMinutes(task) || task.estimated_minutes;
    if (!byAssignee[name]) byAssignee[name] = { name, count: 0, total: 0 };
    byAssignee[name].count += 1;
    byAssignee[name].total += actual;
  });
  return {
    total: todayTasks.length,
    pending: todayTasks.filter((t) => t.status === "pending").length,
    processing: todayTasks.filter((t) => ["accepted", "cleaning", "finished"].includes(t.status)).length,
    completed: completed.length,
    averageMinutes: actuals.length ? round(actuals.reduce((sum, x) => sum + x, 0) / actuals.length) : 0,
    ranking: Object.values(byAssignee)
      .map((x) => ({ name: x.name, count: x.count, avg: round(x.total / x.count) }))
      .sort((a, b) => b.count - a.count || a.avg - b.avg)
  };
}

app.get("/api/bootstrap", (req, res) => {
  res.json(getDashboard(req.query.date || ymd(new Date()), req.query.endDate || req.query.date || ymd(new Date())));
});

app.post("/api/quote", (req, res) => {
  try {
    const data = quote(Number(req.body.roomId), req.body.date, Number(req.body.startMinute), Number(req.body.endMinute), req.body.endDate || req.body.date);
    res.json(data);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.post("/api/orders", (req, res) => {
  try {
    const q = quote(Number(req.body.roomId), req.body.date, Number(req.body.startMinute), Number(req.body.endMinute), req.body.endDate || req.body.date);
    const status = new Date(q.contract.startAt) <= new Date() ? "ongoing" : "pending";
    createOrderRaw({
      roomId: Number(req.body.roomId),
      guest: req.body.guest || "演示客人",
      status,
      startAt: q.contract.startAt,
      endAt: q.contract.endAt,
      price: q.price,
      note: "用户端模拟支付成功"
    });
    updateHardware(Number(req.body.roomId));
    res.json({ ok: true, dashboard: getDashboard(req.body.date) });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.post("/api/orders/:id/checkin", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  db.prepare("UPDATE orders SET status = 'ongoing', note = '演示：手动触发入住，门锁与供电已生效' WHERE id = ?").run(order.id);
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/orders/:id/checkout", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  const now = new Date();
  const plannedMinutes = Math.max(1, (new Date(order.end_at) - new Date(order.start_at)) / 60_000);
  const usedMinutes = Math.max(1, Math.min(plannedMinutes, (now - new Date(order.start_at)) / 60_000));
  const actualPrice = req.body.mode === "early" ? round(order.price * (usedMinutes / plannedMinutes)) : order.price;
  const refund = round(DEPOSIT + Math.max(0, order.price - actualPrice));
  db.prepare(`
    UPDATE orders SET status = 'completed', actual_checkout_at = ?, price = ?, refund = ?, note = ?
    WHERE id = ?
  `).run(now.toISOString(), actualPrice, refund, req.body.mode === "early" ? "提前退房：按实际使用分钟重新结算" : "正常退房：押金已退还", order.id);
  createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: now.toISOString(), priority: req.body.mode === "early" ? "normal" : "normal" });
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/orders/:id/overtime", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  const minutes = Number(req.body.minutes || 25);
  let fee = 0;
  let note = "超时10分钟内：仅提醒客人";
  if (minutes > 20) {
    fee = DEPOSIT;
    note = "超时20分钟以上：扣除全部押金，并自动开启新周期";
    const nextStart = new Date(order.end_at);
    const nextEnd = addMinutes(nextStart, 60);
    createOrderRaw({
      roomId: order.room_id,
      guest: `${order.guest}续住`,
      status: "ongoing",
      startAt: nextStart.toISOString(),
      endAt: nextEnd.toISOString(),
      price: round(order.price / 2),
      note: "系统自动开启的新周期"
    });
  } else if (minutes > 10) {
    fee = 20;
    note = "超时10-20分钟：扣除20元超时费";
  }
  db.prepare("UPDATE orders SET status = 'overtime', overtime_fee = ?, refund = ?, note = ? WHERE id = ?").run(fee, Math.max(0, DEPOSIT - fee), note, order.id);
  createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: new Date().toISOString(), priority: minutes > 10 ? "urgent" : "normal" });
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/cleaning/:id/action", (req, res) => {
  const task = db.prepare("SELECT * FROM cleaning_tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ message: "保洁任务不存在" });
  const now = new Date().toISOString();
  const worker = req.body.assignee || task.assignee || ["王阿姨", "李师傅", "赵姐"][task.id % 3];
  const action = req.body.action;
  if (action === "accept") {
    db.prepare("UPDATE cleaning_tasks SET status = 'accepted', assignee = ?, accepted_at = ? WHERE id = ?").run(worker, now, task.id);
  } else if (action === "start") {
    db.prepare("UPDATE cleaning_tasks SET status = 'cleaning', assignee = ?, started_at = COALESCE(started_at, ?) WHERE id = ?").run(worker, now, task.id);
  } else if (action === "finish") {
    db.prepare("UPDATE cleaning_tasks SET status = 'finished', completed_at = COALESCE(completed_at, ?) WHERE id = ?").run(now, task.id);
  } else if (action === "inspect") {
    db.prepare("UPDATE cleaning_tasks SET status = 'completed', inspected_at = ? WHERE id = ?").run(now, task.id);
  } else if (action === "release") {
    db.prepare("UPDATE cleaning_tasks SET status = 'released' WHERE id = ?").run(task.id);
  } else {
    return res.status(400).json({ message: "未知保洁动作" });
  }
  updateHardware(task.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/cleaning/:id/complete", (req, res) => {
  const task = db.prepare("SELECT * FROM cleaning_tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ message: "保洁任务不存在" });
  const now = new Date().toISOString();
  db.prepare("UPDATE cleaning_tasks SET status = 'completed', completed_at = COALESCE(completed_at, ?), inspected_at = ? WHERE id = ?").run(now, now, task.id);
  updateHardware(task.room_id);
  res.json(getDashboard(req.body.date));
});

app.post("/api/pricing", (req, res) => {
  const { prices, factors } = req.body;
  if (prices) {
    Object.entries(prices).forEach(([type, price]) => {
      db.prepare("UPDATE rooms SET base_price = ? WHERE type = ?").run(Number(price), type);
    });
  }
  if (factors) {
    Object.entries(factors).forEach(([key, value]) => {
      db.prepare("UPDATE pricing SET value = ? WHERE key = ?").run(Number(value), key);
    });
  }
  res.json(getDashboard(req.body.date));
});

app.post("/api/demo/reset", (req, res) => {
  db.exec("DELETE FROM metadata; DELETE FROM hardware; DELETE FROM cleaning_tasks; DELETE FROM maintenance_blocks; DELETE FROM orders; DELETE FROM rooms; DELETE FROM pricing;");
  seedDemoData();
  res.json(getDashboard(req.body.date));
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

initDb();

if (!process.env.NO_LISTEN && !process.env.VERCEL) {
  setInterval(updateOrderAutomation, 30_000);
  const host = process.env.HOST || "127.0.0.1";
  app.listen(PORT, host, () => {
    console.log(`酒店时间资产管理系统已启动：http://localhost:${PORT}`);
  });
}

export { app, getDashboard, quote };
export default app;
