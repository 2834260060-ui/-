import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { existsSync, mkdirSync, statSync } from "fs";
import { DatabaseSync } from "node:sqlite";
import crypto from "node:crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDir = path.join(__dirname, "data");
if (!existsSync(dataDir)) mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "hotel-time-assets.sqlite"));
const app = express();
const PORT = process.env.PORT || 3000;
const ACCESS_PASSWORD = process.env.ACCESS_PASSWORD || "yang10101212";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const sessions = new Map();
const allowedOrigins = new Set([
  "https://hotel-time-asset-system.onrender.com",
  "https://hotel-time-asset-system.onrender.com/",
  ...(process.env.FRONTEND_ORIGINS || "").split(",").map((x) => x.trim()).filter(Boolean)
]);

function isAllowedOrigin(origin = "") {
  if (!origin) return true;
  if (allowedOrigins.has(origin)) return true;
  return /^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin);
}

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (isAllowedOrigin(origin)) {
    if (origin) res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  } else if (req.path.startsWith("/api")) {
    return res.status(403).json({ message: "当前来源无权访问系统接口" });
  }
  if (req.method === "OPTIONS") return res.status(204).end();
  next();
});

app.use(express.json());
app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (req.path.endsWith(".map")) return res.status(404).json({ message: "Not found" });
  next();
});

const DEPOSIT = 100;
const RENEWAL_MINUTES = 12 * 60;
const CONTRACT_OVERTIME_RULES = [
  "订单结束后5分钟：系统第一次提醒用户退房，不扣费",
  "订单结束后10分钟：系统第二次提醒，并扣除5元超时费",
  "订单结束后15分钟：扣除10元超时费",
  "订单结束后20分钟：押金自动转为续住房费，并从原结束时间起开启12小时续住周期"
];
const CHECKIN_RULES = [
  "您已选择该房间，该房间将在预订时段为您保留",
  "请在预计到店时间30分钟内办理入住",
  "超过30分钟未到店，开始按所选时段计费",
  "超过1小时未到店，订单自动取消",
  "自动取消后，已产生费用不予退还",
  "首次用户首次迟到免扣费"
];
const TYPES = {
  economy: "大床房",
  standard: "双人大床房",
  deluxe: "豪华大床房"
};

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      phone TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS rooms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      number TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL,
      base_price REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'idle'
    );
    CREATE TABLE IF NOT EXISTS pricing (
      key TEXT PRIMARY KEY,
      label TEXT NOT NULL,
      value REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      guest TEXT NOT NULL,
      status TEXT NOT NULL,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      actual_checkout_at TEXT,
      price REAL NOT NULL,
      deposit REAL NOT NULL DEFAULT 100,
      overtime_fee REAL NOT NULL DEFAULT 0,
      refund REAL NOT NULL DEFAULT 0,
      paid_total REAL NOT NULL,
      contract_json TEXT NOT NULL,
      note TEXT,
      expected_arrival_minutes INTEGER NOT NULL DEFAULT 20,
      earliest_checkin_at TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS cleaning_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      order_id INTEGER,
      status TEXT NOT NULL,
      scheduled_at TEXT NOT NULL,
      completed_at TEXT,
      ended_at TEXT,
      estimated_minutes INTEGER NOT NULL DEFAULT 15,
      priority TEXT NOT NULL DEFAULT 'normal',
      assignee TEXT,
      accepted_at TEXT,
      started_at TEXT,
      inspected_at TEXT,
      FOREIGN KEY(room_id) REFERENCES rooms(id),
      FOREIGN KEY(order_id) REFERENCES orders(id)
    );
    CREATE TABLE IF NOT EXISTS maintenance_blocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      reason TEXT
    );
    CREATE TABLE IF NOT EXISTS hardware (
      room_id INTEGER PRIMARY KEY,
      lock_authorized INTEGER NOT NULL DEFAULT 0,
      lock_open INTEGER NOT NULL DEFAULT 0,
      power_on INTEGER NOT NULL DEFAULT 0,
      door_open INTEGER NOT NULL DEFAULT 0,
      ac_on INTEGER NOT NULL DEFAULT 0,
      light_on INTEGER NOT NULL DEFAULT 0,
      access_authorized INTEGER NOT NULL DEFAULT 0,
      hot_water_on INTEGER NOT NULL DEFAULT 0,
      elevator_authorized INTEGER NOT NULL DEFAULT 0,
      emergency_light_on INTEGER NOT NULL DEFAULT 1,
      adapter TEXT DEFAULT 'mock',
      last_command TEXT,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS payment_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER,
      room_id INTEGER,
      provider TEXT NOT NULL DEFAULT 'mock',
      status TEXT NOT NULL,
      scenario TEXT NOT NULL,
      amount REAL NOT NULL,
      deposit REAL NOT NULL DEFAULT 0,
      transaction_id TEXT,
      checkin_qr TEXT,
      request_json TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(order_id) REFERENCES orders(id),
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER,
      type TEXT NOT NULL,
      severity TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      message TEXT NOT NULL,
      method TEXT,
      result TEXT,
      escalated INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      acknowledged_at TEXT,
      resolved_at TEXT,
      FOREIGN KEY(room_id) REFERENCES rooms(id)
    );
    CREATE TABLE IF NOT EXISTS waitlist (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      store_id TEXT NOT NULL,
      room_type TEXT,
      guest TEXT NOT NULL,
      requested_start_at TEXT NOT NULL,
      requested_end_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'waiting',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS store_transfers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_store TEXT NOT NULL,
      to_store TEXT NOT NULL,
      room_label TEXT NOT NULL,
      guest TEXT NOT NULL,
      guest_contact TEXT,
      start_at TEXT,
      end_at TEXT,
      expected_arrival_minutes INTEGER NOT NULL DEFAULT 20,
      earliest_checkin_at TEXT,
      amount REAL NOT NULL,
      commission_rate REAL NOT NULL,
      commission_amount REAL NOT NULL,
      host_revenue REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'locked',
      settlement_status TEXT NOT NULL DEFAULT 'pending',
      lock_id TEXT,
      compensation_type TEXT,
      compensation_value REAL NOT NULL DEFAULT 0,
      compensation_text TEXT,
      supplement_json TEXT,
      confirmed_at TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cross_store_locks (
      lock_id TEXT PRIMARY KEY,
      from_store TEXT NOT NULL,
      to_store TEXT NOT NULL,
      room_label TEXT NOT NULL,
      room_type TEXT,
      start_at TEXT NOT NULL,
      end_at TEXT NOT NULL,
      amount REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'reserved',
      expires_at TEXT NOT NULL,
      payload_json TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS time_cards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      time_card_id TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'normal',
      benefits_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS time_card_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ledger_no TEXT NOT NULL UNIQUE,
      time_card_id TEXT NOT NULL,
      benefit_type TEXT NOT NULL,
      action TEXT NOT NULL,
      quantity REAL NOT NULL,
      source TEXT NOT NULL,
      operator TEXT NOT NULL,
      related_order TEXT,
      reason TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(time_card_id) REFERENCES time_cards(time_card_id)
    );
  `);

  migrateCleaningTasks();
  migrateAlerts();
  migrateOrders();
  migrateHardware();
  migratePayments();
  migrateStoreTransfers();
  migrateCrossStoreLocks();
  migrateTimeCards();
  migrateUsers();

  const seeded = db.prepare("SELECT value FROM metadata WHERE key = 'seeded'").get();
  if (!seeded) seedDemoData();
  ensureDemoRoomInventory();
  cleanupSeededNoiseAlerts();
  cleanupAutomaticOperationalNoise();
  cleanupInitialBackendInfoOnce();
  normalizeCleaningDurations();
  ensureCompensationPricing();
}

function ensureCompensationPricing() {
  const stmt = db.prepare(`
    INSERT INTO pricing(key, label, value)
    VALUES (?, ?, ?)
    ON CONFLICT(key) DO NOTHING
  `);
  [
    ["transfer_time_per_100m", "跨店补偿：每100米补偿分钟数", 2],
    ["transfer_traffic_per_km", "跨店补偿：每公里交通补偿金额", 4],
    ["transfer_traffic_min", "跨店补偿：最低交通补偿", 10],
    ["transfer_time_max", "跨店补偿：最高时间补偿分钟", 120]
  ].forEach((row) => stmt.run(...row));
}

function migrateUsers() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      phone TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);
}

function migrateAlerts() {
  db.exec(`CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER,
    type TEXT NOT NULL,
    severity TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    message TEXT NOT NULL,
    recipients TEXT,
    method TEXT,
    result TEXT,
    escalated INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    acknowledged_at TEXT,
    resolved_at TEXT
  );`);
  const columns = db.prepare("PRAGMA table_info(alerts)").all().map((c) => c.name);
  if (!columns.includes("recipients")) db.exec("ALTER TABLE alerts ADD COLUMN recipients TEXT");
}

function migrateCleaningTasks() {
  const columns = db.prepare("PRAGMA table_info(cleaning_tasks)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE cleaning_tasks ADD COLUMN ${sql}`);
  };
  addColumn("ended_at", "ended_at TEXT");
  addColumn("estimated_minutes", "estimated_minutes INTEGER NOT NULL DEFAULT 15");
  addColumn("priority", "priority TEXT NOT NULL DEFAULT 'normal'");
  addColumn("assignee", "assignee TEXT");
  addColumn("accepted_at", "accepted_at TEXT");
  addColumn("started_at", "started_at TEXT");
  addColumn("inspected_at", "inspected_at TEXT");
}

function migrateOrders() {
  const columns = db.prepare("PRAGMA table_info(orders)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE orders ADD COLUMN ${sql}`);
  };
  addColumn("expected_arrival_minutes", "expected_arrival_minutes INTEGER NOT NULL DEFAULT 20");
  addColumn("earliest_checkin_at", "earliest_checkin_at TEXT");
}

function migrateHardware() {
  const columns = db.prepare("PRAGMA table_info(hardware)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE hardware ADD COLUMN ${sql}`);
  };
  addColumn("door_open", "door_open INTEGER NOT NULL DEFAULT 0");
  addColumn("ac_on", "ac_on INTEGER NOT NULL DEFAULT 0");
  addColumn("light_on", "light_on INTEGER NOT NULL DEFAULT 0");
  addColumn("access_authorized", "access_authorized INTEGER NOT NULL DEFAULT 0");
  addColumn("hot_water_on", "hot_water_on INTEGER NOT NULL DEFAULT 0");
  addColumn("elevator_authorized", "elevator_authorized INTEGER NOT NULL DEFAULT 0");
  addColumn("adapter", "adapter TEXT DEFAULT 'mock'");
  addColumn("last_command", "last_command TEXT");
}

function migratePayments() {
  db.exec(`CREATE TABLE IF NOT EXISTS payment_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    room_id INTEGER,
    provider TEXT NOT NULL DEFAULT 'mock',
    status TEXT NOT NULL,
    scenario TEXT NOT NULL,
    amount REAL NOT NULL,
    deposit REAL NOT NULL DEFAULT 0,
    transaction_id TEXT,
    checkin_qr TEXT,
    request_json TEXT,
    created_at TEXT NOT NULL
  );`);
}

function migrateStoreTransfers() {
  const columns = db.prepare("PRAGMA table_info(store_transfers)").all().map((c) => c.name);
  const addColumn = (name, sql) => {
    if (!columns.includes(name)) db.exec(`ALTER TABLE store_transfers ADD COLUMN ${sql}`);
  };
  addColumn("guest_contact", "guest_contact TEXT");
  addColumn("start_at", "start_at TEXT");
  addColumn("end_at", "end_at TEXT");
  addColumn("expected_arrival_minutes", "expected_arrival_minutes INTEGER NOT NULL DEFAULT 20");
  addColumn("earliest_checkin_at", "earliest_checkin_at TEXT");
  addColumn("settlement_status", "settlement_status TEXT NOT NULL DEFAULT 'pending'");
  addColumn("lock_id", "lock_id TEXT");
  addColumn("compensation_type", "compensation_type TEXT");
  addColumn("compensation_value", "compensation_value REAL NOT NULL DEFAULT 0");
  addColumn("compensation_text", "compensation_text TEXT");
  addColumn("supplement_json", "supplement_json TEXT");
  addColumn("confirmed_at", "confirmed_at TEXT");
  addColumn("user_id", "user_id TEXT");
}

function migrateCrossStoreLocks() {
  db.exec(`CREATE TABLE IF NOT EXISTS cross_store_locks (
    lock_id TEXT PRIMARY KEY,
    from_store TEXT NOT NULL,
    to_store TEXT NOT NULL,
    room_label TEXT NOT NULL,
    room_type TEXT,
    start_at TEXT NOT NULL,
    end_at TEXT NOT NULL,
    amount REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'reserved',
    expires_at TEXT NOT NULL,
    payload_json TEXT,
    created_at TEXT NOT NULL
  );`);
}

function migrateTimeCards() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS time_cards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      time_card_id TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'normal',
      benefits_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS time_card_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ledger_no TEXT NOT NULL UNIQUE,
      time_card_id TEXT NOT NULL,
      benefit_type TEXT NOT NULL,
      action TEXT NOT NULL,
      quantity REAL NOT NULL,
      source TEXT NOT NULL,
      operator TEXT NOT NULL,
      related_order TEXT,
      reason TEXT,
      created_at TEXT NOT NULL
    );
  `);
}

function seedDemoData() {
  const roomStmt = db.prepare("INSERT INTO rooms(number, type, base_price, status) VALUES (?, ?, ?, ?)");
  // 演示酒店：2-6层，每层各有经济/标准/豪华三种房型。
  // 初始只展示可售房源，不预置订单；后台订单只来自客户端真实同步。
  buildDemoRooms().forEach((room) => roomStmt.run(room.number, room.type, room.basePrice, room.status));

  const priceStmt = db.prepare("INSERT INTO pricing(key, label, value) VALUES (?, ?, ?)");
  [
    ["golden", "黄金时段 周五20:00-周六08:00", 1.3],
    ["standard", "标准时段 工作日08:00-20:00", 1.0],
    ["fragment", "碎片时段 工作日14:00-18:00", 0.7],
    ["waste", "垃圾时段 工作日02:00-08:00", 0.5],
    ["demand_low", "剩余可售时间 <30%", 1.2],
    ["demand_hot", "剩余可售时间 <10%", 1.5],
    ["transfer_time_per_100m", "跨店补偿：每100米补偿分钟数", 2],
    ["transfer_traffic_per_km", "跨店补偿：每公里交通补偿金额", 4],
    ["transfer_traffic_min", "跨店补偿：最低交通补偿", 10],
    ["transfer_time_max", "跨店补偿：最高时间补偿分钟", 120]
  ].forEach((row) => priceStmt.run(...row));

  db.prepare("SELECT id FROM rooms").all().forEach((room) => updateHardware(room.id));
  db.prepare("INSERT INTO metadata(key, value) VALUES ('seeded', '1')").run();
}

function buildDemoRooms() {
  const typeBySuffix = {
    "01": { type: "economy", basePrice: 199 },
    "02": { type: "standard", basePrice: 299 },
    "03": { type: "deluxe", basePrice: 499 }
  };
  const rooms = [];
  for (let floor = 2; floor <= 6; floor += 1) {
    Object.entries(typeBySuffix).forEach(([suffix, meta]) => {
      const number = `${floor}${suffix}`;
      rooms.push({
        number,
        type: meta.type,
        basePrice: meta.basePrice,
        status: "idle"
      });
    });
  }
  return rooms;
}

function ensureDemoRoomInventory() {
  // 已经部署过的数据库不会自动重建，这里补齐新版本需要的2-6层完整房型。
  const stmt = db.prepare("INSERT OR IGNORE INTO rooms(number, type, base_price, status) VALUES (?, ?, ?, 'idle')");
  buildDemoRooms().forEach((room) => stmt.run(room.number, room.type, room.basePrice));
  db.prepare("SELECT id FROM rooms").all().forEach((room) => updateHardware(room.id));
}

function cleanupSeededNoiseAlerts() {
  // 后台默认保持真实运营的安静状态：删除旧版本预置的假报警。
  db.prepare(`
    DELETE FROM alerts
    WHERE message IN (
      '203房触发紧急按钮，已同步前台/保安/店长',
      '201房用户评分2星，关键词：卫生/噪音'
    )
  `).run();
}

function cleanupAutomaticOperationalNoise() {
  // 保持后台安静：清理旧版本因刷新/定时器自动生成的保洁与预警信息。
  // 后续只有客户侧明确动作（下单、退房、超时模拟、异常模拟）才会同步新信息。
  db.prepare(`
    DELETE FROM alerts
    WHERE type IN ('保洁调度', '清洁可能超时', '用户未到店', '超时未退房')
      AND status = 'open'
  `).run();
}

function cleanupInitialBackendInfoOnce() {
  // 一次性把旧版本线上遗留的演示订单/测试订单清空。
  // 清空后设置标记，之后客户新下单的订单会正常保留，不会每次重启都删除。
  const done = db.prepare("SELECT value FROM metadata WHERE key = 'quiet_backend_orders_v1'").get();
  if (done) return;
  db.exec(`
    DELETE FROM alerts;
    DELETE FROM waitlist;
    DELETE FROM store_transfers;
    DELETE FROM cleaning_tasks;
    DELETE FROM maintenance_blocks;
    DELETE FROM orders;
    UPDATE rooms SET status = 'idle';
  `);
  db.prepare(`
    INSERT INTO metadata(key, value) VALUES ('quiet_backend_orders_v1', ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(new Date().toISOString());
  db.prepare("SELECT id FROM rooms").all().forEach((room) => updateHardware(room.id));
}

function createOrderRaw({ roomId, guest, status, startAt, endAt, price, actualCheckoutAt = null, deposit = DEPOSIT, overtimeFee = 0, refund = 0, note = "", expectedArrivalMinutes = 0, earliestCheckinAt = null }) {
  const earliest = earliestCheckinAt || arrivalCheckinAt(startAt, expectedArrivalMinutes);
  const contract = buildContract(roomId, startAt, endAt, price, { expectedArrivalMinutes, earliestCheckinAt: earliest });
  contract.deposit = deposit;
  const info = db.prepare(`
    INSERT INTO orders(room_id, guest, status, start_at, end_at, actual_checkout_at, price, deposit, overtime_fee, refund, paid_total, contract_json, note, expected_arrival_minutes, earliest_checkin_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(roomId, guest, status, startAt, endAt, actualCheckoutAt, round(price), deposit, overtimeFee, refund, round(price + deposit), JSON.stringify(contract), note, expectedArrivalMinutes, earliest, new Date().toISOString());
  return info.lastInsertRowid;
}

function generateTransactionId() {
  return `MOCKPAY-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function generateCheckinQr(orderId, roomId) {
  // Mock二维码内容：真实交付时替换为二维码服务或小程序入住凭证。
  return `HTA-CHECKIN|order=${orderId}|room=${roomId}|token=${crypto.randomBytes(8).toString("hex")}`;
}

const paymentGateway = {
  provider: "mock",
  async pay({ scenario = "success", amount, deposit, request }) {
    const normalized = ["success", "fail", "cancel"].includes(scenario) ? scenario : "success";
    const status = normalized === "success" ? "success" : normalized === "cancel" ? "cancelled" : "failed";
    return {
      provider: this.provider,
      scenario: normalized,
      status,
      amount: round(amount),
      deposit: round(deposit),
      transactionId: status === "success" ? generateTransactionId() : null,
      message: status === "success"
        ? "模拟支付成功"
        : status === "cancelled"
          ? "用户取消支付，未生成订单，房间保持可售"
          : "模拟支付失败，未生成订单，房间保持可售",
      raw: request
    };
  }
};

function writePaymentRecord({ orderId = null, roomId = null, payment, checkinQr = null }) {
  db.prepare(`
    INSERT INTO payment_records(order_id, room_id, provider, status, scenario, amount, deposit, transaction_id, checkin_qr, request_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    orderId,
    roomId,
    payment.provider,
    payment.status,
    payment.scenario,
    payment.amount,
    payment.deposit,
    payment.transactionId,
    checkinQr,
    JSON.stringify(payment.raw || {}),
    new Date().toISOString()
  );
}

const physicalControlGateway = {
  adapter: "mock",
  apply(roomId, command, reason = "") {
    const enabled = command === "activate";
    const payload = {
      lock: enabled ? "authorized" : "disabled",
      door: "closed",
      power: enabled ? "on" : "off",
      ac: enabled ? "on" : "off",
      lights: enabled ? "on" : "off",
      access: enabled ? "authorized" : "disabled",
      hotWater: enabled ? "on" : "off",
      elevator: enabled ? "authorized" : "disabled",
      reason
    };
    db.prepare(`
      INSERT INTO hardware(room_id, lock_authorized, lock_open, power_on, door_open, ac_on, light_on, access_authorized, hot_water_on, elevator_authorized, emergency_light_on, adapter, last_command, updated_at)
      VALUES (?, ?, 0, ?, 0, ?, ?, ?, ?, ?, 1, 'mock', ?, ?)
      ON CONFLICT(room_id) DO UPDATE SET
        lock_authorized = excluded.lock_authorized,
        lock_open = 0,
        power_on = excluded.power_on,
        door_open = 0,
        ac_on = excluded.ac_on,
        light_on = excluded.light_on,
        access_authorized = excluded.access_authorized,
        hot_water_on = excluded.hot_water_on,
        elevator_authorized = excluded.elevator_authorized,
        emergency_light_on = 1,
        adapter = 'mock',
        last_command = excluded.last_command,
        updated_at = excluded.updated_at
    `).run(
      roomId,
      enabled ? 1 : 0,
      enabled ? 1 : 0,
      enabled ? 1 : 0,
      enabled ? 1 : 0,
      enabled ? 1 : 0,
      enabled ? 1 : 0,
      enabled ? 1 : 0,
      JSON.stringify(payload),
      new Date().toISOString()
    );
    return payload;
  }
};

function cleaningMinutesByType(type) {
  // V3.0：15分钟是系统标准完成时限（SLA），不是固定清扫等待时间。
  // 实际完成可以是5/8/12分钟，完成即恢复可售。
  return 15;
}

function cleaningBufferByType(type) {
  return 15;
}

function roomCleaningBuffer(roomId) {
  const room = db.prepare("SELECT type FROM rooms WHERE id = ?").get(roomId);
  return cleaningBufferByType(room?.type);
}

function nextCheckinAfter(roomId, endedAt) {
  return db.prepare(`
    SELECT start_at, earliest_checkin_at
    FROM orders
    WHERE room_id = ?
      AND status = 'pending'
      AND datetime(start_at) >= datetime(?)
    ORDER BY datetime(start_at) ASC
    LIMIT 1
  `).get(roomId, endedAt || new Date().toISOString());
}

function dynamicCleaningPlan(roomId, endedAt = new Date().toISOString()) {
  const room = db.prepare("SELECT type FROM rooms WHERE id = ?").get(roomId);
  const nextOrder = nextCheckinAfter(roomId, endedAt);
  const deadline = nextOrder?.earliest_checkin_at || nextOrder?.start_at || null;
  const gapMinutes = deadline ? Math.floor((new Date(deadline) - new Date(endedAt)) / 60_000) : null;
  const priority = gapMinutes !== null && gapMinutes < 15 ? "urgent" : "normal";
  const targetMinutes = gapMinutes === null
    ? 8
    : gapMinutes <= 8
      ? Math.max(3, gapMinutes - 1)
      : gapMinutes <= 15
        ? Math.max(5, gapMinutes - 2)
        : gapMinutes <= 30
          ? 8
          : 12;
  return {
    slaMinutes: cleaningMinutesByType(room?.type),
    targetMinutes: Math.max(3, Math.min(15, targetMinutes)),
    priority,
    deadline,
    gapMinutes
  };
}

function autoAssignee(roomId) {
  const workers = ["王阿姨", "李师傅", "赵姐"];
  return workers[Number(roomId || 0) % workers.length];
}

function createCleaningTask({ roomId, orderId, endedAt, priority = null, status = "pending", assignee = null, scheduledAt = null, completedAt = null, note = "" }) {
  const plan = dynamicCleaningPlan(roomId, endedAt || new Date().toISOString());
  const startAt = scheduledAt || new Date().toISOString();
  const assignedWorker = assignee || autoAssignee(roomId);
  const existing = orderId ? db.prepare("SELECT id FROM cleaning_tasks WHERE order_id = ? AND status != 'released' LIMIT 1").get(orderId) : null;
  if (existing) return existing.id;
  const info = db.prepare(`
    INSERT INTO cleaning_tasks(room_id, order_id, status, scheduled_at, completed_at, ended_at, estimated_minutes, priority, assignee, accepted_at, started_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(roomId, orderId, status, startAt, completedAt, endedAt, plan.slaMinutes, priority || plan.priority, assignedWorker, null, null);
  if (note) createAlert({ roomId, type: "保洁调度", severity: (priority || plan.priority) === "urgent" ? "warning" : "info", message: note });
  updateRoomStatus(roomId);
  return info.lastInsertRowid;
}

function dashboardWithCleaningNotice(date, taskId) {
  const dashboard = getDashboard(date);
  dashboard.latestCleaningNotice = dashboard.cleaningTasks.find((task) => task.id === taskId) || null;
  return dashboard;
}

function normalizeCleaningDurations() {
  // V3.0：历史工单统一按15分钟SLA统计，15分钟不是固定清扫时间。
  db.prepare(`
    UPDATE cleaning_tasks
    SET estimated_minutes = 15
  `).run();
}

function actualCleaningMinutes(task) {
  if (!task.started_at || !task.completed_at) return null;
  return Math.max(1, Math.round((new Date(task.completed_at) - new Date(task.started_at)) / 60_000));
}

function alertRecipients(severity, type) {
  const base = ["前台", "运维"];
  if (severity === "critical" || ["安全警报", "门锁故障", "电路异常", "清洁可能超时", "超时未退房"].includes(type)) {
    base.push("保安", "店长");
  }
  return [...new Set(base)];
}

function createAlert({ roomId = null, type, severity = "warning", message, recipients = null }) {
  const duplicate = db.prepare(`
    SELECT id FROM alerts
    WHERE status != 'resolved' AND type = ? AND IFNULL(room_id, 0) = IFNULL(?, 0)
    LIMIT 1
  `).get(type, roomId);
  const targetRecipients = recipients || alertRecipients(severity, type);
  if (duplicate) {
    db.prepare("UPDATE alerts SET recipients = COALESCE(recipients, ?) WHERE id = ?").run(targetRecipients.join("、"), duplicate.id);
    return duplicate.id;
  }
  const info = db.prepare(`
    INSERT INTO alerts(room_id, type, severity, status, message, recipients, created_at)
    VALUES (?, ?, ?, 'open', ?, ?, ?)
  `).run(roomId, type, severity, message, targetRecipients.join("、"), new Date().toISOString());
  return info.lastInsertRowid;
}

function buildStoresSummary(metrics, alerts, userId = "demo-user") {
  const today = ymd(new Date());
  expireCrossStoreLocks();
  const transfers = db.prepare(`
    SELECT * FROM store_transfers
    WHERE date(created_at) = date(?)
    ORDER BY datetime(created_at) DESC
  `).all(today);
  const activeLocks = db.prepare(`
    SELECT * FROM cross_store_locks
    WHERE status = 'reserved' AND datetime(expires_at) > datetime(?)
    ORDER BY datetime(created_at) DESC
  `).all(new Date().toISOString());
  const timeCard = timeCardService.summary(userId || "demo-user");
  const waitlistCount = db.prepare("SELECT COUNT(*) AS count FROM waitlist WHERE status = 'waiting'").get().count;
  const transferAmount = transfers.reduce((sum, t) => sum + t.amount, 0);
  const commissionAmount = transfers.reduce((sum, t) => sum + t.commission_amount, 0);
  const partnerRevenue = transfers.reduce((sum, t) => sum + t.host_revenue, 0);
  const recommendation = crossStoreRecommendation();
  const bStoreOrders = transfers.map((t) => ({
    ...t,
    tag: "跨店调度",
    sourceStore: t.from_store,
    receiveStore: t.to_store,
    splitText: `A店${t.commission_rate}% / B店${100 - t.commission_rate}%`,
    roomStatus: t.status === "locked" ? "已售/已锁定" : "已完成",
    noticeTitle: "跨店调度订单：来自A店",
    minutesToArrival: t.earliest_checkin_at ? Math.max(0, Math.floor((new Date(t.earliest_checkin_at) - new Date()) / 60_000)) : null
  }));
  const bLockedRooms = bStoreOrders
    .filter((t) => t.status === "locked")
    .map((t) => ({ room: t.room_label, status: "已售", guest: t.guest, startAt: t.start_at, endAt: t.end_at }));
  const current = {
    id: "A",
    name: "A店 · 时间资产旗舰店",
    address: "上海市静安区南京西路88号",
    rooms: 3,
    occupancyRate: metrics.occupancyRate,
    todayIncome: round(metrics.todayIncome + commissionAmount),
    alerts: alerts.filter((a) => a.status !== "resolved").length,
    role: "总部/店长/前台"
  };
  const stores = [
    current,
    { id: "B", name: "B店 · 高铁站店", address: "上海虹桥枢纽T2旁", rooms: 36, occupancyRate: 42, todayIncome: round(8620 + partnerRevenue), alerts: 0, role: "总部可见" },
    { id: "C", name: "C店 · 商务公园店", address: "浦东张江科创园18号", rooms: 52, occupancyRate: 76, todayIncome: 15380, alerts: 0, role: "总部可见" }
  ];
  const totalRooms = stores.reduce((sum, s) => sum + s.rooms, 0);
  const totalIncome = stores.reduce((sum, s) => sum + s.todayIncome, 0);
  const avgOccupancy = round(stores.reduce((sum, s) => sum + s.occupancyRate, 0) / stores.length);
  return {
    role: "总部：看所有店；店长：看本店；前台：看本店并处理异常",
    stores,
    totalRooms,
    totalIncome: round(totalIncome),
    avgOccupancy,
    incomeRanking: [...stores].sort((a, b) => b.todayIncome - a.todayIncome),
    occupancyRanking: [...stores].sort((a, b) => b.occupancyRate - a.occupancyRate),
    waitlistCount,
    transferFinance: {
      count: transfers.length,
      amount: round(transferAmount),
      commissionAmount: round(commissionAmount),
      partnerRevenue: round(partnerRevenue),
      latest: transfers.slice(0, 5)
    },
    crossStoreZone: {
      todayOrders: transfers.length,
      sourceCommissionTotal: round(commissionAmount),
      receivingRevenueTotal: round(partnerRevenue),
      pendingSettlement: transfers.filter((t) => (t.settlement_status || "pending") === "pending").length
    },
    aStoreRecords: transfers.map((t) => ({
      id: t.id,
      title: "跨店调度成功",
      room: t.room_label,
      guest: t.guest,
      guestContact: t.guest_contact || "138****1010",
      startAt: t.start_at,
      endAt: t.end_at,
      amount: t.amount,
      commissionAmount: t.commission_amount,
      settlementStatus: t.settlement_status || "pending",
      compensationText: t.compensation_text || "",
      createdAt: t.created_at
    })),
    bStoreOrders,
    bStoreRooms: bLockedRooms,
    activeLocks: activeLocks.map((lock) => ({
      lockId: lock.lock_id,
      toStore: lock.to_store,
      room: lock.room_label,
      expiresAt: lock.expires_at,
      amount: lock.amount,
      status: "5分钟预留中"
    })),
    timeCard,
    latestTransferNotice: bStoreOrders[0] || null,
    transferRecommendation: {
      ...recommendation,
      reason: current.occupancyRate >= 90 ? "A店满房，推荐B店空闲房" : "演示：当A店满房时，系统推荐B店空闲房"
    }
  };
}

function expireCrossStoreLocks() {
  db.prepare(`
    UPDATE cross_store_locks
    SET status = 'expired'
    WHERE status = 'reserved' AND datetime(expires_at) <= datetime(?)
  `).run(new Date().toISOString());
}

const timeCardService = {
  ensure(userId = "demo-user") {
    const now = new Date().toISOString();
    const existing = db.prepare("SELECT * FROM time_cards WHERE user_id = ?").get(userId);
    if (existing) return this.serialize(existing);
    const timeCardId = `TC-${String(userId).toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10) || "USER"}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
    db.prepare(`
      INSERT INTO time_cards(time_card_id, user_id, status, benefits_json, created_at, updated_at)
      VALUES (?, ?, 'normal', ?, ?, ?)
    `).run(timeCardId, userId, JSON.stringify(this.emptyBenefits()), now, now);
    return this.get(userId);
  },
  emptyBenefits() {
    return {
      time: 0,
      compensation: 0,
      activity: 0,
      brand: 0,
      balance: 0,
      extensions: {}
    };
  },
  serialize(card) {
    return {
      ...card,
      benefits: JSON.parse(card.benefits_json || "{}")
    };
  },
  get(userId = "demo-user") {
    const card = db.prepare("SELECT * FROM time_cards WHERE user_id = ?").get(userId);
    return card ? this.serialize(card) : this.ensure(userId);
  },
  ledger(userId = "demo-user", limit = 20) {
    const card = this.get(userId);
    return db.prepare(`
      SELECT * FROM time_card_ledger
      WHERE time_card_id = ?
      ORDER BY datetime(created_at) DESC, id DESC
      LIMIT ?
    `).all(card.time_card_id, limit);
  },
  adjust({ userId = "demo-user", benefitType = "compensation", action = "issue", quantity = 0, source = "system", operator = "system", relatedOrder = "", reason = "" }) {
    const card = this.get(userId);
    if (card.status !== "normal") throw new Error("时间卡当前不可用");
    const benefits = { ...this.emptyBenefits(), ...(card.benefits || {}) };
    const key = benefitType in benefits ? benefitType : "extensions";
    const value = round(Number(quantity || 0));
    if (key === "extensions") {
      benefits.extensions = benefits.extensions || {};
      benefits.extensions[benefitType] = round(Number(benefits.extensions[benefitType] || 0) + value);
    } else {
      benefits[key] = round(Number(benefits[key] || 0) + value);
      if (benefits[key] < 0) throw new Error("时间卡权益余额不足");
    }
    const now = new Date().toISOString();
    const ledgerNo = `TCL-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
    db.prepare("UPDATE time_cards SET benefits_json = ?, updated_at = ? WHERE time_card_id = ?")
      .run(JSON.stringify(benefits), now, card.time_card_id);
    db.prepare(`
      INSERT INTO time_card_ledger(ledger_no, time_card_id, benefit_type, action, quantity, source, operator, related_order, reason, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(ledgerNo, card.time_card_id, benefitType, action, value, source, operator, relatedOrder, reason, now);
    return this.get(userId);
  },
  issueCompensation({ userId = "demo-user", amount, source = "cross_store", relatedOrder = "", reason = "" }) {
    return this.adjust({
      userId,
      benefitType: "compensation",
      action: "issue",
      quantity: amount,
      source,
      operator: "system",
      relatedOrder,
      reason
    });
  },
  summary(userId = "demo-user") {
    const card = this.get(userId);
    return {
      card,
      ledger: this.ledger(userId, 12),
      moduleOrder: [
        "用户系统",
        "时间卡系统",
        "订单系统",
        "时间定价系统",
        "支付系统",
        "入住系统",
        "房态系统",
        "保洁调度系统",
        "现场协调系统",
        "时间补偿系统",
        "异常预警系统",
        "门店运营系统",
        "总部管理系统"
      ]
    };
  }
};

const userService = {
  normalizePhone(phone = "") {
    return String(phone || "").replace(/\D/g, "").slice(0, 20) || `guest-${crypto.randomBytes(3).toString("hex")}`;
  },
  userIdFromPhone(phone = "") {
    return `USER-${this.normalizePhone(phone)}`;
  },
  register({ name = "现场演示客户", phone = "13800001010" }) {
    const now = new Date().toISOString();
    const safeName = String(name || "现场演示客户").trim().slice(0, 30) || "现场演示客户";
    const safePhone = this.normalizePhone(phone);
    const userId = this.userIdFromPhone(safePhone);
    db.prepare(`
      INSERT INTO users(user_id, name, phone, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        name = excluded.name,
        phone = excluded.phone,
        updated_at = excluded.updated_at
    `).run(userId, safeName, safePhone, now, now);
    const user = db.prepare("SELECT * FROM users WHERE user_id = ?").get(userId);
    const timeCard = timeCardService.summary(userId);
    return { user, timeCard };
  },
  get(userId = "demo-user") {
    return db.prepare("SELECT * FROM users WHERE user_id = ?").get(userId) || {
      user_id: userId,
      name: "现场演示客户",
      phone: "13800001010"
    };
  }
};

function getCompensationConfig() {
  const pricing = getPricingConfig();
  return {
    timePer100m: Number(pricing.transfer_time_per_100m ?? 2),
    trafficPerKm: Number(pricing.transfer_traffic_per_km ?? 4),
    trafficMin: Number(pricing.transfer_traffic_min ?? 10),
    timeMax: Number(pricing.transfer_time_max ?? 120)
  };
}

function formatCompensationNumber(value) {
  return Number(Number(value || 0).toFixed(2)).toString();
}

function trafficCompensation(distanceKm) {
  const config = getCompensationConfig();
  const distance = Number(distanceKm || 0);
  return round(Math.max(distance * config.trafficPerKm, config.trafficMin));
}

function timeCompensationMinutes(recommendation) {
  const config = getCompensationConfig();
  const distance = Number(recommendation.distanceKm || 0);
  const distanceMeters = distance * 1000;
  return round(Math.min((distanceMeters / 100) * config.timePer100m, config.timeMax));
}

function parseDistanceKm(value, fallback = NaN) {
  const raw = String(value ?? "").trim().toLowerCase().replace(",", ".");
  const numeric = Number(raw.replace(/公里|千米|km|米|m/g, "").trim());
  const hasKmUnit = /公里|千米|km/.test(raw);
  const hasMeterUnit = /米|m/.test(raw) && !hasKmUnit;
  // 演示输入支持任何数字：
  // - 800 / 800米 / 800m => 0.8公里
  // - 2.3 / 2,3 / 2.3公里 => 2.3公里
  const distance = hasMeterUnit || (!hasKmUnit && numeric > 50) ? numeric / 1000 : numeric;
  return Number.isFinite(distance) ? distance : fallback;
}

// 同品牌门店坐标：真实上线后替换为地图服务返回的经纬度。
// 当前演示版由后端自动计算距离，前端不允许顾客手工修改距离。
const STORE_GEO = {
  A: { id: "A", name: "A店 · 时间资产旗舰店", lat: 31.2304, lng: 121.4737, capacity: 3 },
  B: { id: "B", name: "B店 · 高铁站店", lat: 31.2420, lng: 121.4530, capacity: 36 },
  C: { id: "C", name: "C店 · 商务公园店", lat: 31.2070, lng: 121.5140, capacity: 52 }
};

const CROSS_STORE_ROOMS = {
  B: { economy: "B-0806", standard: "B-1206", deluxe: "B-2308" },
  C: { economy: "C-0508", standard: "C-1618", deluxe: "C-2606" }
};

function haversineKm(from, to) {
  const rad = (n) => (n * Math.PI) / 180;
  const earthKm = 6371;
  const dLat = rad(to.lat - from.lat);
  const dLng = rad(to.lng - from.lng);
  const lat1 = rad(from.lat);
  const lat2 = rad(to.lat);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return round(earthKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function lockedStoreCount(storeId) {
  const row = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM store_transfers WHERE to_store LIKE ? AND status = 'locked') +
      (SELECT COUNT(*) FROM cross_store_locks WHERE to_store LIKE ? AND status = 'reserved' AND datetime(expires_at) > datetime(?))
      AS count
  `).get(`${storeId}店%`, `${storeId}店%`, new Date().toISOString());
  return Number(row?.count || 0);
}

function nearestCrossStore(input = {}) {
  const source = STORE_GEO.A;
  const demoDistance = parseDistanceKm(input.distanceKm);
  const candidates = [STORE_GEO.B, STORE_GEO.C]
    .map((store) => {
      const locked = store.id === "B" && input.forceBFull ? store.capacity : lockedStoreCount(store.id);
      return {
        ...store,
        locked,
        available: Math.max(0, store.capacity - locked),
        // 演示模式：允许输入距离用于验证“距离变化 -> 补偿自动变化”。
        // 正式接入地图后，这里直接使用地图服务返回的真实距离。
        distanceKm: Number.isFinite(demoDistance)
          ? Math.max(0, round(demoDistance + (store.id === "C" ? 2.5 : 0)))
          : haversineKm(source, store)
      };
    })
    .sort((a, b) => a.distanceKm - b.distanceKm);
  return candidates.find((store) => store.available > 0) || candidates[candidates.length - 1];
}

function ensureCrossStoreLock(recommendation) {
  expireCrossStoreLocks();
  const existing = db.prepare(`
    SELECT * FROM cross_store_locks
    WHERE status = 'reserved'
      AND to_store = ?
      AND room_label = ?
      AND datetime(start_at) = datetime(?)
      AND datetime(end_at) = datetime(?)
      AND datetime(expires_at) > datetime(?)
    ORDER BY datetime(created_at) DESC
    LIMIT 1
  `).get(recommendation.to, recommendation.roomNumber, recommendation.startAt, recommendation.endAt, new Date().toISOString());
  if (existing) return existing.lock_id;
  const lockId = `XLOCK-${Date.now()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
  db.prepare(`
    INSERT INTO cross_store_locks(lock_id, from_store, to_store, room_label, room_type, start_at, end_at, amount, status, expires_at, payload_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'reserved', ?, ?, ?)
  `).run(
    lockId,
    recommendation.from,
    recommendation.to,
    recommendation.roomNumber,
    recommendation.roomType,
    recommendation.startAt,
    recommendation.endAt,
    recommendation.estimatedOrder,
    addMinutes(new Date(), 5).toISOString(),
    JSON.stringify(recommendation),
    new Date().toISOString()
  );
  return lockId;
}

function crossStoreRecommendation(input = {}) {
  const selectedRoom = input.roomId ? db.prepare("SELECT * FROM rooms WHERE id = ?").get(Number(input.roomId)) : null;
  const type = selectedRoom?.type || input.roomType || "standard";
  const expectedArrivalMinutes = Math.max(0, Number(input.expectedArrivalMinutes ?? 0));
  const earliestCheckinAt = arrivalCheckinAt(input.date ? parseRange(input.date, Number(input.startMinute ?? 20 * 60), Number(input.endMinute ?? 22 * 60), input.endDate || input.date).startAt : new Date(), expectedArrivalMinutes);
  expireCrossStoreLocks();
  const targetStore = nearestCrossStore(input);
  const toStore = targetStore.name;
  const toStoreId = targetStore.id;
  const distanceKm = targetStore.distanceKm;
  const basePrice = selectedRoom?.base_price || db.prepare("SELECT base_price FROM rooms WHERE type = ? LIMIT 1").get(type)?.base_price || 299;
  const roomPool = CROSS_STORE_ROOMS[toStoreId] || CROSS_STORE_ROOMS.B;
  const startMinute = Number(input.startMinute ?? 20 * 60);
  const endMinute = Number(input.endMinute ?? startMinute + 120);
  const date = input.date || ymd(new Date());
  const endDate = input.endDate || date;
  const { startAt, endAt } = parseRange(date, startMinute, endMinute, endDate);
  const minutes = Math.max(1, Math.round((endAt - startAt) / 60_000));
  const pricing = getPricingConfig();
  const perMinute = basePrice / 1440;
  let total = 0;
  for (let i = 0; i < minutes; i++) {
    total += perMinute * timeCoefficient(addMinutes(startAt, i), pricing);
  }
  const estimatedOrder = round(total);
  const commission = round(estimatedOrder * 0.1);
  const partner = round(estimatedOrder - commission);
  const compensationConfig = getCompensationConfig();
  const distanceMeters = round(distanceKm * 1000);
  const trafficValue = trafficCompensation(distanceKm);
  const timeValue = timeCompensationMinutes({ startAt: startAt.toISOString(), endAt: endAt.toISOString(), distanceKm });
  const extendedEndAt = addMinutes(endAt, timeValue).toISOString();
  const transferRoomNumber = roomPool[type] || (toStoreId === "C" ? "C-1618" : "B-1206");
  const transferSpatial = spatialPricing({ number: transferRoomNumber });
  return {
    fromStoreId: "A",
    toStoreId,
    from: "A店 · 时间资产旗舰店",
    to: toStore,
    distanceKm,
    fallbackReason: targetStore.id === "C" ? "最近可接待门店已自动切换为C店" : "",
    roomNumber: transferRoomNumber,
    roomTypeKey: type,
    roomType: TYPES[type] || "双人大床房",
    room: `${transferRoomNumber} ${TYPES[type] || "双人大床房"}`,
    startAt: startAt.toISOString(),
    endAt: endAt.toISOString(),
    expectedArrivalMinutes,
    earliestCheckinAt,
    minutes,
    commissionRate: 10,
    estimatedOrder,
    commission,
    partnerRevenue: partner,
    lockMinutes: 5,
    lockExpiresAt: addMinutes(new Date(), 5).toISOString(),
    compensationCalc: {
      distanceMeters,
      distanceKm,
      timePer100m: compensationConfig.timePer100m,
      trafficPerKm: compensationConfig.trafficPerKm,
      trafficMin: compensationConfig.trafficMin,
      timeMax: compensationConfig.timeMax,
      timeFormula: `${formatCompensationNumber(distanceMeters)} ÷ 100 × ${formatCompensationNumber(compensationConfig.timePer100m)}`,
      trafficFormula: `${formatCompensationNumber(distanceKm)} × ${formatCompensationNumber(compensationConfig.trafficPerKm)}`,
      timeRaw: round((distanceMeters / 100) * compensationConfig.timePer100m),
      timeResult: timeValue,
      trafficRaw: round(distanceKm * compensationConfig.trafficPerKm),
      trafficResult: trafficValue
    },
    compensationOptions: [
      {
        type: "traffic",
        title: "交通补偿",
        value: trafficValue,
        text: `¥${formatCompensationNumber(trafficValue)}`,
        description: "确认后可在时间卡里查看。"
      },
      {
        type: "time",
        title: "时间补偿",
        value: timeValue,
        text: `免费延长${formatCompensationNumber(timeValue)}分钟`,
        description: `可将离店时间延长至${new Date(extendedEndAt).toLocaleString("zh-CN", { hour12: false })}。`
      }
    ],
    contract: {
      title: "跨店点对点时间契约",
      roomNumber: transferRoomNumber,
      roomAssignText: `${transferRoomNumber}房`,
      roomType: `${TYPES[type] || "双人大床房"}（${toStore}）`,
      spatial: transferSpatial,
      startAt: startAt.toISOString(),
      endAt: endAt.toISOString(),
      price: estimatedOrder,
      deposit: DEPOSIT,
      expectedArrivalMinutes,
      earliestCheckinAt,
      rules: CONTRACT_OVERTIME_RULES,
      checkinRules: CHECKIN_RULES,
      transferNote: `A店已满：系统推荐${toStore}并自动转单；出单店A抽成10%，接待店获得90%房费收入。`,
      hardware: `${toStore}使用Mock支付与Mock设备接口：支付成功后立即锁房并开启门锁、供电、空调、门禁等权限；订单结束后自动关闭设备。`
    }
  };
}

function ymd(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addMinutes(date, minutes) {
  return new Date(new Date(date).getTime() + minutes * 60_000);
}

function arrivalCheckinAt(startAt, expectedArrivalMinutes) {
  const byArrival = addMinutes(new Date(), expectedArrivalMinutes);
  const byContract = new Date(startAt);
  return (byArrival > byContract ? byArrival : byContract).toISOString();
}

function arrivalText(minutes) {
  const value = Math.max(0, Number(minutes || 0));
  return value === 0 ? "用户现在到店/跳过填写预计到店时间" : `用户预计${value}分钟后到店`;
}

function roomSpaceProfile(roomNumber) {
  const number = String(roomNumber || "");
  const floor = Number(number.slice(0, -2)) || 2;
  const suffix = number.slice(-2);
  const floorBand = floor <= 3 ? "低楼层" : floor <= 6 ? "中楼层" : "高楼层";
  const layoutBySuffix = {
    "01": { window: "有窗", position: "中间" },
    "02": { window: "有窗", position: "靠电梯" },
    "03": { window: "无窗", position: "靠楼道" }
  };
  return { floor, floorBand, ...(layoutBySuffix[suffix] || { window: "有窗", position: "中间" }) };
}

function spatialPricing(room) {
  const profile = roomSpaceProfile(room?.number);
  const factors = [];
  if (profile.window === "无窗") factors.push({ label: "无窗", factor: 0.85, text: "无窗-15%" });
  if (profile.position === "靠楼道") factors.push({ label: "靠楼道", factor: 0.9, text: "靠楼道-10%" });
  if (profile.position === "靠电梯") factors.push({ label: "靠电梯", factor: 0.98, text: "靠电梯-2%" });
  if (profile.floorBand === "低楼层") factors.push({ label: "低楼层", factor: 1, text: "低楼层标准价" });
  if (profile.floorBand === "中楼层") factors.push({ label: "中楼层", factor: 1, text: "中楼层标准价" });
  if (profile.floorBand === "高楼层") factors.push({ label: "高楼层", factor: 1.05, text: "高楼层+5%" });
  const factor = factors.reduce((x, item) => x * item.factor, 1);
  return { ...profile, factor: round(factor), factors };
}

function isFirstLateExempt(order) {
  const previous = db.prepare(`
    SELECT COUNT(*) AS count FROM orders
    WHERE guest = ? AND id != ? AND note LIKE '%迟到%'
  `).get(order.guest, order.id).count;
  return previous === 0;
}

function noShowBilling(order, at = new Date()) {
  const earliest = new Date(order.earliest_checkin_at || order.start_at);
  const billStart = addMinutes(earliest, 30);
  const cancelAt = addMinutes(earliest, 60);
  const effectiveEnd = at > cancelAt ? cancelAt : at;
  const totalMinutes = Math.max(1, Math.round((new Date(order.end_at) - new Date(order.start_at)) / 60_000));
  const billedMinutes = Math.max(0, Math.round((effectiveEnd - billStart) / 60_000));
  const exempt = billedMinutes > 0 && isFirstLateExempt(order);
  const fee = exempt ? 0 : Math.min(Number(order.price || 0), round((Number(order.price || 0) / totalMinutes) * billedMinutes));
  const refund = round(Number(order.price || 0) + Number(order.deposit || DEPOSIT) - fee);
  return { billStart, cancelAt, billedMinutes, fee, refund, exempt };
}

function overtimeCharge(minutes) {
  if (minutes >= 20) {
    return {
      fee: DEPOSIT,
      shouldRenew: true,
      note: "超时20分钟：押金自动转为续住房费，并开启12小时续住周期"
    };
  }
  if (minutes >= 15) {
    return {
      fee: 10,
      shouldRenew: false,
      note: "超时15分钟：扣除10元超时费，并持续提醒退房"
    };
  }
  if (minutes >= 10) {
    return {
      fee: 5,
      shouldRenew: false,
      note: "超时10分钟：第二次提醒，并扣除5元超时费"
    };
  }
  if (minutes >= 5) {
    return {
      fee: 0,
      shouldRenew: false,
      note: "超时5分钟：第一次提醒用户退房，不扣费"
    };
  }
  return {
    fee: 0,
    shouldRenew: false,
    note: "超时5分钟内：仅记录，不扣费"
  };
}

function minuteOfDay(date) {
  const d = new Date(date);
  return d.getHours() * 60 + d.getMinutes();
}

function round(value) {
  return Math.round(value * 100) / 100;
}

function getPricingConfig() {
  return Object.fromEntries(db.prepare("SELECT key, value FROM pricing").all().map((r) => [r.key, r.value]));
}

function weekday(date) {
  return new Date(date).getDay();
}

function timeCoefficient(date, pricing) {
  const day = weekday(date);
  const m = minuteOfDay(date);
  const isWorkday = day >= 1 && day <= 5;
  if ((day === 5 && m >= 20 * 60) || (day === 6 && m < 8 * 60)) return pricing.golden;
  if (isWorkday && m >= 14 * 60 && m < 18 * 60) return pricing.fragment;
  if (isWorkday && m >= 2 * 60 && m < 8 * 60) return pricing.waste;
  if (isWorkday && m >= 8 * 60 && m < 20 * 60) return pricing.standard;
  return 0.85;
}

function demandCoefficient(roomId, date, pricing) {
  const map = buildMinuteMap(roomId, date);
  const idle = map.filter((x) => x === "idle").length;
  const ratio = idle / 1440;
  if (ratio < 0.1) return pricing.demand_hot;
  if (ratio < 0.3) return pricing.demand_low;
  return 1;
}

function parseRange(date, startMinute, endMinute, endDate = date) {
  const start = new Date(`${date}T00:00:00`);
  const end = new Date(`${endDate}T00:00:00`);
  start.setMinutes(startMinute);
  end.setMinutes(endMinute);
  return { startAt: start, endAt: end };
}

function roomEarliestStart(roomId, now = new Date()) {
  const buffer = 0;
  const base = now;
  const earliest = base;
  return { earliest, buffer };
}

function rangeIsIdle(roomId, startAt, endAt) {
  const overlaps = db.prepare(`
    SELECT COUNT(*) AS count FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime')
      AND datetime(end_at) > datetime(?) AND datetime(start_at) < datetime(?)
  `).get(roomId, startAt.toISOString(), endAt.toISOString()).count;
  if (overlaps > 0) return false;

  const maintenance = db.prepare(`
    SELECT COUNT(*) AS count FROM maintenance_blocks
    WHERE room_id = ?
      AND datetime(end_at) > datetime(?) AND datetime(start_at) < datetime(?)
  `).get(roomId, startAt.toISOString(), endAt.toISOString()).count;
  return maintenance === 0;
}

function ensureBookable(roomId, startAt, endAt) {
  // 支付前最后一次库存确认：报价阶段可售，不代表支付瞬间仍然可售。
  // 用户侧只判断该时段是否已有订单或维护占用；保洁作为后台工单管理，不向用户暴露。
  if (!rangeIsIdle(roomId, new Date(startAt), new Date(endAt))) {
    throw new Error("该房间所选时段已被占用或维护中，系统将为您推荐其他可订方案。");
  }
  return true;
}

function demandCoefficientForRange(roomId, startAt, pricing) {
  return demandCoefficient(roomId, ymd(startAt), pricing);
}

function quote(roomId, date, startMinute, endMinute, endDate = date) {
  const room = db.prepare("SELECT * FROM rooms WHERE id = ?").get(roomId);
  if (!room) throw new Error("房间不存在");
  const { startAt, endAt } = parseRange(date, startMinute, endMinute, endDate);
  const minutes = Math.round((endAt - startAt) / 60_000);
  if (minutes <= 0) throw new Error("结束时间必须晚于开始时间，可以把结束日期选到明天或更后面");
  if (!rangeIsIdle(roomId, startAt, endAt)) throw new Error(`所选时间段暂不可订，请选择其他时间或房间`);

  const pricing = getPricingConfig();
  const demand = demandCoefficientForRange(roomId, startAt, pricing);
  const perMinute = room.base_price / 1440;
  const space = spatialPricing(room);
  let total = 0;
  let standardTotal = 0;
  const segmentStats = {};
  for (let i = 0; i < minutes; i++) {
    const current = addMinutes(startAt, i);
    const coeff = timeCoefficient(current, pricing);
    standardTotal += perMinute * coeff * demand;
    total += perMinute * space.factor * coeff * demand;
    const key = coeff === pricing.golden ? "黄金" : coeff === pricing.fragment ? "碎片" : coeff === pricing.waste ? "垃圾" : "标准/普通";
    segmentStats[key] = (segmentStats[key] || 0) + 1;
  }
  return {
    room,
    date,
    endDate,
    startMinute,
    endMinute,
    minutes,
    price: round(total),
    standardPrice: round(standardTotal),
    saving: round(Math.max(0, standardTotal - total)),
    savingRate: standardTotal > 0 ? round(((standardTotal - total) / standardTotal) * 100) : 0,
    spatial: space,
    deposit: DEPOSIT,
    payTotal: round(total + DEPOSIT),
    demandCoefficient: demand,
    segmentStats,
    contract: buildContract(roomId, startAt.toISOString(), endAt.toISOString(), total, { standardPrice: standardTotal, saving: Math.max(0, standardTotal - total), spatial: space })
  };
}

function quoteByType(roomType, date, startMinute, endMinute, endDate = date) {
  const rooms = db.prepare("SELECT * FROM rooms WHERE type = ? ORDER BY number").all(roomType);
  if (!rooms.length) throw new Error("该房型不存在");
  const errors = [];
  for (const room of rooms) {
    try {
      const data = quote(room.id, date, startMinute, endMinute, endDate);
      data.roomTypeKey = roomType;
      data.availableRoomCount = rooms.filter((candidate) => {
        const { startAt, endAt } = parseRange(date, startMinute, endMinute, endDate);
        return rangeIsIdle(candidate.id, startAt, endAt);
      }).length;
      data.contract = buildContract(room.id, data.contract.startAt, data.contract.endAt, data.price, { hideRoomNumber: true });
      return data;
    } catch (error) {
      errors.push(error.message);
    }
  }
  throw new Error(errors[0] || "该房型所选时间不可售，建议跨店调度或更换时间");
}

function buildContract(roomId, startAt, endAt, price, options = {}) {
  const room = db.prepare("SELECT number, type FROM rooms WHERE id = ?").get(roomId);
  return {
    title: "点对点时间契约",
    roomNumber: options.hideRoomNumber ? "" : room?.number || "",
    roomAssignText: options.hideRoomNumber ? "到店后分配房间" : `${room?.number || ""}房`,
    roomType: TYPES[room?.type] || room?.type || "",
    spatial: options.spatial || spatialPricing(room),
    standardPrice: round(options.standardPrice || price),
    saving: round(options.saving || 0),
    startAt,
    endAt,
    price: round(price),
    deposit: DEPOSIT,
    expectedArrivalMinutes: options.expectedArrivalMinutes ?? 0,
    earliestCheckinAt: options.earliestCheckinAt || arrivalCheckinAt(startAt, options.expectedArrivalMinutes ?? 0),
    rules: CONTRACT_OVERTIME_RULES,
    checkinRules: CHECKIN_RULES,
    billingCap: "演示默认房费封顶不超过原契约房费",
    hardware: "当前演示为Mock设备模式：支付成功后锁定时段并开启门锁权限、房间电源、空调、灯光、门禁、热水和电梯权限；支付失败或取消不会锁房；订单结束后设备自动关闭并进入保洁。"
  };
}

function buildMinuteMap(roomId, date) {
  return buildMinuteRangeMap(roomId, date, date).map;
}

function normalizeTimelineRange(startDate, endDate = startDate) {
  const rangeStart = new Date(`${startDate}T00:00:00`);
  const rangeEnd = new Date(`${endDate}T00:00:00`);
  if (Number.isNaN(rangeStart.getTime()) || Number.isNaN(rangeEnd.getTime()) || rangeEnd < rangeStart) {
    return normalizeTimelineRange(ymd(new Date()), ymd(new Date()));
  }
  rangeEnd.setDate(rangeEnd.getDate() + 1);
  const minutes = Math.max(1440, Math.round((rangeEnd - rangeStart) / 60_000));
  return { rangeStart, rangeEnd, minutes };
}

function buildMinuteRangeMap(roomId, startDate, endDate = startDate) {
  // 按“开始日期00:00 → 结束日期24:00”生成连续分钟颗粒。
  // 例如22号住到26号，后台会得到一条连续的5天时间轴，而不是只展示22号当天。
  const { rangeStart, rangeEnd, minutes } = normalizeTimelineRange(startDate, endDate);
  const map = new Array(minutes).fill("idle");
  const orders = db.prepare(`
    SELECT * FROM orders
    WHERE room_id = ? AND status IN ('pending','ongoing','overtime')
      AND datetime(end_at) >= datetime(?) AND datetime(start_at) <= datetime(?)
  `).all(roomId, rangeStart.toISOString(), rangeEnd.toISOString());

  orders.forEach((order) => paintRange(map, order.start_at, order.end_at, rangeStart, "sold"));
  const cleaning = db.prepare("SELECT * FROM cleaning_tasks WHERE room_id = ? AND status IN ('pending','accepted','cleaning')").all(roomId);
  cleaning.forEach((task) => paintRange(map, task.scheduled_at, addMinutes(task.scheduled_at, cleaningTargetMinutes(task)).toISOString(), rangeStart, "cleaning"));
  const maintenance = db.prepare("SELECT * FROM maintenance_blocks WHERE room_id = ?").all(roomId);
  maintenance.forEach((block) => paintRange(map, block.start_at, block.end_at, rangeStart, "maintenance"));
  return { map, rangeStart, rangeEnd, minutes };
}

function paintRange(map, startAt, endAt, rangeStart, state) {
  const start = new Date(startAt);
  const end = new Date(endAt);
  const from = Math.max(0, Math.floor((start - rangeStart) / 60_000));
  const to = Math.min(map.length, Math.ceil((end - rangeStart) / 60_000));
  for (let i = from; i < to; i++) map[i] = state;
}

function compressMap(map) {
  const segments = [];
  let start = 0;
  for (let i = 1; i <= map.length; i++) {
    if (i === map.length || map[i] !== map[start]) {
      segments.push({ state: map[start], start, end: i, width: ((i - start) / map.length) * 100 });
      start = i;
    }
  }
  const counts = map.reduce((acc, state) => {
    acc[state] = (acc[state] || 0) + 1;
    return acc;
  }, {});
  return { segments, counts };
}

function updateOrderAutomation() {
  const now = new Date();
  const noShows = db.prepare(`
    SELECT * FROM orders
    WHERE status = 'pending'
      AND note NOT LIKE '预置：%'
      AND datetime(COALESCE(earliest_checkin_at, start_at), '+60 minutes') <= datetime(?)
  `).all(now.toISOString());
  noShows.forEach((order) => {
    const billing = noShowBilling(order, now);
    db.prepare(`
      UPDATE orders SET status = 'cancelled', refund = ?, overtime_fee = ?, note = ?
      WHERE id = ?
    `).run(
      billing.refund,
      billing.fee,
      `用户未到店：最早入住后1小时仍未办理入住，系统自动取消；${billing.exempt ? "首次迟到免责，请合理安排时间" : `已产生${billing.billedMinutes}分钟时段费${billing.fee}元`}，剩余退款${billing.refund}元`,
      order.id
    );
    updateHardware(order.room_id);
  });

  const ongoing = db.prepare("SELECT * FROM orders WHERE status = 'ongoing' AND note NOT LIKE '预置：%'").all();
  ongoing.forEach((order) => {
    const overtimeMinutes = Math.floor((now - new Date(order.end_at)) / 60_000);
    if (overtimeMinutes > 0) {
      db.prepare("UPDATE orders SET status = 'overtime', note = ? WHERE id = ?").run(`系统检测：已超时${overtimeMinutes}分钟`, order.id);
      updateHardware(order.room_id);
    }
  });

  const rooms = db.prepare("SELECT id FROM rooms").all();
  rooms.forEach((room) => updateRoomStatus(room.id));
}

function cleaningTargetMinutes(task) {
  const plan = dynamicCleaningPlan(task.room_id, task.ended_at || task.scheduled_at);
  return plan.targetMinutes;
}

function updateDynamicCleaningAutomation(now = new Date()) {
  // 当前演示版保留可见工单流程：系统自动派单，但不自动点完成。
  // 后台点击“完成并上架”后，房态立即恢复可售。
  return;
  const activeTasks = db.prepare(`
    SELECT * FROM cleaning_tasks
    WHERE status = 'cleaning'
  `).all();
  activeTasks.forEach((task) => {
    const startedAt = new Date(task.started_at || task.scheduled_at);
    const targetMinutes = cleaningTargetMinutes(task);
    if (now - startedAt >= targetMinutes * 60_000) {
      const completedAt = addMinutes(startedAt, targetMinutes).toISOString();
      db.prepare(`
        UPDATE cleaning_tasks
        SET status = 'released',
            completed_at = COALESCE(completed_at, ?),
            inspected_at = COALESCE(inspected_at, completed_at, ?)
        WHERE id = ?
      `).run(completedAt, completedAt, task.id);
      updateRoomStatus(task.room_id);
    }
  });
}

function updateCleaningPreAlerts() {
  const now = new Date();
  const tasks = db.prepare(`
    SELECT c.*, o.start_at, o.earliest_checkin_at, o.expected_arrival_minutes, r.number AS room_number
    FROM cleaning_tasks c
    LEFT JOIN orders o ON c.order_id = o.id
    LEFT JOIN rooms r ON c.room_id = r.id
    WHERE c.status = 'cleaning'
  `).all();
  tasks.forEach((task) => {
    const targetAt = task.earliest_checkin_at || task.start_at;
    const minutesToCheckin = targetAt ? Math.floor((new Date(targetAt) - now) / 60_000) : null;
    if (minutesToCheckin !== null && minutesToCheckin < 5 && minutesToCheckin >= 0) {
      createAlert({ roomId: task.room_id, type: "清洁可能超时", severity: "critical", message: `${task.room_number}房距离用户预计到店仅${minutesToCheckin}分钟，清洁未完成；前台、运维、保安、店长已同步，建议用户延迟入住或换房` });
    }
  });
}

function updateRoomStatus(roomId) {
  const active = db.prepare("SELECT status FROM orders WHERE room_id = ? AND status IN ('ongoing','overtime') ORDER BY id DESC LIMIT 1").get(roomId);
  const cleaning = db.prepare("SELECT status FROM cleaning_tasks WHERE room_id = ? AND status IN ('pending','accepted','cleaning') ORDER BY id DESC LIMIT 1").get(roomId);
  const futureOrder = db.prepare("SELECT id FROM orders WHERE room_id = ? AND status = 'pending' ORDER BY datetime(start_at) ASC LIMIT 1").get(roomId);
  const status = active?.status === "overtime"
    ? "overtime"
    : active
      ? "occupied"
      : cleaning
        ? "cleaning"
        : futureOrder
          ? "pending"
          : "idle";
  db.prepare("UPDATE rooms SET status = ? WHERE id = ?").run(status, roomId);
}

function updateHardware(roomId) {
  updateRoomStatus(roomId);
  const room = db.prepare("SELECT status FROM rooms WHERE id = ?").get(roomId);
  const active = room?.status === "occupied" || room?.status === "overtime";
  physicalControlGateway.apply(roomId, active ? "activate" : "deactivate", active ? "订单入住/续住中，设备保持开启" : "订单结束/取消，设备关闭，仅保留应急照明");
}

function updateAlertEscalation() {
  const now = new Date();
  const open = db.prepare("SELECT * FROM alerts WHERE status != 'resolved'").all();
  open.forEach((alert) => {
    const minutes = Math.floor((now - new Date(alert.created_at)) / 60_000);
    if (minutes >= 15 && !alert.escalated) {
      db.prepare("UPDATE alerts SET escalated = 1, severity = 'critical', recipients = '前台、运维、保安、店长', message = message || ' · 超时未处理，已升级同步前台/运维/保安/店长' WHERE id = ?").run(alert.id);
    }
  });
}

function serializeRoom(room) {
  const availability = roomEarliestStart(room.id);
  const spatial = spatialPricing(room);
  return {
    ...room,
    typeLabel: TYPES[room.type],
    floor: spatial.floor,
    floorBand: spatial.floorBand,
    window: spatial.window,
    position: spatial.position,
    spatialFactor: spatial.factor,
    spatialFactors: spatial.factors,
    guestStatus: "可预订",
    cleaningBuffer: availability.buffer,
    earliestStartAt: availability.earliest.toISOString()
  };
}

function getDashboard(date = ymd(new Date()), endDate = date, userId = "demo-user") {
  updateOrderAutomation();
  updateAlertEscalation();
  const { minutes: rangeMinutes } = normalizeTimelineRange(date, endDate);
  const rooms = db.prepare("SELECT * FROM rooms ORDER BY number").all().map(serializeRoom);
  const orders = db.prepare(`
    SELECT o.*, r.number AS room_number, r.type AS room_type
    FROM orders o JOIN rooms r ON o.room_id = r.id
    ORDER BY datetime(o.start_at) DESC
  `).all().map((o) => ({ ...o, contract: JSON.parse(o.contract_json), roomTypeLabel: TYPES[o.room_type] }));
  const hardware = db.prepare("SELECT * FROM hardware").all();
  const payments = db.prepare(`
    SELECT p.*, r.number AS room_number
    FROM payment_records p
    LEFT JOIN rooms r ON p.room_id = r.id
    ORDER BY datetime(p.created_at) DESC
    LIMIT 30
  `).all();
  const cleaningTasks = db.prepare(`
    SELECT c.*, r.number AS room_number, r.type AS room_type, o.end_at AS order_end_at, o.start_at AS order_start_at, o.earliest_checkin_at AS order_earliest_checkin_at, o.expected_arrival_minutes AS order_expected_arrival_minutes
    FROM cleaning_tasks c
    JOIN rooms r ON c.room_id = r.id
    LEFT JOIN orders o ON c.order_id = o.id
    ORDER BY CASE c.status
      WHEN 'pending' THEN 1
      WHEN 'accepted' THEN 2
      WHEN 'cleaning' THEN 3
      WHEN 'finished' THEN 4
      WHEN 'completed' THEN 5
      WHEN 'released' THEN 6
      ELSE 6
    END, datetime(c.scheduled_at) DESC
  `).all().map((task) => {
    const targetAt = task.order_earliest_checkin_at || task.order_start_at;
    const minutesToCheckin = targetAt ? Math.floor((new Date(targetAt) - new Date()) / 60_000) : null;
    return {
      ...task,
      actual_minutes: actualCleaningMinutes(task),
      target_minutes: ["pending", "accepted", "cleaning"].includes(task.status) ? cleaningTargetMinutes(task) : null,
      roomTypeLabel: TYPES[task.room_type],
      minutes_to_checkin: minutesToCheckin,
      dispatch_label: minutesToCheckin !== null && minutesToCheckin >= 0 ? `动态调度：距离下一位入住${minutesToCheckin}分钟，清扫完成即恢复可售` : "动态调度：无紧邻入住，仍建议尽快完成以提高周转"
    };
  });
  const timelines = rooms.map((room) => {
    const { map, rangeStart, rangeEnd, minutes } = buildMinuteRangeMap(room.id, date, endDate);
    return {
      roomId: room.id,
      roomNumber: room.number,
      rangeStart: rangeStart.toISOString(),
      rangeEnd: rangeEnd.toISOString(),
      rangeMinutes: minutes,
      rangeDays: Math.ceil(minutes / 1440),
      ...compressMap(map)
    };
  });
  const viewStart = new Date(`${date}T00:00:00`);
  const viewEnd = new Date(`${endDate}T00:00:00`);
  viewEnd.setDate(viewEnd.getDate() + 1);
  const todayOrders = orders.filter((o) => new Date(o.end_at) >= viewStart && new Date(o.start_at) <= viewEnd);
  const income = todayOrders.reduce((sum, o) => sum + (o.status === "completed" || o.status === "overtime" || o.status === "ongoing" ? o.price + o.overtime_fee : 0), 0);
  const soldMinutes = timelines.reduce((sum, t) => sum + (t.counts.sold || 0), 0);
  const avgPrice = todayOrders.length ? income / todayOrders.length : 0;
  const alerts = db.prepare(`
    SELECT a.*, r.number AS room_number
    FROM alerts a
    LEFT JOIN rooms r ON a.room_id = r.id
    ORDER BY CASE a.severity WHEN 'critical' THEN 1 WHEN 'warning' THEN 2 ELSE 3 END,
      CASE a.status WHEN 'open' THEN 1 WHEN 'acknowledged' THEN 2 ELSE 3 END,
      datetime(a.created_at) DESC
  `).all();
  const metrics = {
    todayIncome: round(income),
    occupancyRate: round((soldMinutes / (rooms.length * rangeMinutes)) * 100),
    averageRoomPrice: round(avgPrice),
    soldMinutes,
    idleMinutes: rooms.length * rangeMinutes - soldMinutes
  };
  return {
    now: new Date().toISOString(),
    date,
    endDate,
    rangeMinutes,
    rooms,
    orders,
    hardware,
    payments,
    timelines,
    pricing: db.prepare("SELECT * FROM pricing ORDER BY key").all(),
    cleaningTasks,
    // 普通刷新/进入系统不返回“新保洁通知”，避免后台或客户端无动作时自动弹信息。
    latestCleaningNotice: null,
    alerts,
    latestAlert: alerts.find((a) => a.status === "open") || null,
    metrics,
    cleaningMetrics: buildCleaningMetrics(cleaningTasks),
    stores: buildStoresSummary(metrics, alerts, userId)
  };
}

function buildCleaningMetrics(tasks) {
  const today = ymd(new Date());
  const todayTasks = tasks.filter((t) => ymd(t.scheduled_at) === today || ymd(t.completed_at) === today);
  const completed = todayTasks.filter((t) => ["completed", "released"].includes(t.status));
  const actuals = completed.map(actualCleaningMinutes).filter(Boolean);
  const byAssignee = {};
  completed.forEach((task) => {
    const name = task.assignee || "未分配";
    const actual = actualCleaningMinutes(task) || task.estimated_minutes;
    if (!byAssignee[name]) byAssignee[name] = { name, count: 0, total: 0 };
    byAssignee[name].count += 1;
    byAssignee[name].total += actual;
  });
  return {
    total: todayTasks.length,
    pending: todayTasks.filter((t) => ["pending", "accepted"].includes(t.status)).length,
    processing: todayTasks.filter((t) => t.status === "cleaning").length,
    completed: completed.length,
    averageMinutes: actuals.length ? round(actuals.reduce((sum, x) => sum + x, 0) / actuals.length) : 0,
    ranking: Object.values(byAssignee)
      .map((x) => ({ name: x.name, count: x.count, avg: round(x.total / x.count) }))
      .sort((a, b) => b.count - a.count || a.avg - b.avg)
  };
}

function cleanupSessions() {
  const now = Date.now();
  for (const [token, session] of sessions.entries()) {
    if (session.expiresAt <= now) sessions.delete(token);
  }
}

function createSession() {
  cleanupSessions();
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, {
    createdAt: Date.now(),
    expiresAt: Date.now() + SESSION_TTL_MS
  });
  return token;
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  const session = sessions.get(token);
  if (!session || session.expiresAt <= Date.now()) {
    if (token) sessions.delete(token);
    return res.status(401).json({ message: "登录已过期，请重新输入密码" });
  }
  session.expiresAt = Date.now() + SESSION_TTL_MS;
  next();
}

function withAuth(handler) {
  return (req, res) => requireAuth(req, res, () => {
    Promise.resolve(handler(req, res)).catch((error) => {
      console.error("API执行失败", error);
      if (!res.headersSent) res.status(500).json({ message: error.message || "系统服务异常" });
    });
  });
}

app.post("/api/auth/login", (req, res) => {
  if (String(req.body.password || "") !== ACCESS_PASSWORD) {
    return res.status(401).json({ message: "系统维护中" });
  }
  res.json({
    ok: true,
    token: createSession(),
    expiresInMinutes: Math.round(SESSION_TTL_MS / 60_000)
  });
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "hotel-time-asset-system" });
});

app.get("/api/bootstrap", withAuth((req, res) => {
  res.json(getDashboard(
    req.query.date || ymd(new Date()),
    req.query.endDate || req.query.date || ymd(new Date()),
    req.query.userId || "demo-user"
  ));
}));

app.get("/api/time-card", withAuth((req, res) => {
  res.json({ ok: true, timeCard: timeCardService.summary(req.query.userId || "demo-user") });
}));

app.post("/api/users/register", withAuth((req, res) => {
  const result = userService.register({
    name: req.body.name || "现场演示客户",
    phone: req.body.phone || "13800001010"
  });
  res.json({ ok: true, ...result, message: "用户注册成功，系统已自动创建唯一时间卡。" });
}));

app.post("/api/time-card/adjust", withAuth((req, res) => {
  const card = timeCardService.adjust({
    userId: req.body.userId || "demo-user",
    benefitType: req.body.benefitType || "compensation",
    action: req.body.action || "manual_adjust",
    quantity: Number(req.body.quantity || 0),
    source: req.body.source || "headquarters_operation",
    operator: req.body.operator || "总部运营",
    relatedOrder: req.body.relatedOrder || "",
    reason: req.body.reason || "人工调整时间卡权益"
  });
  res.json({ ok: true, timeCard: timeCardService.summary(req.body.userId || "demo-user"), card });
}));

app.post("/api/quote", withAuth((req, res) => {
  try {
    const data = quote(Number(req.body.roomId), req.body.date, Number(req.body.startMinute), Number(req.body.endMinute), req.body.endDate || req.body.date);
    const expectedArrivalMinutes = Math.max(0, Number(req.body.expectedArrivalMinutes ?? 0));
    data.contract.expectedArrivalMinutes = expectedArrivalMinutes;
    data.contract.earliestCheckinAt = arrivalCheckinAt(data.contract.startAt, expectedArrivalMinutes);
    res.json(data);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}));

app.post("/api/orders", withAuth(async (req, res) => {
  try {
    const q = quote(Number(req.body.roomId), req.body.date, Number(req.body.startMinute), Number(req.body.endMinute), req.body.endDate || req.body.date);
    const roomId = Number(q.room?.id || req.body.roomId);
    ensureBookable(roomId, q.contract.startAt, q.contract.endAt);
    const expectedArrivalMinutes = Math.max(0, Number(req.body.expectedArrivalMinutes ?? 0));
    const earliestCheckinAt = arrivalCheckinAt(q.contract.startAt, expectedArrivalMinutes);
    const payment = await paymentGateway.pay({
      scenario: req.body.paymentScenario || "success",
      amount: q.price,
      deposit: DEPOSIT,
      request: {
        roomId,
        startAt: q.contract.startAt,
        endAt: q.contract.endAt,
        guest: req.body.guest || "演示客人",
        paymentMethod: req.body.paymentMethod || "微信支付"
      }
    });
    if (payment.status !== "success") {
      writePaymentRecord({ roomId, payment });
      updateRoomStatus(roomId);
      physicalControlGateway.apply(roomId, "deactivate", payment.message);
      return res.json({
        ok: false,
        payment,
        dashboard: getDashboard(req.body.date),
        message: payment.message
      });
    }
    const orderId = createOrderRaw({
      roomId,
      guest: req.body.guest || "演示客人",
      status: "pending",
      startAt: q.contract.startAt,
      endAt: q.contract.endAt,
      price: q.price,
      note: "Mock支付成功：已生成订单、锁定时段、生成入住二维码，并通过Mock设备接口开启门锁/房间设备权限",
      expectedArrivalMinutes,
      earliestCheckinAt
    });
    const checkinQr = generateCheckinQr(orderId, roomId);
    const contract = buildContract(roomId, q.contract.startAt, q.contract.endAt, q.price, { expectedArrivalMinutes, earliestCheckinAt, spatial: q.spatial, standardPrice: q.standardPrice, saving: q.saving });
    contract.payment = {
      provider: payment.provider,
      method: req.body.paymentMethod || "微信支付",
      transactionId: payment.transactionId,
      status: payment.status
    };
    contract.checkinQr = checkinQr;
    db.prepare("UPDATE orders SET contract_json = ?, note = ? WHERE id = ?").run(
      JSON.stringify(contract),
      "用户端按具体房间下单：Mock支付成功，已锁定该房间时段，入住二维码已生成，Mock设备已开启权限",
      orderId
    );
    writePaymentRecord({ orderId, roomId, payment, checkinQr });
    physicalControlGateway.apply(roomId, "activate", "Mock支付成功，自动开启门锁权限、房间电源、空调、灯光、门禁、热水、电梯权限");
    // 干净可售房间被顾客下单后，只锁定房间/时段，不生成保洁工单。
    // 保洁只在退房、超时结束、突发异常等“房间被使用或污染后”触发。
    updateRoomStatus(roomId);
    res.json({ ok: true, payment, checkinQr, orderId, dashboard: getDashboard(req.body.date), message: "支付成功：订单已生成，入住二维码已生成。" });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}));

app.post("/api/orders/:id/checkin", withAuth((req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  if (order.status === "cancelled") return res.status(400).json({ message: "该订单已因未到店自动取消，房间已释放" });
  // 前台/后台演示办理入住时允许“模拟客户已到店”，避免因为订单时间在未来导致后续退房/超时流程跑不通。
  // 用户端真实入住仍然走时间校验，不传 force 时不会跳过规则。
  const forceCheckin = req.body.force === true;
  const now = new Date();
  const earliest = new Date(order.earliest_checkin_at || order.start_at);
  const billing = forceCheckin
    ? { fee: 0, billedMinutes: 0, exempt: false, refund: DEPOSIT, cancelAt: addMinutes(earliest, 60) }
    : noShowBilling(order, now);
  if (!forceCheckin && now >= billing.cancelAt) {
    db.prepare("UPDATE orders SET status = 'cancelled', refund = ?, overtime_fee = ?, note = ? WHERE id = ?").run(
      billing.refund,
      billing.fee,
      `用户超过最早入住1小时后到店，订单已自动取消；${billing.exempt ? "首次迟到免责，请合理安排时间" : `已产生${billing.billedMinutes}分钟时段费${billing.fee}元`}，剩余退款${billing.refund}元`,
      order.id
    );
    updateHardware(order.room_id);
    return res.status(400).json({ message: `订单已超过1小时未到店并自动取消；${billing.exempt ? "首次迟到免责，请合理安排时间" : `已扣${billing.fee}元`}，退款${billing.refund}元。` });
  }
  if (!forceCheckin && now < earliest) {
    const wait = Math.ceil((earliest - now) / 60_000);
    return res.status(400).json({ message: `房间准备中，预计${wait}分钟后就绪；Mock设备权限已预授权，到时可办理入住` });
  }
  const lateNote = billing.billedMinutes > 0 ? `；已超过30分钟缓冲，${billing.exempt ? "首次迟到免责，请合理安排时间" : `已产生到店前时段费${billing.fee}元（房费封顶不超过原契约价）`}` : "";
  const room = db.prepare("SELECT number FROM rooms WHERE id = ?").get(order.room_id);
  const contract = JSON.parse(order.contract_json);
  contract.roomNumber = room?.number || contract.roomNumber;
  contract.roomAssignText = `${room?.number || ""}房`;
  db.prepare("UPDATE orders SET status = 'ongoing', overtime_fee = ?, contract_json = ?, note = ? WHERE id = ?").run(
    billing.fee,
    JSON.stringify(contract),
    `${forceCheckin ? "前台/后台办理入住" : "用户到店入住"}：已分配${room?.number || ""}房，门锁与供电已生效，开始计费${lateNote}`,
    order.id
  );
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
}));

app.post("/api/alerts/simulate", withAuth((req, res) => {
  let roomId = Number(req.body.roomId || 0);
  const type = req.body.type || "安全警报";
  const severity = type === "安全警报" ? "critical" : ["门锁故障", "电路异常", "用户投诉"].includes(type) ? "warning" : "info";
  let room = db.prepare("SELECT id, number FROM rooms WHERE id = ?").get(roomId);
  if (!room) {
    room = db.prepare("SELECT id, number FROM rooms ORDER BY number LIMIT 1").get();
    roomId = room?.id || null;
  }
  const messageMap = {
    门锁故障: `${room?.number || ""}房开锁/关锁失败，请前台介入`,
    电路异常: `${room?.number || ""}房供电/断电失败，请工程巡检`,
    用户投诉: `${room?.number || ""}房评分低于3星或触发投诉关键词`,
    安全警报: `${room?.number || ""}房烟雾/水浸/紧急按钮触发，已同步保安`,
    超时未退房: `${room?.number || ""}房订单结束10分钟仍未退房`
  };
  createAlert({ roomId, type, severity, message: messageMap[type] || `${room?.number || ""}房出现异常` });
  res.json(getDashboard(req.body.date));
}));

app.post("/api/alerts/:id/action", withAuth((req, res) => {
  const alert = db.prepare("SELECT * FROM alerts WHERE id = ?").get(req.params.id);
  if (!alert) return res.status(404).json({ message: "异常不存在" });
  const now = new Date().toISOString();
  const action = req.body.action || "resolve";
  if (action === "ack") {
    db.prepare("UPDATE alerts SET status = 'acknowledged', acknowledged_at = ? WHERE id = ?").run(now, alert.id);
  } else if (action === "resolve") {
    db.prepare("UPDATE alerts SET status = 'resolved', method = ?, result = ?, resolved_at = ? WHERE id = ?").run(req.body.method || "前台/运维一键处理", req.body.result || "已记录并通知对应岗位", now, alert.id);
  } else if (action === "escalate") {
    db.prepare("UPDATE alerts SET status = 'acknowledged', escalated = 1, severity = 'critical', recipients = '前台、运维、保安、店长', method = ?, result = ?, acknowledged_at = COALESCE(acknowledged_at, ?) WHERE id = ?").run("升级通知", "已同步前台、运维、保安、店长", now, alert.id);
  } else {
    return res.status(400).json({ message: "未知异常动作" });
  }
  res.json(getDashboard(req.body.date));
}));

app.post("/api/orders/:id/checkout", withAuth((req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  const now = new Date();
  const plannedMinutes = Math.max(1, (new Date(order.end_at) - new Date(order.start_at)) / 60_000);
  const usedMinutes = Math.max(1, Math.min(plannedMinutes, (now - new Date(order.start_at)) / 60_000));
  const actualPrice = req.body.mode === "early" ? round(order.price * (usedMinutes / plannedMinutes)) : order.price;
  const refund = round(DEPOSIT + Math.max(0, order.price - actualPrice));
  db.prepare(`
    UPDATE orders SET status = 'completed', actual_checkout_at = ?, end_at = ?, price = ?, refund = ?, note = ?
    WHERE id = ?
  `).run(now.toISOString(), now.toISOString(), actualPrice, refund, req.body.mode === "early" ? "提前退房：按实际使用分钟重新结算" : "正常退房：押金已退还", order.id);
  const cleaningTaskId = createCleaningTask({ roomId: order.room_id, orderId: order.id, endedAt: now.toISOString(), priority: req.body.mode === "early" ? "normal" : "normal" });
  updateHardware(order.room_id);
  res.json(dashboardWithCleaningNotice(req.body.date, cleaningTaskId));
}));

app.post("/api/orders/:id/overtime", withAuth((req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);
  if (!order) return res.status(404).json({ message: "订单不存在" });
  const minutes = Number(req.body.minutes || 20);
  const charge = overtimeCharge(minutes);
  let renewalOrderId = null;
  if (charge.shouldRenew) {
    const nextStart = new Date(order.end_at);
    const nextEnd = addMinutes(nextStart, RENEWAL_MINUTES);
    const renewalPrice = round(Number(order.deposit || DEPOSIT));
    renewalOrderId = createOrderRaw({
      roomId: order.room_id,
      guest: `${order.guest}续住`,
      status: "ongoing",
      startAt: nextStart.toISOString(),
      endAt: nextEnd.toISOString(),
      price: renewalPrice,
      deposit: 0,
      note: `超时20分钟押金转为房费：${nextStart.toLocaleString("zh-CN", { hour12: false })} 至 ${nextEnd.toLocaleString("zh-CN", { hour12: false })}，共12小时`
    });
  }
  const note = renewalOrderId
    ? `${charge.note}，续住订单#${renewalOrderId}`
    : charge.note;
  db.prepare("UPDATE orders SET status = 'overtime', overtime_fee = ?, refund = ?, note = ? WHERE id = ?").run(charge.fee, Math.max(0, DEPOSIT - charge.fee), note, order.id);
  updateHardware(order.room_id);
  res.json(getDashboard(req.body.date));
}));

app.post("/api/cleaning/:id/action", withAuth((req, res) => {
  const task = db.prepare("SELECT * FROM cleaning_tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ message: "保洁任务不存在" });
  const now = new Date().toISOString();
  const worker = req.body.assignee || task.assignee || ["王阿姨", "李师傅", "赵姐"][task.id % 3];
  const action = req.body.action;
  if (action === "accept") {
    db.prepare("UPDATE cleaning_tasks SET status = 'accepted', assignee = ?, accepted_at = ? WHERE id = ?").run(worker, now, task.id);
  } else if (action === "start") {
    db.prepare("UPDATE cleaning_tasks SET status = 'cleaning', assignee = ?, started_at = COALESCE(started_at, ?) WHERE id = ?").run(worker, now, task.id);
  } else if (action === "finish") {
    // V3.0：外部清扫完成信号到达后，系统直接恢复可售，不需要人工确认。
    db.prepare("UPDATE cleaning_tasks SET status = 'released', completed_at = COALESCE(completed_at, ?), inspected_at = COALESCE(inspected_at, ?) WHERE id = ?").run(now, now, task.id);
  } else if (action === "inspect") {
    db.prepare("UPDATE cleaning_tasks SET status = 'released', completed_at = COALESCE(completed_at, ?), inspected_at = COALESCE(inspected_at, ?) WHERE id = ?").run(now, now, task.id);
  } else if (action === "release") {
    db.prepare("UPDATE cleaning_tasks SET status = 'released', completed_at = COALESCE(completed_at, ?), inspected_at = COALESCE(inspected_at, ?) WHERE id = ?").run(now, now, task.id);
  } else {
    return res.status(400).json({ message: "未知保洁动作" });
  }
  updateHardware(task.room_id);
  res.json(getDashboard(req.body.date));
}));

app.post("/api/cleaning/:id/complete", withAuth((req, res) => {
  const task = db.prepare("SELECT * FROM cleaning_tasks WHERE id = ?").get(req.params.id);
  if (!task) return res.status(404).json({ message: "保洁任务不存在" });
  const now = new Date().toISOString();
  db.prepare("UPDATE cleaning_tasks SET status = 'released', completed_at = COALESCE(completed_at, ?), inspected_at = COALESCE(inspected_at, ?) WHERE id = ?").run(now, now, task.id);
  updateHardware(task.room_id);
  res.json(getDashboard(req.body.date));
}));

app.post("/api/stores/recommend", withAuth((req, res) => {
  const recommendation = crossStoreRecommendation(req.body);
  const lockId = ensureCrossStoreLock(recommendation);
  const lock = db.prepare("SELECT * FROM cross_store_locks WHERE lock_id = ?").get(lockId);
  recommendation.lockId = lockId;
  recommendation.lockExpiresAt = lock?.expires_at || recommendation.lockExpiresAt;
  res.json({
    ok: true,
    title: "已为您找到同等级房间",
    message: `您选择的门店当前时间段已满。系统已为您预留${recommendation.to}同等级房间，库存锁定5分钟。`,
    recommendation
  });
}));

app.post("/api/stores/transfer", withAuth((req, res) => {
  const recommendation = crossStoreRecommendation(req.body);
  const lockId = req.body.lockId || ensureCrossStoreLock(recommendation);
  const lock = db.prepare("SELECT * FROM cross_store_locks WHERE lock_id = ?").get(lockId);
  if (!lock || lock.status !== "reserved" || new Date(lock.expires_at) <= new Date()) {
    return res.status(409).json({ message: "跨店预留已超时，系统会重新搜索附近门店并锁定新库存。" });
  }
  const compensationType = req.body.compensationType === "time" ? "time" : "traffic";
  const trafficValue = trafficCompensation(recommendation.distanceKm);
  const timeValue = timeCompensationMinutes(recommendation);
  const compensationValue = compensationType === "time" ? timeValue : trafficValue;
  const compensationText = compensationType === "time" ? `免费延长${formatCompensationNumber(timeValue)}分钟` : `¥${formatCompensationNumber(trafficValue)}账户补偿权益`;
  const finalEndAt = compensationType === "time"
    ? addMinutes(recommendation.endAt, timeValue).toISOString()
    : recommendation.endAt;
  if (compensationType === "time") {
    recommendation.endAt = finalEndAt;
    recommendation.contract.endAt = finalEndAt;
  }
  const amount = round(Number(req.body.amount || recommendation.estimatedOrder));
  const commission = round(amount * 0.1);
  const partner = round(amount - commission);
  const confirmedAt = new Date().toISOString();
  const supplement = {
    title: "跨店服务补充协议",
    originalStore: recommendation.from,
    adjustedStore: recommendation.to,
    reason: "原门店目标时段库存为0，系统自动启动跨店承接机制。",
    compensation: {
      type: compensationType,
      text: compensationText,
      value: compensationValue
    },
    orderTime: {
      startAt: recommendation.startAt,
      endAt: finalEndAt
    },
    userConfirmedAt: confirmedAt,
    lockId
  };
  if (compensationType === "traffic") {
    timeCardService.issueCompensation({
      userId: req.body.userId || "demo-user",
      amount: trafficValue,
      source: "cross_store_transfer",
      relatedOrder: lockId,
      reason: `跨店承接交通补偿：${recommendation.from} 调整至 ${recommendation.to}`
    });
  }
  const transferUserId = req.body.userId || "demo-user";
  db.prepare(`
    INSERT INTO store_transfers(from_store, to_store, room_label, guest, guest_contact, start_at, end_at, expected_arrival_minutes, earliest_checkin_at, amount, commission_rate, commission_amount, host_revenue, status, settlement_status, lock_id, compensation_type, compensation_value, compensation_text, supplement_json, confirmed_at, user_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 10, ?, ?, 'locked', 'pending', ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    recommendation.from,
    recommendation.to,
    `${recommendation.roomNumber} ${recommendation.roomType}`,
    req.body.guest || "跨店演示客户",
    req.body.guestContact || "138****1010",
    recommendation.startAt,
    finalEndAt,
    recommendation.expectedArrivalMinutes,
    recommendation.earliestCheckinAt,
    amount,
    commission,
    partner,
    lockId,
    compensationType,
    compensationValue,
    compensationText,
    JSON.stringify(supplement),
    confirmedAt,
    transferUserId,
    new Date().toISOString()
  );
  db.prepare("UPDATE cross_store_locks SET status = 'confirmed' WHERE lock_id = ?").run(lockId);
  const checkinQr = generateCheckinQr(`transfer-${lockId}`, recommendation.roomNumber);
  createAlert({
    type: "跨店调度订单",
    severity: "warning",
    message: `跨店调度订单：来自A店，${recommendation.to} ${recommendation.roomType} ${recommendation.roomNumber}，价格${amount}元，客户${req.body.guestContact || "138****1010"}，权益：${compensationText}，${arrivalText(recommendation.expectedArrivalMinutes)}`
  });
  res.json({
    ok: true,
    message: "支付成功：订单已生成，入住二维码已生成。",
    checkinQr,
    transfer: { ...recommendation, estimatedOrder: amount, commission, partnerRevenue: partner, compensationText, supplement },
    supplement,
    timeCard: timeCardService.summary(transferUserId),
    dashboard: getDashboard(req.body.date, req.body.endDate || req.body.date, transferUserId)
  });
}));

app.post("/api/stores/waitlist", withAuth((req, res) => {
  const recommendation = crossStoreRecommendation(req.body);
  db.prepare(`
    INSERT INTO waitlist(store_id, room_type, guest, requested_start_at, requested_end_at, status, created_at)
    VALUES ('A', ?, ?, ?, ?, 'waiting', ?)
  `).run(
    recommendation.roomType,
    req.body.guest || "候补演示客户",
    recommendation.startAt,
    recommendation.endAt,
    new Date().toISOString()
  );
  res.json({
    ok: true,
    message: "已加入A店候补队列：如有房间释放，前台会优先联系客户。",
    dashboard: getDashboard(req.body.date, req.body.endDate || req.body.date)
  });
}));

app.post("/api/pricing", withAuth((req, res) => {
  const { prices, factors } = req.body;
  if (prices) {
    Object.entries(prices).forEach(([type, price]) => {
      db.prepare("UPDATE rooms SET base_price = ? WHERE type = ?").run(Number(price), type);
    });
  }
  if (factors) {
    Object.entries(factors).forEach(([key, value]) => {
      db.prepare("UPDATE pricing SET value = ? WHERE key = ?").run(Number(value), key);
    });
  }
  res.json(getDashboard(req.body.date));
}));

app.post("/api/demo/reset", withAuth((req, res) => {
  db.exec("DROP TABLE IF EXISTS member_wallet; DELETE FROM metadata; DELETE FROM alerts; DELETE FROM waitlist; DELETE FROM store_transfers; DELETE FROM cross_store_locks; DELETE FROM time_card_ledger; DELETE FROM time_cards; DELETE FROM payment_records; DELETE FROM hardware; DELETE FROM cleaning_tasks; DELETE FROM maintenance_blocks; DELETE FROM orders; DELETE FROM rooms; DELETE FROM pricing;");
  seedDemoData();
  res.json(getDashboard(req.body.date));
}));

app.get("*", (req, res) => {
  // 轻量 Express 兼容层不支持完整 static 中间件选项；
  // 这里手动返回前端文件，确保 API 路由优先，其他路径回到首页。
  const publicDir = path.join(__dirname, "public");
  const safePath = path.normalize(decodeURIComponent(req.path || "/")).replace(/^(\.\.[/\\])+/, "");
  const candidate = path.join(publicDir, safePath === "/" ? "index.html" : safePath);
  if (candidate.startsWith(publicDir) && existsSync(candidate) && statSync(candidate).isFile()) {
    return res.sendFile(candidate);
  }
  res.sendFile(path.join(publicDir, "index.html"));
});

initDb();

if (!process.env.NO_LISTEN && !process.env.VERCEL) {
  setInterval(updateOrderAutomation, 30_000);
  // 云平台（Render/Railway 等）需要监听 0.0.0.0，外部流量才能稳定转发进来。
  // 本地如果想固定 127.0.0.1，可以启动时设置 HOST=127.0.0.1。
  const host = process.env.HOST || "0.0.0.0";
  app.listen(PORT, host, () => {
    console.log(`酒店时间资产管理系统已启动：http://localhost:${PORT}`);
  });
}

export { app, getDashboard, quote, quoteByType };
export default app;
